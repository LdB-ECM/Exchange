#include "Packet.h"
#include "Opcodes.h"
#include <string.h>

#include <windows.h>                // because we have to...

using namespace Ig;
using namespace Ig::Opcodes;

std::map<unsigned short, int> Packet::m_opcodeSizes;

Packet::Packet(int messageNumber, int status)
{
   // Initialize opcode sizes.
   initializeOpcodeSizes();

   // Initialize the buffer to 0.
   memset(m_buffer, 0, 1500);
   
   // Setup Pointers.
   m_packetHeaderOut = (PacketHeaderOut*)m_buffer;   
   m_packetHeaderIn = 0;
   m_dataHeader = (DataHeader*)(m_buffer + sizeof(PacketHeaderOut));

   // Setup the cursors.
   m_pushCursor = m_buffer + sizeof(PacketHeaderOut) + sizeof(DataHeader);
   m_popCursor = m_buffer + sizeof(PacketHeaderOut) + sizeof(DataHeader);

   // Setup the headers.
   m_packetHeaderOut->magicNumber = 0x20756470;
   m_dataHeader->msgnum = messageNumber;
   m_dataHeader->status = status;
   
   // Initialize buffer size.
   m_bufferSize = sizeof(PacketHeaderOut) + sizeof(DataHeader);

   // Set serialized to false because it has not been done yet.
   m_serialized = false;
   m_endOfDataPresent = false;
}

Packet::Packet(char* buffer, int size)
{
   // Initialize opcode sizes.
   initializeOpcodeSizes();

   // Make sure size isn't too big.
   if (size > 1500) size = 1500;
   // Initialize the buffer to 0.
   memset(m_buffer, 0, 1500);
   // Copy the data in.
   memcpy(m_buffer, buffer, size);

   // Setup Pointers.
   m_packetHeaderOut = 0;
   m_packetHeaderIn = (PacketHeaderIn*)m_buffer;   
   m_dataHeader = (DataHeader*)(m_buffer + sizeof(PacketHeaderIn));

   // Setup the cursors.
   m_pushCursor = m_buffer + size;
   m_popCursor = m_buffer + sizeof(PacketHeaderIn) + sizeof(DataHeader);
   
   // Initialize buffer size.
   m_bufferSize = size;

   // Set the serialzed flag to true.
   m_serialized = true;

   // Unserialize it.
   unserialize();

   // Check to see if the end of data opcode is there.
   unsigned short opcodeNumber;
   memcpy(&opcodeNumber, m_pushCursor - 4, sizeof(opcodeNumber));
   if (opcodeNumber == Ig::Opcodes::EndOfData::opcodeNumber)
      m_endOfDataPresent = true;
   else
      m_endOfDataPresent = false;


}

void Packet::serialize()
{
   // Swap the data to netowrk order.
   int* data = (int*)m_buffer;
   int start = 0;

   if (m_serialized) return;

   // If the end of data opcode has not been added, then add it.
   if (!m_endOfDataPresent)
      pushOpcode(Ig::Opcodes::EndOfData());

   // Get the starting position.
   if (m_packetHeaderOut == 0)
      start = (sizeof(PacketHeaderIn) + sizeof(DataHeader)) / 4;
   else
      start = (sizeof(PacketHeaderOut) + sizeof(DataHeader)) / 4;

   // Swap the data in the opcode block.
   for (int i=start; i<m_bufferSize/4; i++)
      data[i] = htonl(data[i]);

   m_serialized = true;
}

void Packet::unserialize()
{
   // Swap the data to host order.
   int* data = (int*)m_buffer;
   int start = 0;

   if (!m_serialized) return;

   // Get the starting position.
   if (m_packetHeaderOut == 0)
      start = (sizeof(PacketHeaderIn) + sizeof(DataHeader)) / 4;
   else
      start = (sizeof(PacketHeaderOut) + sizeof(DataHeader)) / 4;

   // If the header is in the wrong order, swap it too.
   int magicNumber = 0;
   memcpy(&magicNumber, m_buffer, sizeof(int));
   if (magicNumber == 0x70647520)
      start = 0;

   // Swap the data in the opcode block.
   for (int i=start; i<m_bufferSize/4; i++)
      data[i] = ntohl(data[i]);

   m_serialized = false;
}

void Packet::clear()
{
   int start = 0;
   // Get the starting position.
   if (m_packetHeaderOut == 0)
   {
      start = sizeof(PacketHeaderIn) + sizeof(DataHeader);
      m_packetHeaderIn->byteCount = 0;
   }
   else
   {
      start = sizeof(PacketHeaderOut) + sizeof(DataHeader);
      m_packetHeaderOut->byteCount = 0;
   }

   // Set everything after the headers to 0.
   memset(m_buffer + start, 0, 1500 - start);
   // Reset buffer size.
   m_bufferSize = start;
   // Setup the cursors.
   m_pushCursor = m_buffer + start;
   m_popCursor = m_buffer + start;
   // Reset flags.
   m_serialized = false;
   m_endOfDataPresent = false;
}

bool Packet::pushOpcode(Opcodes::Opcode& opcode)
{
   int newSize = 0;

   // Make sure there is room in the packet (and space for the end of data opcode).
   if (m_packetHeaderIn != 0)
      newSize = m_packetHeaderIn->byteCount + opcode.getBufferSize();
   else
      newSize = m_packetHeaderOut->byteCount + opcode.getBufferSize();

   // If this is not an end of data opcode then add extra padding for it.
   if (opcode.getOpcodeNumber() != Ig::Opcodes::EndOfData::opcodeNumber)
      newSize += 4;

   // If there is no room, then return false.
   if (newSize > sc_maxOpcodeBlockSize)
      return false;

   // If this in fact an end of data opcode, then set the flag to say we have added it.
   if (opcode.getOpcodeNumber() == Ig::Opcodes::EndOfData::opcodeNumber)
      m_endOfDataPresent = true;

   // Copy the opcode into the buffer
   memcpy(m_pushCursor, opcode.getBuffer(), opcode.getBufferSize());
   // Move the push cursor.
   m_pushCursor += opcode.getBufferSize();

   // Increment byte count
   if (m_packetHeaderIn != 0)
      m_packetHeaderIn->byteCount += opcode.getBufferSize();
   else
      m_packetHeaderOut->byteCount += opcode.getBufferSize();
   
   // Increment buffer size
   m_bufferSize += opcode.getBufferSize();

   return true;
}

bool Packet::popOpcode(Opcodes::Opcode& opcode)
{
   // Make sure the read cursor has not passed the write cursor.
   if (m_popCursor >= m_pushCursor) return false;

   // Get the opcode number from the cursor location.
   unsigned short opcodeNumber;
   memcpy(&opcodeNumber, m_popCursor, sizeof(opcodeNumber));
   
   // Make sure the opcode is correct.
   if (opcode.getOpcodeNumber() != opcodeNumber)
      return false;

   // Copy the buffer into the opcode.
   opcode.setBuffer(m_popCursor);

   // Move the pop cursor.
   unsigned short size;
   // If the opcode is an extended opcode, the size is stored in the data.
   if (opcodeNumber == Ig::Opcodes::ExtendedOpcode::opcodeNumber)
   {
      memcpy(&size, m_popCursor + sizeof(unsigned short), sizeof(unsigned short));
      m_popCursor += size;
   }
   else
   {
      // Get the size from the stored list of opcodes.
      size = getOpcodeSize(opcodeNumber);
      // If the size could not be found, then move the pop cursor to the end.
      if (size == 0)
      {
         m_popCursor = m_pushCursor;
         return false;
      }
      else
      {
         m_popCursor += size;
      }
   }

   return true;
}

bool Packet::popOpcode()
{
   // Make sure the read cursor has not passed the write cursor.
   if (m_popCursor >= m_pushCursor) return false;

   // Get the opcode number from the cursor location.
   unsigned short opcodeNumber;
   memcpy(&opcodeNumber, m_popCursor, sizeof(opcodeNumber));
   
   // Move the pop cursor.
   unsigned short size;
   // If the opcode is an extended opcode, the size is stored in the data.
   if (opcodeNumber == Ig::Opcodes::ExtendedOpcode::opcodeNumber)
   {
      memcpy(&size, m_popCursor + sizeof(unsigned short), sizeof(unsigned short));
      m_popCursor += size;
   }
   else
   {
      // Get the size from the stored list of opcodes.
      size = getOpcodeSize(opcodeNumber);
      // If the size could not be found, then move the pop cursor to the end.
      if (size == 0)
      {
         m_popCursor = m_pushCursor;
         return false;
      }
      else
      {
         m_popCursor += size;
      }
   }

   return true;
}


bool Packet::peekOpcode(unsigned short& opcodeNumber, unsigned short& subOpcodeA, unsigned short& subOpcodeB)
{
   // Make sure the read cursor has not passed the write cursor.
   if (m_popCursor >= m_pushCursor) return false;

   // Copy the opcode number from the buffer.
   memcpy(&opcodeNumber, m_popCursor, sizeof(opcodeNumber));

   // If it is an extended opcode, copy the sub opcodes as well.
   if (opcodeNumber == Ig::Opcodes::ExtendedOpcode::opcodeNumber)
   {
      memcpy(&subOpcodeB, m_popCursor + 8, sizeof(subOpcodeA));
      memcpy(&subOpcodeA, m_popCursor + 10, sizeof(subOpcodeB));
   }
   else
   {
      subOpcodeA = 0;
      subOpcodeB = 0;
   }
   return true;
}

int Packet::getMessageNumber()
{
   if (m_dataHeader != 0)
      return m_dataHeader->msgnum;
   else
      return 0;
}

int Packet::getStatus()
{
   if (m_dataHeader != 0)
      return m_dataHeader->status;
   else
      return 0;
}

void Packet::setStatus(int status)
{
   if (m_dataHeader != 0)
      m_dataHeader->status = status;
}

void Packet::initializeOpcodeSizes()
{
   // Setup a static boolean so this method only ever runs once.
   static bool completed = false;
   if (completed) return;

   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3000,  4)); //End Of Data
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3001,  4)); //Storm
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3002, 16)); //Ground Fog
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3004, 12)); //Cloud
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3005, 12)); //Haze Correction
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3006, 28)); //Time of Day
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3007, 12)); //Horizon
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3008,  8)); //Visibility
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3009,  8)); //Ambient
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x300A, 40)); //Storm(Advanced)
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x300C,  8)); //Defocus
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x300D, 40)); //Viewport-Specific Ambience
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x300E, 24)); //Advanced Clouds (ESIG)
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x300F, 24)); //Clouds EP
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3020,  4)); //Landing Lights (ESIG)
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3021,  4)); //Strobe
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3022,  4)); //Beacon
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3023, 12)); //Light and Polygon Intensity
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3024,  4)); //Random-Light Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3025, 24)); //Database
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3026,  8)); //Color Control Host
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3028, 12)); //Steerable Searchlight
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3029, 12)); //Noise Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x302A, 12)); //Fog Color Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x302C, 20)); //Local Lights and Polygon Intensities
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x302D, 20)); //Table Driven Texture
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3030,  4)); //Height-Above-Terrain Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3031, 20)); //Height-Above-Terrain Testpoint Request
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3032,  4)); //Height-Above-Terrain Testpoint Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3036,  4)); //Laser Range-Finder Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3037, 20)); //Laser Range-Finder Cursor
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3038,  4)); //Laser Range-Finder Cursor Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3039, 32)); //Fast-jet Collision Detection Definition
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x303C,  8)); //Laser Range-Finder Single-Response Request
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x303D, 16)); //Terrain Following Models
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3040, 32)); //Moving-Model Definition
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3041, 48)); //Moving-Model and Eyepoint Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3042, 16)); //Animation, Converging Traffic, and Bird Strike
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3043, 24)); //Viewport
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3044, 20)); //Eyepoint
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3046,  4)); //Illumination-Source Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3047, 20)); //Tracer Bullet
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3048, 36)); //Illumination-Source Definition
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3049, 16)); //Static Model Definition
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x304C, 32)); //Moving-Model Update
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x304D, 40)); //Articulated Parts Moving-Model Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x304F,  8)); //Fixed Selectable Features Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3050, 84)); //ASCII
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3052,  4)); //Video
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3057, 20)); //Viewport Visibility
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3058,  8)); //Multiple-IG Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3059,  8)); //Dgamma
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x305C,  8)); //Viewport-specific Moving Model
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3061,  8)); //IRPP Mode
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3062, 12)); //IRPP AGC/Gain/Level
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3063, 12)); //IRPP Distortion
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3064,  8)); //IRPP Polarity
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3065,  8)); //IRPP Test Pattern
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3066,  8)); //EXG Symbol Intensity
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3067, 24)); //EXG Symbol Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3068, 32)); //IR Environment
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3069, 12)); //IR Visibility Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x306A, 32)); //IRPP Configuration
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x306B,  8)); //IRPP Switches
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x306C,  8)); //IR Support Temperature
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x306D, 16)); //EXG Target Tracker Offset Track Data
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x306E, 24)); //EXG Target Tracker Turret Data
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x306F,  8)); //IRPP Viewport Control Data
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3078, 48)); //Articulated Parts Three Submodels Moving-Model Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3079,  8)); //Tracker Status
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x307A,  4)); //Tracker Mode
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x307B,  4)); //Script File
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3080, 28)); //Height Above Terrain
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3081,  8)); //Collision-Detection Response(Clouds only)
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3082, 12)); //Laser Range-Finder Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3083, 52)); //Moving-Model Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3084, 52)); //Height-Above-Terrain (ESIG)
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3085, 12)); //Host Packet Error
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3087, 48)); //Enhanced Laser Range-Finder Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x308D, 12)); //Animate Complete
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x308F, 12)); //Animate Frame Number
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3090, 36)); //Moving-Model Velocity
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3091, 36)); //Wave Equation
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3098, 12)); //Moving-Model Parameter
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3099, 36)); //Full Motion Compensation
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x309A, 32)); //Advanced Routed Traffic Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x309B,  4)); //Advanced Routed Traffic Request
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x309C,  4)); //Routed Traffic Status
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x309D,  8)); //Wind Effects
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x309E, 40)); //Generic Airport Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x309F, 12)); //Scattered Clouds
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30A2, 48)); //Articulated Parts Moving-Model Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B0,  8)); //EXG Cuer Capture Gate Parmeters
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B1, 20)); //IR Diurnal Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B3, 12)); //EXG Symbol Value
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B5,  4)); //IRPP Configuration File Select
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B6,  4)); //EXG Tracking Type Select
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B7, 20)); //EXG FOV Set
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30B8, 24)); //EXG Turret Rates
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30BA,  8)); //EXG Symbol Update
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30BB, 12)); //Target Tracker Control
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30D0, 36)); //Model Chaining
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x30D1,  8)); //Model Switch
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3132, 12)); //Advanced Routed Traffic Information Block
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3122, 28)); //Advanced Routed Traffic Route Status Block
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3130, 12)); //DI-Guy Character Type
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3131, 12)); //DI-Guy Action Type
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3132, 24)); //DI-Guy Aim Angles
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3133, 28)); //DI-Guy Model Definition
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3134, 52)); //DI-Guy Model Update
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3139, 32)); //Binocular View
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3140, 36)); //Radar Patch Request
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3184, 48)); //Collision-Detection Line Segment Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3185, 36)); //Tracker Position
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3186,  4)); //Tracker Viewport Change
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3190,  8)); //Time of Year Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3200,  8)); //IRPP Status/Mode Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3201, 16)); //EXG Symbology Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3202, 20)); //EXG Target Tracker Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3203, 12)); //IRPP Gain, Level, and Noise Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3205, 12)); //EXG Cuer Capture Gate Response
   m_opcodeSizes.insert(std::pair<unsigned short, int>(0x3206, 36)); //TargetTracker Response

   completed = true;
}

int Packet::getOpcodeSize(unsigned int opcodeNumber)
{
   // Search the map for the opcode.
   std::map<unsigned short, int>::iterator iter;
   iter = m_opcodeSizes.find(opcodeNumber);
   // If we found it then return the size.
   if (iter != m_opcodeSizes.end())
      return iter->second;
   // Otherwise return 0.
   else
      return 0;
}