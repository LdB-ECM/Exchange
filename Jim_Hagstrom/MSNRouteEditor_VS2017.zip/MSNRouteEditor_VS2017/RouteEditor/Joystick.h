//*****************************************************************************
//*****                            UNCLASSIFIED                           *****
//*****************************************************************************
/** 
* @file
* This is the Joystick Class definition. This class provides the ability to
* handle a standard USB joystick.
*/

#pragma once

/** This is the joystick class. */
class Joystick
{

public:

   /** Defines the Joystick POV(HAT) position. */
   enum JoystickPov
   {
      e_JoyPovForward,
      e_JoyPovBackward,
      e_JoyPovLeft,
      e_JoyPovRight,
      e_JoyPovCentered,
   };

   /** Constructor. */
   Joystick();
   /** Destructor. */
   virtual ~Joystick();

   /** Check the joystick input. This must be called to
   * update the joystick data. Call this before using
   * the accessors.
   */
   void checkInput();

   /** Get the X axis value.
   * -1 means the Joystick is all the way to the left.
   *  1 means the Joystick is all the way to the right.
   *  0 means the Joystick is centered.
   * @return The X axis value.
   */
   inline double getXAxis() { return m_xAxis; }     

   /** Get the T axis value.
   * -1 means the Joystick is all the way to the front.
   *  1 means the Joystick is all the way to the back.
   *  0 means the Joystick is centered.
   * @return The Y axis value.
   */
   inline double getYAxis() { return m_yAxis; }      

   /** Get the Z axis value. Z is generally used as a
   * throttle control.
   * -1 means the throttle is all the way foward.
   *  1 means the throttle is all the way backward.
   *  0 means the throttle is centered.
   * @return The Z axis value.
   */
   inline double getZAxis() { return m_zAxis; }

   /** Get the R axis value. R is used to do various things
   * but generally it is used for the rudder.
   * -1 means the Joystick is twisted all the way to the left.
   *  1 means the Joystick is twisted all the way to the right.
   *  0 means the Joystick is not twisted.
   * @return The Z axis value.
   */
   inline double getRAxis() { return m_rAxis; }

   /** Get the Joystick Pov(HAT) position.
   * @return The position.
   */
   inline JoystickPov getPov() { return m_pov; }

   /** Get the state of a button.
   * @param button The button to check.
   */
   bool getButton(unsigned int button);

   /** Get the number of buttons on the joystick. 
   * @return The number of buttons.
   */
   inline unsigned int getButtonCount() { return m_buttonCount; }

   /** Set the area around the center of an axis that does
   * not respond to input. A value of .1 would ignore .1 to 
   * the left and right of center. If the axis value is smaller
   * than this size then the value in the axis will be set to 0.
   * @param size The area to ignore. 
   */
   inline void setDeadZone(double size) { m_deadZone = size; }

   inline bool getHasPov() { return m_hasPov; }
   inline bool getHasZ() { return m_hasZ; }
   inline bool getHasR() { return m_hasR; }

   /** Is the joystick connected.
   * @param True if the joystick is connected.
   */
   inline bool isConnected() { return m_connected; }

private:

   bool* m_buttons;
   unsigned int m_buttonCount;

   /** What does the joystick have. */
   bool m_hasPov;
   bool m_hasZ;
   bool m_hasR;


   /** Is the joystick connected. */
   bool m_connected;
   /** Joystick POV(HAT) position. */
   JoystickPov m_pov;

   /** Joystick Ranges */
   unsigned int m_xMax;
   unsigned int m_xMin;
   unsigned int m_yMax;
   unsigned int m_yMin;
   unsigned int m_zMax;
   unsigned int m_zMin;
   unsigned int m_rMax;
   unsigned int m_rMin;

   /** Joystick X axis */
   double m_xAxis;
   /** Joystick Y axis */
   double m_yAxis;
   /** Joystick Z axis */
   double m_zAxis;
   /** Joystick R axis */
   double m_rAxis;

   /** Dead Zone */
   double m_deadZone;
};

