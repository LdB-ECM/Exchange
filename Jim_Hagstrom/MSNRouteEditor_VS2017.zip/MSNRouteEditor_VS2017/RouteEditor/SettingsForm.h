#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace RouteEditor {

	/// <summary>
	/// Summary for SettingsForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class SettingsForm : public System::Windows::Forms::Form
	{
	public:
		SettingsForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}


      void setMaxVelocity(System::Double value) { this->textBoxMaxVelocity->Text = System::Convert::ToString(value); }
      System::Double getMaxVelocity() { return System::Convert::ToDouble(this->textBoxMaxVelocity->Text); }

      void setMaxAngularVelocity(System::Double value) { this->textBoxMaxAngularVelocity->Text = System::Convert::ToString(value); }
      System::Double getMaxAngularVelocity() { return System::Convert::ToDouble(this->textBoxMaxAngularVelocity->Text); }

      void setDeadZone(System::Double value) { this->textBoxDeadZone->Text = System::Convert::ToString(value); }
      System::Double getDeadZone() { return System::Convert::ToDouble(this->textBoxDeadZone->Text); }

      void setModelFilename(System::String^ value) { this->textBoxModelFilename->Text = value; }
      System::String^ getModelFilename() { return this->textBoxModelFilename->Text; }

      void setLatitude(System::Double value) { this->textBoxLatitude->Text = System::Convert::ToString(value); }
      System::Double getLatitude() { return System::Convert::ToDouble(this->textBoxLatitude->Text); }

      void setLongitude(System::Double value) { this->textBoxLongitude->Text = System::Convert::ToString(value); }
      System::Double getLongitude() { return System::Convert::ToDouble(this->textBoxLongitude->Text); }

      void setAltitude(System::Double value) { this->textBoxAltitude->Text = System::Convert::ToString(value); }
      System::Double getAltitude() { return System::Convert::ToDouble(this->textBoxAltitude->Text); }

      void setHeading(System::Double value) { this->textBoxHeading->Text = System::Convert::ToString(value); }
      System::Double getHeading() { return System::Convert::ToDouble(this->textBoxHeading->Text); }

   protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~SettingsForm()
		{
			if (components)
			{
				delete components;
			}
		}
   private: System::Windows::Forms::Button^  buttonOK;
   private: System::Windows::Forms::Button^  buttonCancel;
   private: System::Windows::Forms::Label^  labelMaxVelocity;

   private: System::Windows::Forms::TextBox^  textBoxMaxVelocity;
   private: System::Windows::Forms::GroupBox^  groupBoxJoystick;
   private: System::Windows::Forms::Label^  label1;
   private: System::Windows::Forms::TextBox^  textBoxMaxAngularVelocity;

   private: System::Windows::Forms::GroupBox^  groupBox1;
   private: System::Windows::Forms::TextBox^  textBoxModelFilename;


   private: System::Windows::Forms::Label^  label2;
   private: System::Windows::Forms::TextBox^  textBoxDeadZone;
   private: System::Windows::Forms::GroupBox^  groupBox2;
   private: System::Windows::Forms::Label^  label6;
   private: System::Windows::Forms::Label^  label7;
   private: System::Windows::Forms::Label^  label8;
   private: System::Windows::Forms::Label^  label5;
   private: System::Windows::Forms::Label^  label4;
   private: System::Windows::Forms::Label^  label3;
   private: System::Windows::Forms::TextBox^  textBoxHeading;
   private: System::Windows::Forms::TextBox^  textBoxAltitude;
   private: System::Windows::Forms::TextBox^  textBoxLongitude;
   private: System::Windows::Forms::TextBox^  textBoxLatitude;





   protected: 


   protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
         this->buttonOK = (gcnew System::Windows::Forms::Button());
         this->buttonCancel = (gcnew System::Windows::Forms::Button());
         this->labelMaxVelocity = (gcnew System::Windows::Forms::Label());
         this->textBoxMaxVelocity = (gcnew System::Windows::Forms::TextBox());
         this->groupBoxJoystick = (gcnew System::Windows::Forms::GroupBox());
         this->textBoxDeadZone = (gcnew System::Windows::Forms::TextBox());
         this->label2 = (gcnew System::Windows::Forms::Label());
         this->textBoxMaxAngularVelocity = (gcnew System::Windows::Forms::TextBox());
         this->label1 = (gcnew System::Windows::Forms::Label());
         this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
         this->textBoxHeading = (gcnew System::Windows::Forms::TextBox());
         this->label8 = (gcnew System::Windows::Forms::Label());
         this->textBoxAltitude = (gcnew System::Windows::Forms::TextBox());
         this->label5 = (gcnew System::Windows::Forms::Label());
         this->textBoxLongitude = (gcnew System::Windows::Forms::TextBox());
         this->label4 = (gcnew System::Windows::Forms::Label());
         this->textBoxLatitude = (gcnew System::Windows::Forms::TextBox());
         this->label3 = (gcnew System::Windows::Forms::Label());
         this->textBoxModelFilename = (gcnew System::Windows::Forms::TextBox());
         this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
         this->groupBoxJoystick->SuspendLayout();
         this->groupBox1->SuspendLayout();
         this->groupBox2->SuspendLayout();
         this->SuspendLayout();
         // 
         // buttonOK
         // 
         this->buttonOK->Location = System::Drawing::Point(86, 280);
         this->buttonOK->Name = L"buttonOK";
         this->buttonOK->Size = System::Drawing::Size(75, 23);
         this->buttonOK->TabIndex = 0;
         this->buttonOK->Text = L"OK";
         this->buttonOK->UseVisualStyleBackColor = true;
         this->buttonOK->Click += gcnew System::EventHandler(this, &SettingsForm::buttonOK_Click);
         // 
         // buttonCancel
         // 
         this->buttonCancel->Location = System::Drawing::Point(167, 280);
         this->buttonCancel->Name = L"buttonCancel";
         this->buttonCancel->Size = System::Drawing::Size(75, 23);
         this->buttonCancel->TabIndex = 1;
         this->buttonCancel->Text = L"Cancel";
         this->buttonCancel->UseVisualStyleBackColor = true;
         this->buttonCancel->Click += gcnew System::EventHandler(this, &SettingsForm::buttonCancel_Click);
         // 
         // labelMaxVelocity
         // 
         this->labelMaxVelocity->AutoSize = true;
         this->labelMaxVelocity->Location = System::Drawing::Point(6, 16);
         this->labelMaxVelocity->Name = L"labelMaxVelocity";
         this->labelMaxVelocity->Size = System::Drawing::Size(70, 13);
         this->labelMaxVelocity->TabIndex = 2;
         this->labelMaxVelocity->Text = L"Max Velocity:";
         // 
         // textBoxMaxVelocity
         // 
         this->textBoxMaxVelocity->Location = System::Drawing::Point(9, 32);
         this->textBoxMaxVelocity->Name = L"textBoxMaxVelocity";
         this->textBoxMaxVelocity->Size = System::Drawing::Size(100, 20);
         this->textBoxMaxVelocity->TabIndex = 0;
         // 
         // groupBoxJoystick
         // 
         this->groupBoxJoystick->Controls->Add(this->textBoxDeadZone);
         this->groupBoxJoystick->Controls->Add(this->label2);
         this->groupBoxJoystick->Controls->Add(this->textBoxMaxAngularVelocity);
         this->groupBoxJoystick->Controls->Add(this->label1);
         this->groupBoxJoystick->Controls->Add(this->textBoxMaxVelocity);
         this->groupBoxJoystick->Controls->Add(this->labelMaxVelocity);
         this->groupBoxJoystick->Location = System::Drawing::Point(12, 12);
         this->groupBoxJoystick->Name = L"groupBoxJoystick";
         this->groupBoxJoystick->Size = System::Drawing::Size(230, 101);
         this->groupBoxJoystick->TabIndex = 2;
         this->groupBoxJoystick->TabStop = false;
         this->groupBoxJoystick->Text = L"Joystick Settings";
         // 
         // textBoxDeadZone
         // 
         this->textBoxDeadZone->Location = System::Drawing::Point(122, 32);
         this->textBoxDeadZone->Name = L"textBoxDeadZone";
         this->textBoxDeadZone->Size = System::Drawing::Size(100, 20);
         this->textBoxDeadZone->TabIndex = 2;
         // 
         // label2
         // 
         this->label2->AutoSize = true;
         this->label2->Location = System::Drawing::Point(119, 16);
         this->label2->Name = L"label2";
         this->label2->Size = System::Drawing::Size(64, 13);
         this->label2->TabIndex = 6;
         this->label2->Text = L"Dead Zone:";
         // 
         // textBoxMaxAngularVelocity
         // 
         this->textBoxMaxAngularVelocity->Location = System::Drawing::Point(9, 72);
         this->textBoxMaxAngularVelocity->Name = L"textBoxMaxAngularVelocity";
         this->textBoxMaxAngularVelocity->Size = System::Drawing::Size(100, 20);
         this->textBoxMaxAngularVelocity->TabIndex = 1;
         // 
         // label1
         // 
         this->label1->AutoSize = true;
         this->label1->Location = System::Drawing::Point(6, 55);
         this->label1->Name = L"label1";
         this->label1->Size = System::Drawing::Size(109, 13);
         this->label1->TabIndex = 4;
         this->label1->Text = L"Max Angular Velocity:";
         // 
         // groupBox1
         // 
         this->groupBox1->Controls->Add(this->textBoxHeading);
         this->groupBox1->Controls->Add(this->label8);
         this->groupBox1->Controls->Add(this->textBoxAltitude);
         this->groupBox1->Controls->Add(this->label5);
         this->groupBox1->Controls->Add(this->textBoxLongitude);
         this->groupBox1->Controls->Add(this->label4);
         this->groupBox1->Controls->Add(this->textBoxLatitude);
         this->groupBox1->Controls->Add(this->label3);
         this->groupBox1->Location = System::Drawing::Point(12, 119);
         this->groupBox1->Name = L"groupBox1";
         this->groupBox1->Size = System::Drawing::Size(230, 102);
         this->groupBox1->TabIndex = 3;
         this->groupBox1->TabStop = false;
         this->groupBox1->Text = L"Starting Position";
         // 
         // textBoxHeading
         // 
         this->textBoxHeading->Location = System::Drawing::Point(122, 71);
         this->textBoxHeading->Name = L"textBoxHeading";
         this->textBoxHeading->Size = System::Drawing::Size(100, 20);
         this->textBoxHeading->TabIndex = 3;
         // 
         // label8
         // 
         this->label8->AutoSize = true;
         this->label8->Location = System::Drawing::Point(119, 55);
         this->label8->Name = L"label8";
         this->label8->Size = System::Drawing::Size(50, 13);
         this->label8->TabIndex = 10;
         this->label8->Text = L"Heading:";
         // 
         // textBoxAltitude
         // 
         this->textBoxAltitude->Location = System::Drawing::Point(122, 32);
         this->textBoxAltitude->Name = L"textBoxAltitude";
         this->textBoxAltitude->Size = System::Drawing::Size(100, 20);
         this->textBoxAltitude->TabIndex = 2;
         // 
         // label5
         // 
         this->label5->AutoSize = true;
         this->label5->Location = System::Drawing::Point(119, 16);
         this->label5->Name = L"label5";
         this->label5->Size = System::Drawing::Size(45, 13);
         this->label5->TabIndex = 8;
         this->label5->Text = L"Altitude:";
         // 
         // textBoxLongitude
         // 
         this->textBoxLongitude->Location = System::Drawing::Point(9, 71);
         this->textBoxLongitude->Name = L"textBoxLongitude";
         this->textBoxLongitude->Size = System::Drawing::Size(100, 20);
         this->textBoxLongitude->TabIndex = 1;
         // 
         // label4
         // 
         this->label4->AutoSize = true;
         this->label4->Location = System::Drawing::Point(6, 55);
         this->label4->Name = L"label4";
         this->label4->Size = System::Drawing::Size(57, 13);
         this->label4->TabIndex = 6;
         this->label4->Text = L"Longitude:";
         // 
         // textBoxLatitude
         // 
         this->textBoxLatitude->Location = System::Drawing::Point(9, 32);
         this->textBoxLatitude->Name = L"textBoxLatitude";
         this->textBoxLatitude->Size = System::Drawing::Size(100, 20);
         this->textBoxLatitude->TabIndex = 0;
         // 
         // label3
         // 
         this->label3->AutoSize = true;
         this->label3->Location = System::Drawing::Point(6, 16);
         this->label3->Name = L"label3";
         this->label3->Size = System::Drawing::Size(48, 13);
         this->label3->TabIndex = 4;
         this->label3->Text = L"Latitude:";
         // 
         // textBoxModelFilename
         // 
         this->textBoxModelFilename->Location = System::Drawing::Point(9, 19);
         this->textBoxModelFilename->Name = L"textBoxModelFilename";
         this->textBoxModelFilename->Size = System::Drawing::Size(213, 20);
         this->textBoxModelFilename->TabIndex = 0;
         // 
         // groupBox2
         // 
         this->groupBox2->Controls->Add(this->textBoxModelFilename);
         this->groupBox2->Location = System::Drawing::Point(12, 227);
         this->groupBox2->Name = L"groupBox2";
         this->groupBox2->Size = System::Drawing::Size(230, 47);
         this->groupBox2->TabIndex = 4;
         this->groupBox2->TabStop = false;
         this->groupBox2->Text = L"Model Filename:";
         // 
         // SettingsForm
         // 
         this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
         this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
         this->ClientSize = System::Drawing::Size(254, 310);
         this->Controls->Add(this->groupBox2);
         this->Controls->Add(this->groupBox1);
         this->Controls->Add(this->groupBoxJoystick);
         this->Controls->Add(this->buttonCancel);
         this->Controls->Add(this->buttonOK);
         this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
         this->MaximizeBox = false;
         this->MinimizeBox = false;
         this->Name = L"SettingsForm";
         this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
         this->Text = L"Settings";
         this->groupBoxJoystick->ResumeLayout(false);
         this->groupBoxJoystick->PerformLayout();
         this->groupBox1->ResumeLayout(false);
         this->groupBox1->PerformLayout();
         this->groupBox2->ResumeLayout(false);
         this->groupBox2->PerformLayout();
         this->ResumeLayout(false);

      }
#pragma endregion
   private:

      // OK Button Clicked
      System::Void buttonOK_Click(System::Object^  sender, System::EventArgs^  e) 
      {
         // Double check values.
         if (System::String::IsNullOrEmpty(this->textBoxMaxVelocity->Text))
         {
            System::Windows::Forms::MessageBox::Show("Error in max velocity. Invalid value.", "Error",
               System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            return;
         }
         else
         {
            try
            {
               double maxVelocity = Convert::ToDouble(this->textBoxMaxVelocity->Text);
               if (maxVelocity <= 0)
               {
                  System::Windows::Forms::MessageBox::Show("Error in max velocity. Invalid value.", "Error",
                     System::Windows::Forms::MessageBoxButtons::OK,
                     System::Windows::Forms::MessageBoxIcon::Error);
                  return;
               }

            }
            catch (...)
            {
               System::Windows::Forms::MessageBox::Show("Error in max velocity. Invalid value.", "Error",
                  System::Windows::Forms::MessageBoxButtons::OK,
                  System::Windows::Forms::MessageBoxIcon::Error);
               return;
            }

         }

         // Double check values.
         if (System::String::IsNullOrEmpty(this->textBoxMaxAngularVelocity->Text))
         {
            System::Windows::Forms::MessageBox::Show("Error in max angular velocity. Invalid value.", "Error",
               System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            return;
         }
         else
         {
            try
            {
               double maxVelocity = Convert::ToDouble(this->textBoxMaxAngularVelocity->Text);
               if (maxVelocity <= 0)
               {
                  System::Windows::Forms::MessageBox::Show("Error in max angular velocity. Invalid value.", "Error",
                     System::Windows::Forms::MessageBoxButtons::OK,
                     System::Windows::Forms::MessageBoxIcon::Error);
                  return;
               }

            }
            catch (...)
            {
               System::Windows::Forms::MessageBox::Show("Error in max angular velocity. Invalid value.", "Error",
                  System::Windows::Forms::MessageBoxButtons::OK,
                  System::Windows::Forms::MessageBoxIcon::Error);
               return;
            }

         }

         if (System::String::IsNullOrEmpty(this->textBoxLatitude->Text))
         {
            System::Windows::Forms::MessageBox::Show("Error in latitude. Invalid value.", "Error",
               System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            return;
         }
         else
         {
            try
            {
               double latitude = Convert::ToDouble(this->textBoxLatitude->Text);
               if (latitude < -90 || latitude > 90)
               {
                  System::Windows::Forms::MessageBox::Show("Error in latitude. Invalid value.", "Error",
                     System::Windows::Forms::MessageBoxButtons::OK,
                     System::Windows::Forms::MessageBoxIcon::Error);
                  return;
               }

            }
            catch (...)
            {
               System::Windows::Forms::MessageBox::Show("Error in latitude. Invalid value.", "Error",
                  System::Windows::Forms::MessageBoxButtons::OK,
                  System::Windows::Forms::MessageBoxIcon::Error);
               return;
            }

         }

         if (System::String::IsNullOrEmpty(this->textBoxLongitude->Text))
         {
            System::Windows::Forms::MessageBox::Show("Error in longitude. Invalid value.", "Error",
               System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            return;
         }
         else
         {
            try
            {
               double longitude = Convert::ToDouble(this->textBoxLongitude->Text);
               if (longitude < -180 || longitude > 180)
               {
                  System::Windows::Forms::MessageBox::Show("Error in longitude. Invalid value.", "Error",
                     System::Windows::Forms::MessageBoxButtons::OK,
                     System::Windows::Forms::MessageBoxIcon::Error);
                  return;
               }

            }
            catch (...)
            {
               System::Windows::Forms::MessageBox::Show("Error in longitude. Invalid value.", "Error",
                  System::Windows::Forms::MessageBoxButtons::OK,
                  System::Windows::Forms::MessageBoxIcon::Error);
               return;
            }

         }

         if (System::String::IsNullOrEmpty(this->textBoxAltitude->Text))
         {
            System::Windows::Forms::MessageBox::Show("Error in altitude. Invalid value.", "Error",
               System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            return;
         }
         else
         {
            try
            {
               double altitude = Convert::ToDouble(this->textBoxAltitude->Text);
            }
            catch (...)
            {
               System::Windows::Forms::MessageBox::Show("Error in altitude. Invalid value.", "Error",
                  System::Windows::Forms::MessageBoxButtons::OK,
                  System::Windows::Forms::MessageBoxIcon::Error);
               return;
            }

         }

         if (System::String::IsNullOrEmpty(this->textBoxHeading->Text))
         {
            System::Windows::Forms::MessageBox::Show("Error in heading. Invalid value.", "Error",
               System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            return;
         }
         else
         {
            try
            {
               double heading = Convert::ToDouble(this->textBoxHeading->Text);
               if (heading < -180 || heading > 180)
               {
                  System::Windows::Forms::MessageBox::Show("Error in heading. Invalid value.", "Error",
                     System::Windows::Forms::MessageBoxButtons::OK,
                     System::Windows::Forms::MessageBoxIcon::Error);
                  return;
               }

            }
            catch (...)
            {
               System::Windows::Forms::MessageBox::Show("Error in heading. Invalid value.", "Error",
                  System::Windows::Forms::MessageBoxButtons::OK,
                  System::Windows::Forms::MessageBoxIcon::Error);
               return;
            }

         }


         this->DialogResult = System::Windows::Forms::DialogResult::OK;
         this->Close();
      }

      // Cancel Clicked
      System::Void buttonCancel_Click(System::Object^  sender, System::EventArgs^  e) 
      {
         this->DialogResult = System::Windows::Forms::DialogResult::Cancel;
         this->Close();
      }

   private: System::Void SettingsForm_Load(System::Object^  sender, System::EventArgs^  e) {
            }
};
}
