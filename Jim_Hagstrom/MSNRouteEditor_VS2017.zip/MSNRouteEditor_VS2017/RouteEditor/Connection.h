#pragma once

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <winsock2.h>               // for winsock
#pragma comment(lib, "ws2_32.lib")  // for winsock
#include <windows.h>                // because we have to...
#include <process.h>                // for _beginthreadex
#include <deque>
#include <string>
#include <map>
#include <set>

namespace Ig
{
   // Forward Declare the Opcode class.
   namespace Opcodes
   {
      class Opcode;
   };

   /** Critical Section Utility Class. */
   class CriticalSection
   {
   public:
      /** Constructor. */
      CriticalSection();
      /** Destructor. */
      virtual ~CriticalSection();

      /** Lock the critical section. */
      void lock();

      /** Unlock the critical section. */
      void unlock();

   private:

      /** Critical section. */
      CRITICAL_SECTION m_criticalSection;

   };

   /** The connection class maintains a connection to the Ig. */
   class Connection
   {
   public:

      /** Enumeration to define the current connection state. */
      enum ConnectionState
      {
         /** Offline. */
         offline,
         /** Connecting to the Ig. */
         connecting,
         /** Loading models and motion systems. */
         loading,
         /** Waiting for the Ig to finish. */
         waiting,
         /** Running normally. */
         running,
         /** Unloading everything. */
         unloading,
         /** Disconnecting. */
         disconnecting,
      };

      /** Defines the position of a model. */
      struct Position
      {
         /* Latitude of the model. */
         double latitude;
         /* Longitude of the model. */
         double longitude;
         /* Altitude of the model. */
         double altitude;
         /* Heading of the model. */
         double heading;
         /* Pitch of the model. */
         double pitch;
         /* Roll of the model. */
         double roll;

         /** Constructor. */
         Position() : latitude(0), longitude(0), altitude(0),
            heading(0), pitch(0), roll(0) {};
      };

      /** Defines the velocity of a model. */
      struct Velocity
      {
         /* X velocity of the model. */
         double x;
         /* Y velocity of the model. */
         double y;
         /* Z velocity of the model. */
         double z;
         /* Heading velocity of the model. */
         double heading;
         /* Pitch velocity of the model. */
         double pitch;
         /* Roll velocity of the model. */
         double roll;

         /** Constructor. */
         Velocity() : x(0), y(0), z(0), 
            heading(0), pitch(0), roll(0) {}
      };

   public:
      /** Constructor. */
      Connection();
      /** Destructor. */
      ~Connection();

      /** Open the connection.
      * @return True if the connection was opened, false if an error occured.
      * @param ip The ip address to connect to.
      * @param port The port to send data to.
      * @param timeOut The amount of time to wait before timing out.
      */
      bool open(const char* ip, const int port, const int timeOut = 5000);

      /** Close the connection. 
      * @param immediate Close the connection without cleaning up.
      */
      void close(bool immediate = false);

      /** Load a model.
      * @param slot The slot to load the model in.
      * @param filename The model to load.
      */
      void loadModel(int slot, const char* filename);

      /** Unload the model
      * @param slot The slot to unload.
      */
      void unloadModel(int slot);

      /** Bind an instance of the model to a motion system.
      * @param motionSystem The motion system to bind to.
      * @param slot The slot holding the model.
      */
      void bindModel(int motionSystem, int slot);

      /** Unbind an instance of a model.
      * @param motionSystem The model number to unbind.
      */
      void unbindModel(int motionSystem);

      /** Unbind all models. */
      void unbindAllModels();

      /** Set the parent motion system of a model.
      * @param int motionSystem The instance of the model.
      * @param int parentMotionSystem The parent motionSystem.
      */
      void setModelParent(int motionSystem, int parentMotionSystem);

      /** Set the position of a model.
      * @param motionSystem The instance of the model.
      * @param position The position of the model.
      */
      void setModelPosition(int motionSystem, const Connection::Position& position);

      /** Get the position of a model.
      * @return The position of the model.
      * @param motionSystem The instance of the model.
      */
      Position getModelPosition(int motionSystem);

      /** Set the velocity of a model.
      * @param motionSystem The instance of the model.
      * @param velocity The velocity of the model.
      */
      void setModelVelocity(int motionSystem, const Connection::Velocity& velocity);

      /** Set the select of a model.
      * @param motionSystem The instance of the model.
      * @param modelSelect the select of the model.
      */
      void setModelSelect(int motionSystem, int modelSelect);

      /** Set the terrain following state of a model.
      * @param motionSystem The instance of the model.
      * @param enable True to enable terrain following, false to disable.
      */
      void setModelTerrainFollowing(int motionSystem, bool enable);

      /** Get the state of the terrain following flag for a model.
      * @return True if terrain following is turned on.
      * @param motionSystem The instance of the model.
      */
      bool getModelTerrainFollowing(int motionSystem);

      /** Send a cli command to the Ig.
      * @param command The command to send.
      */
      void sendCliCommand(const char command[80]);

      /** Initiate a request for a model position.
      * @param The motion system to ask for.
      */
      void requestModelPosition(int motionSystem);

      /** Get the next available motion system number. 
      * @return The next available motion system number.      
      */
      int getNextAvailableMotionSystem();

      /** Set the current connection state.
      * @return The current state of the connection.
      */
      ConnectionState getState();


   protected:



      /** Defines a motion system (an instance of a model). */
      struct MotionSystem
      {
         /** The model to bind to. */
         int model;
         /** The position of the model. */
         Position position;
         /** The velocity of the model. */
         Velocity velocity;
         /** The model select. */
         int select;
         /** The terrain following state. */
         bool terrainFollowing;
         /** The motion system is bound. */
         bool bound;
         /** The parent motion system. */
         int parentMotionSystem;

         /** Constructor. */
         MotionSystem() : model(0), select(1), 
            terrainFollowing(false), bound(false), 
            parentMotionSystem(1) {}
      };

      /** Defines what has changed in a motion system. */
      struct MotionSystemChange
      {
         /** Indicates change to the bind state of the motion system. */
         bool bind;
         /** Indicates change to the position of the motion system. */
         bool position;
         /** Indicates change to the velocity of the motion system. */
         bool velocity;
         /** Indicates change to the terrain following state of the motion system. */
         bool terrainFollowing;
         /** Indicates a changeg to the parent motion system. */
         bool parent;

         /** Constructor. */
         MotionSystemChange(bool bindChanged = false, 
            bool positionChanged = false,
            bool velocityChanged = false,
            bool terrainFollowingChanged = false,
            bool parentChanged = false)
         {
            bind = bindChanged;
            position = positionChanged;
            velocity = velocityChanged;
            terrainFollowing = terrainFollowingChanged;
            parent = parentChanged;
         }
      };

   protected:
      
      /** Set the current connection state.
      * @param state The state to switch to.
      */
      void setState(ConnectionState state);

      /** Get the timeout value. 
      * @return The timeout value.
      */
      int getTimeOut();

      /** Returns true if the IG is finished loading.
      * @return True if the IG is finished loading, false otherwise.
      */
      bool getFinishedLoading();

      /** Set the state of the IG loading flag.
      * @param finished The state if the IG loading flag.
      */
      void setFinishedLoading(bool finished);

      /** Returns true if the IG has restuarted.
      * @return True if the IG has restarted.
      */
      bool getRestarted();

      /** Set the state of the restarted flag.
      * @param True if the IG has restarted.
      */
      void setRestarted(bool restarted);

      /** Push an opcode onto the queue. 
      * @param opcode The opcode to add to the queue.
      */
      void pushOpcode(Ig::Opcodes::Opcode* opcode);

      /** Post a model change for processing.
      * @param number The model number.
      * @param load True to load the model, false to unload.
      */
      void postModelChange(int number, bool load = true);

      /** Post a motion system change for processing. 
      * @param number The motion system number.
      * @param bind Process a bind change.
      * @param position Process a position change.
      * @param velocity Process a velocity change.
      * @param terrainFollowing Process a terrain following change.
      * @param parent Process a change to the parent motion system.
      */
      void postMotionSystemChange(int number, bool bind = false, 
         bool position = false, bool velocity = false, 
         bool terrainFollowing = false, bool parent = false);

      /** Post a motion system request for processing.
      * @param number The motion system number.
      */
      void postMotionSystemRequest(int number);

      /** Send data thread function. */
      static uintptr_t __stdcall sendData(void* param);
      /** Receive data thread function. */
      static uintptr_t __stdcall receiveData(void* param);

      /** Exits the threads. */
      void exitThreads();

      /** Clear any pending opcodes. */
      void clearPendingOpcodes();
      /** Send any opcodes that are still pending. */
      void sendPendingOpcodes();

      /** Returns true if there are pending opcodes.
      * @return True if there are pending opcodes.
      */
      bool hasPendingOpcodes();

      /** Push a load status request onto the queue. */
      void pushLoadStatusRequest();

      /** Clear any model changes. */
      void clearModelChanges();
      /** Clear any motion system changes. */
      void clearMotionSystemChanges();
      /** Clear any motion system requests. */
      void clearMotionSystemRequests();

      /** Process model changes. */
      void processModelChanges();
      /** Process motion system changes. */
      void processMotionSystemChanges();
      /** Process motion system requests. */
      void processMotionSystemRequests();


      /** Process the connecting state. */
      void processConnectingState();
      /** Process the loading state. */
      void processLoadingState();
      /** Process the waiting state. */
      void processWaitingState();
      /** Process the running state. */
      void processRunningState();
      /** Process the unloading state. */
      void processUnloadingState();
      /** Process the disconnecting state. */
      void processDisconnectingState();

      /** Process the reinitalize state. */
      void processReinitialize();

      /** Process a response from the IG.
      * @param buffer The buffer of data.
      * @param size The size of the buffer.
      */
      void processResponse(char* buffer, int size);


   private:

      /** Thread to send data. */
      HANDLE m_sendThread;
      /** Thread to receive data. */
      HANDLE m_receiveThread;
      /** Unique id of the send thread. */
      unsigned int m_sendThreadId;
      /** Unique id of the receive thread. */
      unsigned int m_receiveThreadId;

      // Critical Sections.

      /** Critical Section to protect the opcodes queue. */
      CriticalSection m_csOpcodes;
      /** Critical Section to protect the motion system changes. */
      CriticalSection m_csMotionSystemChanges;
      /** Critical Section to protect the motion system requests. */
      CriticalSection m_csMotionSystemRequests;
      /** Critical Section to protect the model changes. */
      CriticalSection m_csModelChanges;
      /** Critical Section to protect the models list. */
      CriticalSection m_csModels;
      /** Critical Section to protect the motion system list. */
      CriticalSection m_csMotionSystems;
      /** Critical Section to protect the state variable. */
      CriticalSection m_csState;
      /** Critical Section to protect the timeOut variable. */
      CriticalSection m_csTimeOut;
      /** Critical Section to protect the finished loading flag. */
      CriticalSection m_csFinishedLoading;
      /** Critical Section to protect the restarted flag. */
      CriticalSection m_csRestarted;

  
      /** Socket for sending data. */
      SOCKET m_sendSocket;
      /** Socket for receiving data. */
      SOCKET m_receiveSocket;
      /** Address for sending data. */
      sockaddr_in m_sendAddress;
      /** Address for receivind data. */
      sockaddr_in m_receiveAddress;
      /** Port to send data. */
      int m_sendPort;
      /** Port to receive data. */
      int m_receivePort;

      /** Amount of time to wait before a timeout. (1000 = 1 second) */
      int m_timeOut;

      /** Indicates the ig is done loading. */
      bool m_finishedLoading;

      /** The starting motion system. */
      int m_motionSystemStart;
      /** The ending motion system. */
      int m_motionSystemEnd;

      /** The current connection state. */
      ConnectionState m_state;
      /** Flag to indicate that the Ig has restarted. */
      bool m_restarted;

      /** Map of motion system changes to process. */
      std::map<int, MotionSystemChange> m_motionSystemChanges;
      /** Set of motion sytem requests. */
      std::set<int> m_motionSystemRequests;
      /** Map of model changes to process. */
      std::map<int, bool> m_modelChanges;

      /** Queue of opcodes to send. */
      std::deque<Ig::Opcodes::Opcode*> m_opcodes;

      /** Map of models. */
      std::map<int, std::string> m_models;

      /** Map of motion systems (instances of models). */
      std::map<int, MotionSystem> m_motionSystems;
   };
}