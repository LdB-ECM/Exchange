#pragma once
#include <map>

namespace Ig
{
   namespace Opcodes
   {
      class Opcode;
   }

   class Packet
   {
   public:

      /** Constructor to setup an outgoing packet. */
      Packet(int messageNumber, int status);

      /** Constructor to setup an incoming packet. */
      Packet(char* buffer, int size);

      /** Push an opcode onto the back of a packet. 
      * @return True on success, false of the packet is full. 
      * @param opcode The opcode to push.
      */
      bool pushOpcode(Opcodes::Opcode& opcode);

      /** Pop an opcode from the front of the packet.
      * @return True on success, false if there are no more opcodes.
      * @param opcode Where to copy the opcode to.
      */
      bool popOpcode(Opcodes::Opcode& opcode);

      /** Pop an opcode from the front of the packet.
      * @return True on success, false if there are no more opcodes.
      */
      bool popOpcode();


      /** Get the number of the next opcode to pop from the packet. 
      * If the opcode is an extended opcode, then it will also fill subOpcodeA and subOpcodeB.
      * @return True on success, false if no more opcodes exist.
      * @param opcodeNumber Where to store the opcode number of the next opcode in the packet.
      * @param subOpcodeA Where to store the sub opcode A.
      * @param subOpcodeB Where to store the sub opcode B.
      */
      bool peekOpcode(unsigned short& opcodeNumber, unsigned short& subOpcodeA, unsigned short& subOpcodeB);

      /** Serialize the packet into network byte order. */
      void serialize();

      /** Unserialize the packet into host byte order. */
      void unserialize();

      /** Get the data in the buffer. 
      * @return A pointer to the data in the buffer.
      */
      char* getBuffer() { return m_buffer; }

      /** Get the size of the buffer.
      * @return The size of the buffer.
      */
      int getBufferSize() { return m_bufferSize; }

      /** Clear the packet.  */
      void clear();

      /** Get the message number of the packet. 
      * @return The message number of the packet.
      */
      int getMessageNumber();
      
      /** Get the status of the message. 
      * @return The status of the message.
      */
      int getStatus();

      /** Set the status of the message.
      * @param status The status.
      */
      void setStatus(int status);

   public:

      /** Max size of the data in the opcode block. */
      static const unsigned int sc_maxOpcodeBlockSize = 1468;
      
      // Host Status Constants

      /** normal host packet with data. */
      static const unsigned int sc_normalHostData = 0x0;
      /** normal host packet without data. */
      static const unsigned int sc_normalNoHostData = 0x1;
      /** request with host data. */
      static const unsigned int sc_requestDataHostData = 0x2;
      /** request with no host data. */
      static const unsigned int sc_requestDataNoHostData = 0x03;
      /** acknowledge a host restart with data. */
      static const unsigned int sc_restartAckHostData = 0x4;
      /** acknowledge a host restart and request data. */
      static const unsigned int sc_restartAckRequestDataHostData = 0x6;

      // IG Status Constants

      /** Normal acknowldegement, no data. */
      static const unsigned int sc_normalAckNoIgData = 0x0;
      /** Normal acknowledgement with data. */
      static const unsigned int sc_normalAckIgData = 0x2;
      /** IG was restarted, no data. */
      static const unsigned int sc_igRestartedNoData = 0x4;
      /** IG was restarted with data. */
      static const unsigned int sc_igRestartedData = 0x6;
      /** IG sync. */
      static const unsigned int sc_igSync = 0xffffffff;

   protected:

      /** Packet Header for Incoming Data. */
      struct PacketHeaderIn
      {
         int magicNumber;
         int byteCount;
         int reserved;
      }; 

      /** Packet Header for Outgoing Data. */
      struct PacketHeaderOut
      {
         int magicNumber;
         int byteCount;
         int seconds;
         int microseconds;
         int reserved;
      }; 

      /** Data Header. */
      struct DataHeader
      {
         int msgnum;
         int status;
         int unused;
      };

   protected:
      
      /** Initialize the map of opcode sizes. */
      void initializeOpcodeSizes();

      /** Get the size of an opcode. 
      * @return The opcode size (0 if not found).
      * @param The opcode number to lookup.
      */
      int getOpcodeSize(unsigned int opcodeNumber);

   private:
      /** The buffer of data. */
      char m_buffer[1500];
      /** The current size of the buffer. */
      int m_bufferSize;
      /** A pointer to the write location into the buffer. */
      char* m_pushCursor;
      /** A pointer to the read location into the buffer. */
      char* m_popCursor;

      // Map of the opcode sizes.
      static std::map<unsigned short, int> m_opcodeSizes;

      // Pointers to structures within the buffer.

      /** Pointer to the data header section of the buffer. */
      DataHeader* m_dataHeader;
      /** Pointer to the packet header section for an incoming packet. */
      PacketHeaderIn* m_packetHeaderIn;
      /** Pointer to the packet header section for an outgoing packet. */
      PacketHeaderOut* m_packetHeaderOut;

      /** Flag to indicate if the packet has been serialized. */
      bool m_serialized;
      /** Flag to indicate that the end of data opcode has been added. */
      bool m_endOfDataPresent;
   };
}