#pragma once

#include "Connection.h"
#include <string>

// Forward Declarations.
class Joystick;

namespace RouteEditor {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MainForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class MainForm : public System::Windows::Forms::Form
	{
	public:

      /** Constructor. */
		MainForm(void);

      /** Create a new file. */
      System::Void newFile();
      /** Show the Open File Dialog window. */
      System::Void openFile();
      /** Show the Save As File Dialog window. */
      System::Void saveAsFile();
      /** Save the current file. */
      System::Void saveFile();

      /** Open a file in the csv format.
      * @return True on success, false on failure.
      * @param filename The path of the file to open.
      */
      System::Boolean openCsvFile(System::String^ filename);

      /** Open a file in the rtd format.
      * @return True on success, false on failure.
      * @param filename The path of the file to open.
      */
      System::Boolean openRtdFile(System::String^ filename);

      /** Save the current file in csv format.
      * @return True on success, false on failure.
      * @param filename The path of the file to save.
      */
      System::Boolean saveCsvFile(System::String^ filename);

      /** Save the current file in rtd format.
      * @return True on success, false on failure.
      * @param filename The path of the file to save.
      */
      System::Boolean saveRtdFile(System::String^ filename);

      /** Save changes to the current file. The Save As Dialog
      * will show if a filename has not been specified yet.
      * @return OK on sucess, Cancel if the user cancels the save.
      */
      System::Windows::Forms::DialogResult saveChanges();

      /** Get the name of the file
      * @return The name of the current file.
      */
      System::String^ getFileName() { return m_filename; }

      /** Update the title bar to show filename and save status. */
      System::Void updateTitle();

      /** Add a waypoint. */
      System::Void addWaypoint();
      /** Update the current waypoint. */
      System::Void updateWaypoint();
      /** Delete the current waypoint. */
      System::Void deleteWaypoint();

      /** Cut the currently selected waypoints. */
      System::Void cut();
      /** Copy the currently selected waypoints. */
      System::Void copy();
      /** Paste data from the clipboard. */
      System::Void paste();

      /** Copy the data from the currently selected cells up. */
      System::Void fillUp();
      /** Copy the data from the currently selected cells down. */
      System::Void fillDown();


      /** Load the user's settings from a file. */
      System::Void loadSettings();
      /** Save the user's settings to a file. */
      System::Void saveSettings();


      /** Connect to the Ig. */
      System::Void connect();
      /** Disconnect from the Ig. */
      System::Void disconnect();

      /** Convert a System::String to an std::string.
      * @return The string in std::string format.
      * @param s The string to convert.
      */
      std::string toStdString(System::String^ s);

      /** Disable editing of the location bar. */
      System::Void disableLocationBar();
      /** Enable editing of the location bar. */
      System::Void enableLocationBar();

      /** Copy data from the data grid to the Ig.
      * @param row The row number in the data grid to copy.
      */
      System::Void dataGridRowToWaypoint(int row);

   
      /** Copy data from the data grid to the Ig.
      * @param row The row number in the data grid to copy.
      */
      System::Void dataGridRowToMotionSystem(int row, int motionSystem);

      /** Chain the eyepoint. */
      System::Void chain();

      /** Unchain the eyepoint. */
      System::Void unchain();

      // Do not edit below here...

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MainForm();

   private:
      Ig::Connection* m_igConnection;

      System::String^ m_filename;
      System::Boolean m_saved;
      System::Double m_maxVelocity;
      System::Double m_maxAngularVelocity;
      System::Double m_deadZone;
      System::String^ m_modelFilename;
      System::Int32 m_cursorMotionSystem;
      System::Int32 m_eyepointMotionSystem;
      Joystick* m_joystick;
      System::Double m_startLatitude;
      System::Double m_startLongitude;
      System::Double m_startAltitude;
      System::Double m_startHeading;


   private: System::Windows::Forms::MenuStrip^  menuStrip;
   private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  editToolStripMenuItem;
   private: System::Windows::Forms::ToolStripContainer^  toolStripContainer;
   private: System::Windows::Forms::ToolStrip^  toolStripMain;

   private: System::Windows::Forms::ToolStripMenuItem^  toolsToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  newToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  openToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  saveToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  saveAsToolStripMenuItem;
   private: System::Windows::Forms::ToolStripSeparator^  toolStripMenuItem1;
   private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
   private: System::Windows::Forms::DataGridView^  dataGridView;
   private: System::Windows::Forms::StatusStrip^  statusStrip;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonNew;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonOpen;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonSave;
   private: System::Windows::Forms::OpenFileDialog^  openFileDialog;
   private: System::Windows::Forms::SaveFileDialog^  saveFileDialog;
   private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonCut;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonCopy;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonPaste;
   private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator2;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonNewRecord;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonUpdateRecord;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonDeleteRecord;
   private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator3;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonFillUp;
   private: System::Windows::Forms::ToolStripButton^  toolStripButtonFillDown;

   private: System::Windows::Forms::ToolStripMenuItem^  cutToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  copyToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  pasteToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  deleteToolStripMenuItem;
   private: System::Windows::Forms::ToolStripSeparator^  toolStripMenuItem2;
   private: System::Windows::Forms::ToolStripMenuItem^  selectAllToolStripMenuItem;

   private: System::Windows::Forms::ToolStrip^  toolStripConnect;

   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelIP;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxIP;
   private: System::Windows::Forms::ToolStripLabel^  labelPort;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxPort;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonConnect;


   private: System::Windows::Forms::ToolStripStatusLabel^  statusLabel;

   private: System::Windows::Forms::ToolStripStatusLabel^  connectionStatusLabel;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Latitude;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Longitude;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Altitude;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Heading;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Pitch;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Roll;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  Speed;
   private: System::Windows::Forms::DataGridViewComboBoxColumn^  Units;
   private: System::Windows::Forms::DataGridViewComboBoxColumn^  TerrainFollowing;
   private: System::Windows::Forms::DataGridViewTextBoxColumn^  TurnRadius;
   private: System::Windows::Forms::ToolStripMenuItem^  settingsToolStripMenuItem;
   private: System::Windows::Forms::ToolStrip^  toolStripLocation;

   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelLatitude;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxLatitude;
   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelLongitude;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxLongitude;
   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelAltitude;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxAltitude;
   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelHeading;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxHeading;

   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelPitch;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxPitch;

   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelRoll;
   private: System::Windows::Forms::ToolStripTextBox^  textBoxRoll;
   private: System::Windows::Forms::ToolStripLabel^  toolStripLabelTerrainFollowing;
   private: System::Windows::Forms::ToolStripComboBox^  dropDownTerrain;
   private: System::Windows::Forms::ToolStripMenuItem^  viewToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  toolbarsToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  standardToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  connectionToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  locationToolStripMenuItem;
   private: System::Windows::Forms::ToolStripSeparator^  toolStripMenuItem3;
   private: System::Windows::Forms::ToolStripMenuItem^  statusBarToolStripMenuItem;
   private: System::Windows::Forms::Timer^  timer;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonUpdateLocation;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonDisconnect;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonOK;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonCancel;
private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator4;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonEyepoint;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonCursor;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonChain;
private: System::Windows::Forms::ToolStripButton^  toolStripButtonUnchain;
private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator5;
private: System::Windows::Forms::ToolStrip^  toolStripCommand;
private: System::Windows::Forms::ToolStripLabel^  toolStripLabel1;
private: System::Windows::Forms::ToolStripTextBox^  textBoxCommand;


private: System::Windows::Forms::ToolStripButton^  toolStripButtonExecute;
private: System::Windows::Forms::ToolStripMenuItem^  commandToolStripMenuItem;
private: System::Windows::Forms::Timer^  timerJoystick;
private: System::Windows::Forms::Timer^  timerLocation;






   private: System::ComponentModel::IContainer^  components;







	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
         this->components = (gcnew System::ComponentModel::Container());
         System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MainForm::typeid));
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle10 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle11 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle5 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle6 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle7 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle8 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle9 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
         this->menuStrip = (gcnew System::Windows::Forms::MenuStrip());
         this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->newToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->saveToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->saveAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->editToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->cutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->copyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->pasteToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->deleteToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->toolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->selectAllToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->viewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->toolbarsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->standardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->connectionToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->locationToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->commandToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->toolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->statusBarToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->toolsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->settingsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
         this->toolStripContainer = (gcnew System::Windows::Forms::ToolStripContainer());
         this->toolStripLocation = (gcnew System::Windows::Forms::ToolStrip());
         this->toolStripLabelLatitude = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxLatitude = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripLabelLongitude = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxLongitude = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripLabelAltitude = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxAltitude = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripLabelHeading = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxHeading = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripLabelPitch = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxPitch = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripLabelRoll = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxRoll = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripLabelTerrainFollowing = (gcnew System::Windows::Forms::ToolStripLabel());
         this->dropDownTerrain = (gcnew System::Windows::Forms::ToolStripComboBox());
         this->toolStripButtonUpdateLocation = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonOK = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonCancel = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripSeparator4 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->toolStripButtonEyepoint = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonCursor = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripSeparator5 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->toolStripButtonUnchain = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonChain = (gcnew System::Windows::Forms::ToolStripButton());
         this->statusStrip = (gcnew System::Windows::Forms::StatusStrip());
         this->statusLabel = (gcnew System::Windows::Forms::ToolStripStatusLabel());
         this->connectionStatusLabel = (gcnew System::Windows::Forms::ToolStripStatusLabel());
         this->dataGridView = (gcnew System::Windows::Forms::DataGridView());
         this->Latitude = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Longitude = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Altitude = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Heading = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Pitch = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Roll = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Speed = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->Units = (gcnew System::Windows::Forms::DataGridViewComboBoxColumn());
         this->TerrainFollowing = (gcnew System::Windows::Forms::DataGridViewComboBoxColumn());
         this->TurnRadius = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
         this->toolStripMain = (gcnew System::Windows::Forms::ToolStrip());
         this->toolStripButtonNew = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonOpen = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonSave = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->toolStripButtonCut = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonCopy = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonPaste = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->toolStripButtonNewRecord = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonUpdateRecord = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonDeleteRecord = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripSeparator3 = (gcnew System::Windows::Forms::ToolStripSeparator());
         this->toolStripButtonFillUp = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonFillDown = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripConnect = (gcnew System::Windows::Forms::ToolStrip());
         this->toolStripLabelIP = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxIP = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->labelPort = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxPort = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripButtonConnect = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripButtonDisconnect = (gcnew System::Windows::Forms::ToolStripButton());
         this->toolStripCommand = (gcnew System::Windows::Forms::ToolStrip());
         this->toolStripLabel1 = (gcnew System::Windows::Forms::ToolStripLabel());
         this->textBoxCommand = (gcnew System::Windows::Forms::ToolStripTextBox());
         this->toolStripButtonExecute = (gcnew System::Windows::Forms::ToolStripButton());
         this->openFileDialog = (gcnew System::Windows::Forms::OpenFileDialog());
         this->saveFileDialog = (gcnew System::Windows::Forms::SaveFileDialog());
         this->timer = (gcnew System::Windows::Forms::Timer(this->components));
         this->timerJoystick = (gcnew System::Windows::Forms::Timer(this->components));
         this->timerLocation = (gcnew System::Windows::Forms::Timer(this->components));
         this->menuStrip->SuspendLayout();
         this->toolStripContainer->BottomToolStripPanel->SuspendLayout();
         this->toolStripContainer->ContentPanel->SuspendLayout();
         this->toolStripContainer->TopToolStripPanel->SuspendLayout();
         this->toolStripContainer->SuspendLayout();
         this->toolStripLocation->SuspendLayout();
         this->statusStrip->SuspendLayout();
         (cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView))->BeginInit();
         this->toolStripMain->SuspendLayout();
         this->toolStripConnect->SuspendLayout();
         this->toolStripCommand->SuspendLayout();
         this->SuspendLayout();
         // 
         // menuStrip
         // 
         this->menuStrip->BackColor = System::Drawing::SystemColors::Control;
         this->menuStrip->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
         this->menuStrip->GripStyle = System::Windows::Forms::ToolStripGripStyle::Visible;
         this->menuStrip->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->fileToolStripMenuItem, 
            this->editToolStripMenuItem, this->viewToolStripMenuItem, this->toolsToolStripMenuItem});
         this->menuStrip->Location = System::Drawing::Point(0, 0);
         this->menuStrip->Name = L"menuStrip";
         this->menuStrip->Size = System::Drawing::Size(922, 24);
         this->menuStrip->TabIndex = 0;
         this->menuStrip->Text = L"menuStrip";
         // 
         // fileToolStripMenuItem
         // 
         this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->newToolStripMenuItem, 
            this->openToolStripMenuItem, this->saveToolStripMenuItem, this->saveAsToolStripMenuItem, this->toolStripMenuItem1, this->exitToolStripMenuItem});
         this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
         this->fileToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::F));
         this->fileToolStripMenuItem->Size = System::Drawing::Size(35, 20);
         this->fileToolStripMenuItem->Text = L"File";
         // 
         // newToolStripMenuItem
         // 
         this->newToolStripMenuItem->Name = L"newToolStripMenuItem";
         this->newToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::N));
         this->newToolStripMenuItem->Size = System::Drawing::Size(163, 22);
         this->newToolStripMenuItem->Text = L"New";
         this->newToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::newToolStripMenuItem_Click);
         // 
         // openToolStripMenuItem
         // 
         this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
         this->openToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::O));
         this->openToolStripMenuItem->Size = System::Drawing::Size(163, 22);
         this->openToolStripMenuItem->Text = L"Open...";
         this->openToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::openToolStripMenuItem_Click);
         // 
         // saveToolStripMenuItem
         // 
         this->saveToolStripMenuItem->Name = L"saveToolStripMenuItem";
         this->saveToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::S));
         this->saveToolStripMenuItem->Size = System::Drawing::Size(163, 22);
         this->saveToolStripMenuItem->Text = L"Save";
         this->saveToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::saveToolStripMenuItem_Click);
         // 
         // saveAsToolStripMenuItem
         // 
         this->saveAsToolStripMenuItem->Name = L"saveAsToolStripMenuItem";
         this->saveAsToolStripMenuItem->Size = System::Drawing::Size(163, 22);
         this->saveAsToolStripMenuItem->Text = L"Save As...";
         this->saveAsToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::saveAsToolStripMenuItem_Click);
         // 
         // toolStripMenuItem1
         // 
         this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
         this->toolStripMenuItem1->Size = System::Drawing::Size(160, 6);
         // 
         // exitToolStripMenuItem
         // 
         this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
         this->exitToolStripMenuItem->Size = System::Drawing::Size(163, 22);
         this->exitToolStripMenuItem->Text = L"Exit";
         this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::exitToolStripMenuItem_Click);
         // 
         // editToolStripMenuItem
         // 
         this->editToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->cutToolStripMenuItem, 
            this->copyToolStripMenuItem, this->pasteToolStripMenuItem, this->deleteToolStripMenuItem, this->toolStripMenuItem2, this->selectAllToolStripMenuItem});
         this->editToolStripMenuItem->Name = L"editToolStripMenuItem";
         this->editToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::E));
         this->editToolStripMenuItem->Size = System::Drawing::Size(37, 20);
         this->editToolStripMenuItem->Text = L"Edit";
         // 
         // cutToolStripMenuItem
         // 
         this->cutToolStripMenuItem->Name = L"cutToolStripMenuItem";
         this->cutToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::X));
         this->cutToolStripMenuItem->Size = System::Drawing::Size(167, 22);
         this->cutToolStripMenuItem->Text = L"Cut";
         this->cutToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::cutToolStripMenuItem_Click);
         // 
         // copyToolStripMenuItem
         // 
         this->copyToolStripMenuItem->Name = L"copyToolStripMenuItem";
         this->copyToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::C));
         this->copyToolStripMenuItem->Size = System::Drawing::Size(167, 22);
         this->copyToolStripMenuItem->Text = L"Copy";
         this->copyToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::copyToolStripMenuItem_Click);
         // 
         // pasteToolStripMenuItem
         // 
         this->pasteToolStripMenuItem->Name = L"pasteToolStripMenuItem";
         this->pasteToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::V));
         this->pasteToolStripMenuItem->Size = System::Drawing::Size(167, 22);
         this->pasteToolStripMenuItem->Text = L"Paste";
         this->pasteToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::pasteToolStripMenuItem_Click);
         // 
         // deleteToolStripMenuItem
         // 
         this->deleteToolStripMenuItem->Name = L"deleteToolStripMenuItem";
         this->deleteToolStripMenuItem->Size = System::Drawing::Size(167, 22);
         this->deleteToolStripMenuItem->Text = L"Delete";
         this->deleteToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::deleteToolStripMenuItem_Click);
         // 
         // toolStripMenuItem2
         // 
         this->toolStripMenuItem2->Name = L"toolStripMenuItem2";
         this->toolStripMenuItem2->Size = System::Drawing::Size(164, 6);
         // 
         // selectAllToolStripMenuItem
         // 
         this->selectAllToolStripMenuItem->Name = L"selectAllToolStripMenuItem";
         this->selectAllToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::A));
         this->selectAllToolStripMenuItem->Size = System::Drawing::Size(167, 22);
         this->selectAllToolStripMenuItem->Text = L"Select All";
         this->selectAllToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::selectAllToolStripMenuItem_Click);
         // 
         // viewToolStripMenuItem
         // 
         this->viewToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->toolbarsToolStripMenuItem, 
            this->toolStripMenuItem3, this->statusBarToolStripMenuItem});
         this->viewToolStripMenuItem->Name = L"viewToolStripMenuItem";
         this->viewToolStripMenuItem->Size = System::Drawing::Size(41, 20);
         this->viewToolStripMenuItem->Text = L"View";
         // 
         // toolbarsToolStripMenuItem
         // 
         this->toolbarsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->standardToolStripMenuItem, 
            this->connectionToolStripMenuItem, this->locationToolStripMenuItem, this->commandToolStripMenuItem});
         this->toolbarsToolStripMenuItem->Name = L"toolbarsToolStripMenuItem";
         this->toolbarsToolStripMenuItem->Size = System::Drawing::Size(135, 22);
         this->toolbarsToolStripMenuItem->Text = L"Toolbars";
         // 
         // standardToolStripMenuItem
         // 
         this->standardToolStripMenuItem->Checked = true;
         this->standardToolStripMenuItem->CheckOnClick = true;
         this->standardToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
         this->standardToolStripMenuItem->Name = L"standardToolStripMenuItem";
         this->standardToolStripMenuItem->Size = System::Drawing::Size(139, 22);
         this->standardToolStripMenuItem->Text = L"Standard";
         this->standardToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &MainForm::standardToolStripMenuItem_CheckedChanged);
         // 
         // connectionToolStripMenuItem
         // 
         this->connectionToolStripMenuItem->Checked = true;
         this->connectionToolStripMenuItem->CheckOnClick = true;
         this->connectionToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
         this->connectionToolStripMenuItem->Name = L"connectionToolStripMenuItem";
         this->connectionToolStripMenuItem->Size = System::Drawing::Size(139, 22);
         this->connectionToolStripMenuItem->Text = L"Connection";
         this->connectionToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &MainForm::connectionToolStripMenuItem_CheckedChanged);
         // 
         // locationToolStripMenuItem
         // 
         this->locationToolStripMenuItem->Checked = true;
         this->locationToolStripMenuItem->CheckOnClick = true;
         this->locationToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
         this->locationToolStripMenuItem->Name = L"locationToolStripMenuItem";
         this->locationToolStripMenuItem->Size = System::Drawing::Size(139, 22);
         this->locationToolStripMenuItem->Text = L"Location";
         this->locationToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &MainForm::locationToolStripMenuItem_CheckedChanged);
         // 
         // commandToolStripMenuItem
         // 
         this->commandToolStripMenuItem->Checked = true;
         this->commandToolStripMenuItem->CheckOnClick = true;
         this->commandToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
         this->commandToolStripMenuItem->Name = L"commandToolStripMenuItem";
         this->commandToolStripMenuItem->Size = System::Drawing::Size(139, 22);
         this->commandToolStripMenuItem->Text = L"Command";
         this->commandToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::commandToolStripMenuItem_Click);
         // 
         // toolStripMenuItem3
         // 
         this->toolStripMenuItem3->Name = L"toolStripMenuItem3";
         this->toolStripMenuItem3->Size = System::Drawing::Size(132, 6);
         // 
         // statusBarToolStripMenuItem
         // 
         this->statusBarToolStripMenuItem->Checked = true;
         this->statusBarToolStripMenuItem->CheckOnClick = true;
         this->statusBarToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
         this->statusBarToolStripMenuItem->Name = L"statusBarToolStripMenuItem";
         this->statusBarToolStripMenuItem->Size = System::Drawing::Size(135, 22);
         this->statusBarToolStripMenuItem->Text = L"Status Bar";
         this->statusBarToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &MainForm::statusBarToolStripMenuItem_CheckedChanged);
         // 
         // toolsToolStripMenuItem
         // 
         this->toolsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->settingsToolStripMenuItem});
         this->toolsToolStripMenuItem->Name = L"toolsToolStripMenuItem";
         this->toolsToolStripMenuItem->Size = System::Drawing::Size(44, 20);
         this->toolsToolStripMenuItem->Text = L"Tools";
         // 
         // settingsToolStripMenuItem
         // 
         this->settingsToolStripMenuItem->Name = L"settingsToolStripMenuItem";
         this->settingsToolStripMenuItem->Size = System::Drawing::Size(136, 22);
         this->settingsToolStripMenuItem->Text = L"Settings...";
         this->settingsToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::settingsToolStripMenuItem_Click);
         // 
         // toolStripContainer
         // 
         // 
         // toolStripContainer.BottomToolStripPanel
         // 
         this->toolStripContainer->BottomToolStripPanel->Controls->Add(this->toolStripLocation);
         this->toolStripContainer->BottomToolStripPanel->Controls->Add(this->statusStrip);
         // 
         // toolStripContainer.ContentPanel
         // 
         this->toolStripContainer->ContentPanel->Controls->Add(this->dataGridView);
         this->toolStripContainer->ContentPanel->Size = System::Drawing::Size(922, 431);
         this->toolStripContainer->Dock = System::Windows::Forms::DockStyle::Fill;
         this->toolStripContainer->Location = System::Drawing::Point(0, 24);
         this->toolStripContainer->Name = L"toolStripContainer";
         this->toolStripContainer->Size = System::Drawing::Size(922, 503);
         this->toolStripContainer->TabIndex = 1;
         this->toolStripContainer->Text = L"toolStripContainer1";
         // 
         // toolStripContainer.TopToolStripPanel
         // 
         this->toolStripContainer->TopToolStripPanel->Controls->Add(this->toolStripMain);
         this->toolStripContainer->TopToolStripPanel->Controls->Add(this->toolStripConnect);
         this->toolStripContainer->TopToolStripPanel->Controls->Add(this->toolStripCommand);
         // 
         // toolStripLocation
         // 
         this->toolStripLocation->Dock = System::Windows::Forms::DockStyle::None;
         this->toolStripLocation->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(23) {this->toolStripLabelLatitude, 
            this->textBoxLatitude, this->toolStripLabelLongitude, this->textBoxLongitude, this->toolStripLabelAltitude, this->textBoxAltitude, 
            this->toolStripLabelHeading, this->textBoxHeading, this->toolStripLabelPitch, this->textBoxPitch, this->toolStripLabelRoll, this->textBoxRoll, 
            this->toolStripLabelTerrainFollowing, this->dropDownTerrain, this->toolStripButtonUpdateLocation, this->toolStripButtonOK, this->toolStripButtonCancel, 
            this->toolStripSeparator4, this->toolStripButtonEyepoint, this->toolStripButtonCursor, this->toolStripSeparator5, this->toolStripButtonUnchain, 
            this->toolStripButtonChain});
         this->toolStripLocation->Location = System::Drawing::Point(3, 0);
         this->toolStripLocation->Name = L"toolStripLocation";
         this->toolStripLocation->Size = System::Drawing::Size(846, 25);
         this->toolStripLocation->TabIndex = 2;
         // 
         // toolStripLabelLatitude
         // 
         this->toolStripLabelLatitude->Name = L"toolStripLabelLatitude";
         this->toolStripLabelLatitude->Size = System::Drawing::Size(26, 22);
         this->toolStripLabelLatitude->Text = L"Lat:";
         this->toolStripLabelLatitude->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // textBoxLatitude
         // 
         this->textBoxLatitude->Enabled = false;
         this->textBoxLatitude->Name = L"textBoxLatitude";
         this->textBoxLatitude->Size = System::Drawing::Size(75, 25);
         // 
         // toolStripLabelLongitude
         // 
         this->toolStripLabelLongitude->Name = L"toolStripLabelLongitude";
         this->toolStripLabelLongitude->Size = System::Drawing::Size(28, 22);
         this->toolStripLabelLongitude->Text = L"Lon:";
         this->toolStripLabelLongitude->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // textBoxLongitude
         // 
         this->textBoxLongitude->Enabled = false;
         this->textBoxLongitude->Name = L"textBoxLongitude";
         this->textBoxLongitude->Size = System::Drawing::Size(75, 25);
         // 
         // toolStripLabelAltitude
         // 
         this->toolStripLabelAltitude->Name = L"toolStripLabelAltitude";
         this->toolStripLabelAltitude->Size = System::Drawing::Size(24, 22);
         this->toolStripLabelAltitude->Text = L"Alt:";
         this->toolStripLabelAltitude->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // textBoxAltitude
         // 
         this->textBoxAltitude->Enabled = false;
         this->textBoxAltitude->Name = L"textBoxAltitude";
         this->textBoxAltitude->Size = System::Drawing::Size(50, 25);
         // 
         // toolStripLabelHeading
         // 
         this->toolStripLabelHeading->Name = L"toolStripLabelHeading";
         this->toolStripLabelHeading->Size = System::Drawing::Size(50, 22);
         this->toolStripLabelHeading->Text = L"Heading:";
         this->toolStripLabelHeading->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // textBoxHeading
         // 
         this->textBoxHeading->Enabled = false;
         this->textBoxHeading->Name = L"textBoxHeading";
         this->textBoxHeading->Size = System::Drawing::Size(50, 25);
         // 
         // toolStripLabelPitch
         // 
         this->toolStripLabelPitch->Name = L"toolStripLabelPitch";
         this->toolStripLabelPitch->Size = System::Drawing::Size(34, 22);
         this->toolStripLabelPitch->Text = L"Pitch:";
         this->toolStripLabelPitch->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // textBoxPitch
         // 
         this->textBoxPitch->Enabled = false;
         this->textBoxPitch->Name = L"textBoxPitch";
         this->textBoxPitch->Size = System::Drawing::Size(50, 25);
         // 
         // toolStripLabelRoll
         // 
         this->toolStripLabelRoll->Name = L"toolStripLabelRoll";
         this->toolStripLabelRoll->Size = System::Drawing::Size(28, 22);
         this->toolStripLabelRoll->Text = L"Roll:";
         this->toolStripLabelRoll->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // textBoxRoll
         // 
         this->textBoxRoll->Enabled = false;
         this->textBoxRoll->Name = L"textBoxRoll";
         this->textBoxRoll->Size = System::Drawing::Size(50, 25);
         // 
         // toolStripLabelTerrainFollowing
         // 
         this->toolStripLabelTerrainFollowing->Name = L"toolStripLabelTerrainFollowing";
         this->toolStripLabelTerrainFollowing->Size = System::Drawing::Size(78, 22);
         this->toolStripLabelTerrainFollowing->Text = L"Terrain Follow:";
         this->toolStripLabelTerrainFollowing->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // dropDownTerrain
         // 
         this->dropDownTerrain->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
         this->dropDownTerrain->Enabled = false;
         this->dropDownTerrain->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"on", L"off"});
         this->dropDownTerrain->Name = L"dropDownTerrain";
         this->dropDownTerrain->Size = System::Drawing::Size(75, 25);
         // 
         // toolStripButtonUpdateLocation
         // 
         this->toolStripButtonUpdateLocation->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonUpdateLocation->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonUpdateLocation.Image")));
         this->toolStripButtonUpdateLocation->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonUpdateLocation->Name = L"toolStripButtonUpdateLocation";
         this->toolStripButtonUpdateLocation->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonUpdateLocation->Text = L"Edit Location";
         this->toolStripButtonUpdateLocation->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonUpdateLocation_Click);
         // 
         // toolStripButtonOK
         // 
         this->toolStripButtonOK->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonOK->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonOK.Image")));
         this->toolStripButtonOK->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonOK->Name = L"toolStripButtonOK";
         this->toolStripButtonOK->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonOK->Text = L"OK";
         this->toolStripButtonOK->Visible = false;
         this->toolStripButtonOK->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonOK_Click);
         // 
         // toolStripButtonCancel
         // 
         this->toolStripButtonCancel->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonCancel->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonCancel.Image")));
         this->toolStripButtonCancel->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonCancel->Name = L"toolStripButtonCancel";
         this->toolStripButtonCancel->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonCancel->Text = L"Cancel";
         this->toolStripButtonCancel->Visible = false;
         this->toolStripButtonCancel->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonCancel_Click);
         // 
         // toolStripSeparator4
         // 
         this->toolStripSeparator4->Name = L"toolStripSeparator4";
         this->toolStripSeparator4->Size = System::Drawing::Size(6, 25);
         // 
         // toolStripButtonEyepoint
         // 
         this->toolStripButtonEyepoint->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonEyepoint->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonEyepoint.Image")));
         this->toolStripButtonEyepoint->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonEyepoint->Name = L"toolStripButtonEyepoint";
         this->toolStripButtonEyepoint->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonEyepoint->Text = L"Viewing Location";
         this->toolStripButtonEyepoint->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonEyepoint_Click);
         // 
         // toolStripButtonCursor
         // 
         this->toolStripButtonCursor->Checked = true;
         this->toolStripButtonCursor->CheckState = System::Windows::Forms::CheckState::Checked;
         this->toolStripButtonCursor->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonCursor->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonCursor.Image")));
         this->toolStripButtonCursor->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonCursor->Name = L"toolStripButtonCursor";
         this->toolStripButtonCursor->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonCursor->Text = L"Cursor Location";
         this->toolStripButtonCursor->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonCursor_Click);
         // 
         // toolStripSeparator5
         // 
         this->toolStripSeparator5->Name = L"toolStripSeparator5";
         this->toolStripSeparator5->Size = System::Drawing::Size(6, 25);
         // 
         // toolStripButtonUnchain
         // 
         this->toolStripButtonUnchain->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonUnchain->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonUnchain.Image")));
         this->toolStripButtonUnchain->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonUnchain->Name = L"toolStripButtonUnchain";
         this->toolStripButtonUnchain->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonUnchain->Text = L"Unchain View from Cursor";
         this->toolStripButtonUnchain->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonUnchain_Click);
         // 
         // toolStripButtonChain
         // 
         this->toolStripButtonChain->Checked = true;
         this->toolStripButtonChain->CheckState = System::Windows::Forms::CheckState::Checked;
         this->toolStripButtonChain->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonChain->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonChain.Image")));
         this->toolStripButtonChain->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonChain->Name = L"toolStripButtonChain";
         this->toolStripButtonChain->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonChain->Text = L"Chain View to Cursor";
         this->toolStripButtonChain->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonChain_Click);
         // 
         // statusStrip
         // 
         this->statusStrip->Dock = System::Windows::Forms::DockStyle::None;
         this->statusStrip->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->statusLabel, this->connectionStatusLabel});
         this->statusStrip->Location = System::Drawing::Point(0, 25);
         this->statusStrip->Name = L"statusStrip";
         this->statusStrip->Size = System::Drawing::Size(922, 22);
         this->statusStrip->TabIndex = 1;
         this->statusStrip->Text = L"statusStrip1";
         // 
         // statusLabel
         // 
         this->statusLabel->Name = L"statusLabel";
         this->statusLabel->Size = System::Drawing::Size(785, 17);
         this->statusLabel->Spring = true;
         this->statusLabel->Text = L"Waypoint: None selected.";
         this->statusLabel->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
         // 
         // connectionStatusLabel
         // 
         this->connectionStatusLabel->BorderSides = System::Windows::Forms::ToolStripStatusLabelBorderSides::Left;
         this->connectionStatusLabel->Name = L"connectionStatusLabel";
         this->connectionStatusLabel->Size = System::Drawing::Size(122, 17);
         this->connectionStatusLabel->Text = L"IG Connection: Offline.";
         // 
         // dataGridView
         // 
         this->dataGridView->AllowUserToResizeRows = false;
         this->dataGridView->BorderStyle = System::Windows::Forms::BorderStyle::None;
         dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
         dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Control;
         dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
            System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
         dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::WindowText;
         dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::Highlight;
         dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
         dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
         this->dataGridView->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
         this->dataGridView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
         this->dataGridView->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(10) {this->Latitude, 
            this->Longitude, this->Altitude, this->Heading, this->Pitch, this->Roll, this->Speed, this->Units, this->TerrainFollowing, this->TurnRadius});
         dataGridViewCellStyle10->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
         dataGridViewCellStyle10->BackColor = System::Drawing::SystemColors::Window;
         dataGridViewCellStyle10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
            System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
         dataGridViewCellStyle10->ForeColor = System::Drawing::SystemColors::ControlText;
         dataGridViewCellStyle10->SelectionBackColor = System::Drawing::SystemColors::Highlight;
         dataGridViewCellStyle10->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
         dataGridViewCellStyle10->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
         this->dataGridView->DefaultCellStyle = dataGridViewCellStyle10;
         this->dataGridView->Dock = System::Windows::Forms::DockStyle::Fill;
         this->dataGridView->Location = System::Drawing::Point(0, 0);
         this->dataGridView->Name = L"dataGridView";
         dataGridViewCellStyle11->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
         dataGridViewCellStyle11->BackColor = System::Drawing::SystemColors::Control;
         dataGridViewCellStyle11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, 
            System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
         dataGridViewCellStyle11->ForeColor = System::Drawing::SystemColors::WindowText;
         dataGridViewCellStyle11->NullValue = nullptr;
         dataGridViewCellStyle11->SelectionBackColor = System::Drawing::SystemColors::Highlight;
         dataGridViewCellStyle11->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
         dataGridViewCellStyle11->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
         this->dataGridView->RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
         this->dataGridView->Size = System::Drawing::Size(922, 431);
         this->dataGridView->TabIndex = 0;
         this->dataGridView->CellValueChanged += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MainForm::dataGridView_CellValueChanged);
         this->dataGridView->RowEnter += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MainForm::dataGridView_RowEnter);
         this->dataGridView->CellDoubleClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MainForm::dataGridView_CellDoubleClick);
         this->dataGridView->RowLeave += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MainForm::dataGridView_RowLeave);
         this->dataGridView->RowHeaderMouseDoubleClick += gcnew System::Windows::Forms::DataGridViewCellMouseEventHandler(this, &MainForm::dataGridView_RowHeaderMouseDoubleClick);
         this->dataGridView->DataError += gcnew System::Windows::Forms::DataGridViewDataErrorEventHandler(this, &MainForm::dataGridView_DataError);
         // 
         // Latitude
         // 
         dataGridViewCellStyle2->NullValue = nullptr;
         this->Latitude->DefaultCellStyle = dataGridViewCellStyle2;
         this->Latitude->HeaderText = L"Latitude";
         this->Latitude->Name = L"Latitude";
         this->Latitude->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Longitude
         // 
         dataGridViewCellStyle3->NullValue = nullptr;
         this->Longitude->DefaultCellStyle = dataGridViewCellStyle3;
         this->Longitude->HeaderText = L"Longitude";
         this->Longitude->Name = L"Longitude";
         this->Longitude->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Altitude
         // 
         dataGridViewCellStyle4->NullValue = nullptr;
         this->Altitude->DefaultCellStyle = dataGridViewCellStyle4;
         this->Altitude->HeaderText = L"Altitude";
         this->Altitude->Name = L"Altitude";
         this->Altitude->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Heading
         // 
         dataGridViewCellStyle5->NullValue = nullptr;
         this->Heading->DefaultCellStyle = dataGridViewCellStyle5;
         this->Heading->HeaderText = L"Heading";
         this->Heading->Name = L"Heading";
         this->Heading->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Pitch
         // 
         dataGridViewCellStyle6->NullValue = nullptr;
         this->Pitch->DefaultCellStyle = dataGridViewCellStyle6;
         this->Pitch->HeaderText = L"Pitch";
         this->Pitch->Name = L"Pitch";
         this->Pitch->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Roll
         // 
         dataGridViewCellStyle7->NullValue = nullptr;
         this->Roll->DefaultCellStyle = dataGridViewCellStyle7;
         this->Roll->HeaderText = L"Roll";
         this->Roll->Name = L"Roll";
         this->Roll->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Speed
         // 
         dataGridViewCellStyle8->NullValue = nullptr;
         this->Speed->DefaultCellStyle = dataGridViewCellStyle8;
         this->Speed->HeaderText = L"Speed";
         this->Speed->Name = L"Speed";
         this->Speed->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // Units
         // 
         this->Units->HeaderText = L"Units";
         this->Units->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"fps", L"mph", L"knots"});
         this->Units->Name = L"Units";
         // 
         // TerrainFollowing
         // 
         this->TerrainFollowing->HeaderText = L"Terrain Following";
         this->TerrainFollowing->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"off", L"on"});
         this->TerrainFollowing->Name = L"TerrainFollowing";
         // 
         // TurnRadius
         // 
         dataGridViewCellStyle9->NullValue = nullptr;
         this->TurnRadius->DefaultCellStyle = dataGridViewCellStyle9;
         this->TurnRadius->HeaderText = L"Turn Radius";
         this->TurnRadius->Name = L"TurnRadius";
         this->TurnRadius->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
         // 
         // toolStripMain
         // 
         this->toolStripMain->Dock = System::Windows::Forms::DockStyle::None;
         this->toolStripMain->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(14) {this->toolStripButtonNew, 
            this->toolStripButtonOpen, this->toolStripButtonSave, this->toolStripSeparator1, this->toolStripButtonCut, this->toolStripButtonCopy, 
            this->toolStripButtonPaste, this->toolStripSeparator2, this->toolStripButtonNewRecord, this->toolStripButtonUpdateRecord, this->toolStripButtonDeleteRecord, 
            this->toolStripSeparator3, this->toolStripButtonFillUp, this->toolStripButtonFillDown});
         this->toolStripMain->Location = System::Drawing::Point(3, 0);
         this->toolStripMain->Name = L"toolStripMain";
         this->toolStripMain->Size = System::Drawing::Size(283, 25);
         this->toolStripMain->TabIndex = 0;
         // 
         // toolStripButtonNew
         // 
         this->toolStripButtonNew->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonNew->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonNew.Image")));
         this->toolStripButtonNew->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonNew->Name = L"toolStripButtonNew";
         this->toolStripButtonNew->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonNew->Text = L"New";
         this->toolStripButtonNew->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonNew_Click);
         // 
         // toolStripButtonOpen
         // 
         this->toolStripButtonOpen->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonOpen->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonOpen.Image")));
         this->toolStripButtonOpen->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonOpen->Name = L"toolStripButtonOpen";
         this->toolStripButtonOpen->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonOpen->Text = L"Open";
         this->toolStripButtonOpen->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonOpen_Click);
         // 
         // toolStripButtonSave
         // 
         this->toolStripButtonSave->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonSave->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonSave.Image")));
         this->toolStripButtonSave->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonSave->Name = L"toolStripButtonSave";
         this->toolStripButtonSave->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonSave->Text = L"Save";
         this->toolStripButtonSave->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonSave_Click);
         // 
         // toolStripSeparator1
         // 
         this->toolStripSeparator1->Name = L"toolStripSeparator1";
         this->toolStripSeparator1->Size = System::Drawing::Size(6, 25);
         // 
         // toolStripButtonCut
         // 
         this->toolStripButtonCut->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonCut->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonCut.Image")));
         this->toolStripButtonCut->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonCut->Name = L"toolStripButtonCut";
         this->toolStripButtonCut->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonCut->Text = L"Cut";
         this->toolStripButtonCut->ToolTipText = L"Cut";
         this->toolStripButtonCut->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonCut_Click);
         // 
         // toolStripButtonCopy
         // 
         this->toolStripButtonCopy->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonCopy->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonCopy.Image")));
         this->toolStripButtonCopy->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonCopy->Name = L"toolStripButtonCopy";
         this->toolStripButtonCopy->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonCopy->Text = L"Copy";
         this->toolStripButtonCopy->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonCopy_Click);
         // 
         // toolStripButtonPaste
         // 
         this->toolStripButtonPaste->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonPaste->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonPaste.Image")));
         this->toolStripButtonPaste->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonPaste->Name = L"toolStripButtonPaste";
         this->toolStripButtonPaste->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonPaste->Text = L"Paste";
         this->toolStripButtonPaste->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonPaste_Click);
         // 
         // toolStripSeparator2
         // 
         this->toolStripSeparator2->Name = L"toolStripSeparator2";
         this->toolStripSeparator2->Size = System::Drawing::Size(6, 25);
         // 
         // toolStripButtonNewRecord
         // 
         this->toolStripButtonNewRecord->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonNewRecord->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonNewRecord.Image")));
         this->toolStripButtonNewRecord->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonNewRecord->Name = L"toolStripButtonNewRecord";
         this->toolStripButtonNewRecord->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonNewRecord->Text = L"New Waypoint";
         this->toolStripButtonNewRecord->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonNewRecord_Click);
         // 
         // toolStripButtonUpdateRecord
         // 
         this->toolStripButtonUpdateRecord->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonUpdateRecord->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonUpdateRecord.Image")));
         this->toolStripButtonUpdateRecord->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonUpdateRecord->Name = L"toolStripButtonUpdateRecord";
         this->toolStripButtonUpdateRecord->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonUpdateRecord->Text = L"Update Waypoint";
         this->toolStripButtonUpdateRecord->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonUpdateRecord_Click);
         // 
         // toolStripButtonDeleteRecord
         // 
         this->toolStripButtonDeleteRecord->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonDeleteRecord->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonDeleteRecord.Image")));
         this->toolStripButtonDeleteRecord->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonDeleteRecord->Name = L"toolStripButtonDeleteRecord";
         this->toolStripButtonDeleteRecord->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonDeleteRecord->Text = L"Delete Waypoint";
         this->toolStripButtonDeleteRecord->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonDeleteRecord_Click);
         // 
         // toolStripSeparator3
         // 
         this->toolStripSeparator3->Name = L"toolStripSeparator3";
         this->toolStripSeparator3->Size = System::Drawing::Size(6, 25);
         // 
         // toolStripButtonFillUp
         // 
         this->toolStripButtonFillUp->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonFillUp->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonFillUp.Image")));
         this->toolStripButtonFillUp->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonFillUp->Name = L"toolStripButtonFillUp";
         this->toolStripButtonFillUp->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonFillUp->Text = L"Fill Up";
         this->toolStripButtonFillUp->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonFillUp_Click);
         // 
         // toolStripButtonFillDown
         // 
         this->toolStripButtonFillDown->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonFillDown->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonFillDown.Image")));
         this->toolStripButtonFillDown->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonFillDown->Name = L"toolStripButtonFillDown";
         this->toolStripButtonFillDown->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonFillDown->Text = L"Fill Down";
         this->toolStripButtonFillDown->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonFillDown_Click);
         // 
         // toolStripConnect
         // 
         this->toolStripConnect->Dock = System::Windows::Forms::DockStyle::None;
         this->toolStripConnect->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->toolStripLabelIP, 
            this->textBoxIP, this->labelPort, this->textBoxPort, this->toolStripButtonConnect, this->toolStripButtonDisconnect});
         this->toolStripConnect->Location = System::Drawing::Point(286, 0);
         this->toolStripConnect->Name = L"toolStripConnect";
         this->toolStripConnect->Size = System::Drawing::Size(211, 25);
         this->toolStripConnect->TabIndex = 1;
         // 
         // toolStripLabelIP
         // 
         this->toolStripLabelIP->Name = L"toolStripLabelIP";
         this->toolStripLabelIP->Size = System::Drawing::Size(21, 22);
         this->toolStripLabelIP->Text = L"IP:";
         // 
         // textBoxIP
         // 
         this->textBoxIP->Name = L"textBoxIP";
         this->textBoxIP->Size = System::Drawing::Size(80, 25);
         this->textBoxIP->Text = L"172.30.2.100";
         // 
         // labelPort
         // 
         this->labelPort->Name = L"labelPort";
         this->labelPort->Size = System::Drawing::Size(31, 22);
         this->labelPort->Text = L"Port:";
         // 
         // textBoxPort
         // 
         this->textBoxPort->Name = L"textBoxPort";
         this->textBoxPort->Size = System::Drawing::Size(40, 25);
         this->textBoxPort->Text = L"5001";
         // 
         // toolStripButtonConnect
         // 
         this->toolStripButtonConnect->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonConnect->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonConnect.Image")));
         this->toolStripButtonConnect->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonConnect->Name = L"toolStripButtonConnect";
         this->toolStripButtonConnect->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonConnect->Text = L"Connect";
         this->toolStripButtonConnect->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonConnect_Click);
         // 
         // toolStripButtonDisconnect
         // 
         this->toolStripButtonDisconnect->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonDisconnect->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonDisconnect.Image")));
         this->toolStripButtonDisconnect->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonDisconnect->Name = L"toolStripButtonDisconnect";
         this->toolStripButtonDisconnect->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonDisconnect->Text = L"Disconnect";
         this->toolStripButtonDisconnect->Visible = false;
         this->toolStripButtonDisconnect->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonDisconnect_Click);
         // 
         // toolStripCommand
         // 
         this->toolStripCommand->Dock = System::Windows::Forms::DockStyle::None;
         this->toolStripCommand->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->toolStripLabel1, 
            this->textBoxCommand, this->toolStripButtonExecute});
         this->toolStripCommand->Location = System::Drawing::Point(497, 0);
         this->toolStripCommand->Name = L"toolStripCommand";
         this->toolStripCommand->Size = System::Drawing::Size(326, 25);
         this->toolStripCommand->TabIndex = 2;
         // 
         // toolStripLabel1
         // 
         this->toolStripLabel1->Name = L"toolStripLabel1";
         this->toolStripLabel1->Size = System::Drawing::Size(58, 22);
         this->toolStripLabel1->Text = L"Command:";
         // 
         // textBoxCommand
         // 
         this->textBoxCommand->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
         this->textBoxCommand->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::CustomSource;
         this->textBoxCommand->Enabled = false;
         this->textBoxCommand->MaxLength = 80;
         this->textBoxCommand->Name = L"textBoxCommand";
         this->textBoxCommand->Size = System::Drawing::Size(200, 25);
         this->textBoxCommand->KeyUp += gcnew System::Windows::Forms::KeyEventHandler(this, &MainForm::textBoxCommand_KeyUp);
         // 
         // toolStripButtonExecute
         // 
         this->toolStripButtonExecute->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
         this->toolStripButtonExecute->Enabled = false;
         this->toolStripButtonExecute->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButtonExecute.Image")));
         this->toolStripButtonExecute->ImageTransparentColor = System::Drawing::Color::Magenta;
         this->toolStripButtonExecute->Name = L"toolStripButtonExecute";
         this->toolStripButtonExecute->Size = System::Drawing::Size(23, 22);
         this->toolStripButtonExecute->Text = L"Execute Command";
         this->toolStripButtonExecute->Click += gcnew System::EventHandler(this, &MainForm::toolStripButtonExecute_Click);
         // 
         // timer
         // 
         this->timer->Enabled = true;
         this->timer->Interval = 500;
         this->timer->Tick += gcnew System::EventHandler(this, &MainForm::timer_Tick);
         // 
         // timerJoystick
         // 
         this->timerJoystick->Enabled = true;
         this->timerJoystick->Tick += gcnew System::EventHandler(this, &MainForm::timerJoystick_Tick);
         // 
         // timerLocation
         // 
         this->timerLocation->Enabled = true;
         this->timerLocation->Interval = 30;
         this->timerLocation->Tick += gcnew System::EventHandler(this, &MainForm::timerLocation_Tick);
         // 
         // MainForm
         // 
         this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
         this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
         this->ClientSize = System::Drawing::Size(922, 527);
         this->Controls->Add(this->toolStripContainer);
         this->Controls->Add(this->menuStrip);
         this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
         this->MainMenuStrip = this->menuStrip;
         this->Name = L"MainForm";
         this->Text = L"RouteEditor";
         this->KeyUp += gcnew System::Windows::Forms::KeyEventHandler(this, &MainForm::MainForm_KeyUp);
         this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &MainForm::MainForm_FormClosing);
         this->menuStrip->ResumeLayout(false);
         this->menuStrip->PerformLayout();
         this->toolStripContainer->BottomToolStripPanel->ResumeLayout(false);
         this->toolStripContainer->BottomToolStripPanel->PerformLayout();
         this->toolStripContainer->ContentPanel->ResumeLayout(false);
         this->toolStripContainer->TopToolStripPanel->ResumeLayout(false);
         this->toolStripContainer->TopToolStripPanel->PerformLayout();
         this->toolStripContainer->ResumeLayout(false);
         this->toolStripContainer->PerformLayout();
         this->toolStripLocation->ResumeLayout(false);
         this->toolStripLocation->PerformLayout();
         this->statusStrip->ResumeLayout(false);
         this->statusStrip->PerformLayout();
         (cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView))->EndInit();
         this->toolStripMain->ResumeLayout(false);
         this->toolStripMain->PerformLayout();
         this->toolStripConnect->ResumeLayout(false);
         this->toolStripConnect->PerformLayout();
         this->toolStripCommand->ResumeLayout(false);
         this->toolStripCommand->PerformLayout();
         this->ResumeLayout(false);
         this->PerformLayout();

      }
#pragma endregion

   private: 

      // Toolstrip Button Handlers

      System::Void toolStripButtonNew_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonOpen_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonSave_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void toolStripButtonNewRecord_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonUpdateRecord_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonDeleteRecord_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonCut_Click(System::Object^  sender, System::EventArgs^  e);      
      System::Void toolStripButtonCopy_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonPaste_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void toolStripButtonFillUp_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonFillDown_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void toolStripButtonConnect_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonDisconnect_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void toolStripButtonUpdateLocation_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonOK_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonCancel_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void toolStripButtonEyepoint_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonCursor_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonChain_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void toolStripButtonUnchain_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void toolStripButtonExecute_Click(System::Object^  sender, System::EventArgs^  e);

      // Menu Item Event Handlers

      System::Void newToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void openToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void saveToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void saveAsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);

      System::Void cutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void copyToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void pasteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void deleteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void selectAllToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);


      System::Void standardToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      System::Void connectionToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      System::Void locationToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      System::Void commandToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      System::Void statusBarToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      System::Void settingsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);

      // Data Grid Event Handlers

      System::Void dataGridView_CellValueChanged(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
      System::Void dataGridView_RowEnter(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
      System::Void dataGridView_RowLeave(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
      System::Void dataGridView_DataError(System::Object^  sender, System::Windows::Forms::DataGridViewDataErrorEventArgs^  e);
      System::Void dataGridView_CellDoubleClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e);
      System::Void dataGridView_RowHeaderMouseDoubleClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellMouseEventArgs^  e);

      // Form Event Handlers

      System::Void MainForm_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e);
      System::Void MainForm_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);

      System::Void textBoxCommand_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);

      // Timer Events

      System::Void timer_Tick(System::Object^  sender, System::EventArgs^  e);

      
         
      System::Void timerJoystick_Tick(System::Object^  sender, System::EventArgs^  e);
      System::Void timerLocation_Tick(System::Object^  sender, System::EventArgs^  e);
         
};
}

