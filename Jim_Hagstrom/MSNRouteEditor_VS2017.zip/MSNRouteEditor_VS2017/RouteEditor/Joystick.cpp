//*****************************************************************************
//*****                            UNCLASSIFIED                           *****
//*****************************************************************************
/** 
 * @file
 * This is the Joystick Class implementation. This class provides the ability to
 * handle a standard USB joystick for a Windows operating system.
 */


#include <windows.h>
// Windows Joystick
#include <mmsystem.h>				
#pragma comment(lib, "Winmm.lib")

#include "Joystick.h"


Joystick::Joystick()
{
	m_hasPov = false;
   m_hasZ = false;
   m_hasR = false;
	
	// Get the joystick range
	JOYCAPS joycaps;
   if (JOYERR_NOERROR == joyGetDevCaps(JOYSTICKID1, &joycaps, sizeof(joycaps)))
   {
   
      m_xMax = joycaps.wXmax;
      m_yMax = joycaps.wYmax;
      m_zMax = joycaps.wZmax;
      m_rMax = joycaps.wRmax;
      m_xMin = joycaps.wXmin;
      m_yMin = joycaps.wYmin;
      m_zMin = joycaps.wZmin;
      m_rMin = joycaps.wRmin;


      if (joycaps.wCaps & JOYCAPS_HASPOV) m_hasPov = true;
      if (joycaps.wCaps & JOYCAPS_HASZ) m_hasZ = true;
      if (joycaps.wCaps & JOYCAPS_HASR) m_hasR = true;
   }
   else
   {
      m_xMax = 0;
      m_yMax = 0;
      m_zMax = 0;
      m_rMax = 0;
      m_xMin = 0;
      m_yMin = 0;
      m_zMin = 0;
      m_rMin = 0;
      m_hasPov = false;
      m_hasZ = false;
      m_hasR = false;
   }

   // Setup the joystick
   JOYINFOEX joyinfo;
	joyinfo.dwSize = sizeof(JOYINFOEX);
	joyinfo.dwFlags = JOY_RETURNALL;

	// Get the joystick position and make sure it is attached
	if (joyGetPosEx(JOYSTICKID1, &joyinfo) == JOYERR_NOERROR)
		m_connected = true;
	else
		m_connected = false;

   // setup the buttons
   m_buttons = new bool[32];
   for (int i=0; i<32; i++) 
      m_buttons[i] = false;

   m_buttonCount = joycaps.wMaxButtons;

   m_xAxis = 0;
   m_yAxis = 0;
   m_zAxis = 0;
   m_rAxis = 0;
   m_pov = e_JoyPovCentered;
   m_deadZone = 0;
}

Joystick::~Joystick()
{
   // release the memory for the buttons
   delete [] m_buttons;
}


void Joystick::checkInput()
{
   // Setup the joystick
   JOYINFOEX joyinfo;
	joyinfo.dwSize = sizeof(JOYINFOEX);
	joyinfo.dwFlags = JOY_RETURNALL;

	// Get the joystick position and make sure it is attached
	if (joyGetPosEx(JOYSTICKID1, &joyinfo) == JOYERR_NOERROR)
		m_connected = true;
	else
		m_connected = false;

   if (!m_connected) return;

   // Calculate the Range
   double x_range = m_xMax - m_xMin;
   double y_range = m_yMax - m_yMin;
   double z_range = m_zMax - m_zMin;
   double r_range = m_rMax - m_rMin;
   
   // Get the current position
   double x = joyinfo.dwXpos;
   double y = joyinfo.dwYpos;
   double z = joyinfo.dwZpos;
   double r = joyinfo.dwRpos;

   // Calculate the ratio
   double ratio_x = (x + m_xMin) / x_range;
   double ratio_y = (y + m_yMin) / y_range;
   double ratio_z = (z + m_zMin) / z_range;
   double ratio_r = (r + m_rMin) / r_range;

   // Save the data to member variables
   m_xAxis = ratio_x * 2 - 1.0;
   m_yAxis = ratio_y * 2 - 1.0;
   m_zAxis = ratio_z * 2 - 1.0;
   m_rAxis = ratio_r * 2 - 1.0;

   if (-m_deadZone < m_xAxis && m_xAxis < m_deadZone) m_xAxis = 0;
   if (-m_deadZone < m_yAxis && m_yAxis < m_deadZone) m_yAxis = 0;
   if (-m_deadZone < m_zAxis && m_zAxis < m_deadZone) m_zAxis = 0;
   if (-m_deadZone < m_rAxis && m_rAxis < m_deadZone) m_rAxis = 0;

   if (m_hasPov)
   {
      // Get POV position
      switch (joyinfo.dwPOV)
      {
 		   case JOY_POVBACKWARD:   m_pov = e_JoyPovBackward; break;
		   case JOY_POVFORWARD:    m_pov = e_JoyPovForward; break;
		   case JOY_POVLEFT:       m_pov = e_JoyPovLeft; break;
		   case JOY_POVRIGHT:      m_pov = e_JoyPovRight; break;
         case JOY_POVCENTERED:   m_pov = e_JoyPovCentered; break;
         default: m_pov = e_JoyPovCentered; break;
	   };
   }

   // Get Buttons
   m_buttons[0] = (joyinfo.dwButtons & JOY_BUTTON1 ? true : false);
   m_buttons[1] = (joyinfo.dwButtons & JOY_BUTTON2 ? true : false);
   m_buttons[2] = (joyinfo.dwButtons & JOY_BUTTON3 ? true : false);
   m_buttons[3] = (joyinfo.dwButtons & JOY_BUTTON4 ? true : false);
   m_buttons[4] = (joyinfo.dwButtons & JOY_BUTTON5 ? true : false);
   m_buttons[5] = (joyinfo.dwButtons & JOY_BUTTON6 ? true : false);
   m_buttons[6] = (joyinfo.dwButtons & JOY_BUTTON7 ? true : false);
   m_buttons[7] = (joyinfo.dwButtons & JOY_BUTTON8 ? true : false);
   m_buttons[8] = (joyinfo.dwButtons & JOY_BUTTON9 ? true : false);
   m_buttons[9] = (joyinfo.dwButtons & JOY_BUTTON10 ? true : false);
   m_buttons[10] = (joyinfo.dwButtons & JOY_BUTTON11 ? true : false);
   m_buttons[11] = (joyinfo.dwButtons & JOY_BUTTON12 ? true : false);
   m_buttons[12] = (joyinfo.dwButtons & JOY_BUTTON13 ? true : false);
   m_buttons[13] = (joyinfo.dwButtons & JOY_BUTTON14 ? true : false);
   m_buttons[14] = (joyinfo.dwButtons & JOY_BUTTON15 ? true : false);
   m_buttons[15] = (joyinfo.dwButtons & JOY_BUTTON16 ? true : false);
   m_buttons[16] = (joyinfo.dwButtons & JOY_BUTTON17 ? true : false);
   m_buttons[17] = (joyinfo.dwButtons & JOY_BUTTON18 ? true : false);
   m_buttons[18] = (joyinfo.dwButtons & JOY_BUTTON19 ? true : false);
   m_buttons[19] = (joyinfo.dwButtons & JOY_BUTTON20 ? true : false);
   m_buttons[20] = (joyinfo.dwButtons & JOY_BUTTON21 ? true : false);
   m_buttons[21] = (joyinfo.dwButtons & JOY_BUTTON22 ? true : false);
   m_buttons[22] = (joyinfo.dwButtons & JOY_BUTTON23 ? true : false);
   m_buttons[23] = (joyinfo.dwButtons & JOY_BUTTON24 ? true : false);
   m_buttons[24] = (joyinfo.dwButtons & JOY_BUTTON25 ? true : false);
   m_buttons[25] = (joyinfo.dwButtons & JOY_BUTTON26 ? true : false);
   m_buttons[26] = (joyinfo.dwButtons & JOY_BUTTON27 ? true : false);
   m_buttons[27] = (joyinfo.dwButtons & JOY_BUTTON28 ? true : false);
   m_buttons[28] = (joyinfo.dwButtons & JOY_BUTTON29 ? true : false);
   m_buttons[29] = (joyinfo.dwButtons & JOY_BUTTON30 ? true : false);
   m_buttons[30] = (joyinfo.dwButtons & JOY_BUTTON31 ? true : false);
   m_buttons[31] = (joyinfo.dwButtons & JOY_BUTTON32 ? true : false);

}

bool Joystick::getButton(unsigned int button)
{
   // idiot checks
   if (m_buttonCount == 0) return false; 
   if (button < 1 || button >= m_buttonCount) return false;

   // return the button state
   return m_buttons[button-1];
}

