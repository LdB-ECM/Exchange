#include "Opcodes.h"
#include <string.h>
#include <math.h>
using namespace Ig::Opcodes;

// Opcode

const double Opcode::sc_epsilon          = 0.00001;
const double Opcode::sc_pi               = 3.14159265358979323846;
const double Opcode::sc_halfPi           = 3.14159265358979323846 / 2.0;
const double Opcode::sc_twoPi            = 2.0 * 3.14159265358979323846;
const double Opcode::sc_degreesToRadians = 3.14159265358979323846 / 180.0;
const double Opcode::sc_radiansToDegrees = 180.0 / 3.14159265358979323846;


const __int64 Opcode::doubleTo36BitAngle(const double angle)
{   
   double local_angle = reduceAngleDegrees(angle);

 	// conversion formula
	__int64 temp = static_cast<__int64>( ((local_angle / 360.0) * pow(2.0f,36)) );
	
	// zero out bit 31 and shift bits 31-35 once left
	temp = (temp & 0x000000007FFFFFFFULL) | ((temp << 1) & 0x1F00000000ULL);

	//byte swap
   temp = ((temp & 0xFFFF) << 48) + 
			 ((temp & 0xFFFF00000000ULL) >> 16) + 
			 ((temp & 0xFFFF0000) >> 16); 

   return temp;
}

const int Opcode::doubleTo32BitScaledDistance(const double distance)
{
	return static_cast<int>((distance * pow(2.0, 9.0)));
}

const double Opcode::scaledDistance32BitToDouble(const int distance)
{
	return static_cast<double>((static_cast<double>(distance) / pow(2.0, 9.0)));
}

const int Opcode::doubleTo32BitAngle(const double angle)
{
   int num_2pi = static_cast<int>(angle / 360);
   double remainder = angle - (num_2pi * 360);
   if (remainder > 180.0)
   {
      remainder = -( 360-remainder);
   }
   else
   if (remainder < -180.0)
   {
      remainder = ( 360 + remainder);
   }

	return static_cast<int>( ( (angle / 360.0) * pow(2.0, 32) ) );
}

const short Opcode::doubleTo16BitScalarA(const double value)
{
   return static_cast<short>(value * pow(2.0, 11));
}

const int Opcode::doubleTo32BitScalarA(const double value)
{
   return static_cast<int>(value * pow(2.0, 16));
}


const int Opcode::doubleTo32BitScalarD(const double value)
{
   return static_cast<int>(value * pow(2.0, 15));
}

const int Opcode::doubleTo32BitScaledAngularRate(const double rate)
{
   return static_cast<int>(rate * pow(2.0f, 25));
}

const double Opcode::intToFloat64(int highInt, int lowInt)
{
   // Create 64 bit versions of the integers
   __int64 tempLowInt = 0;
   __int64 tempHighInt = 0;
   // Create a 64 bit float
   double tempFloat = 0.0;
   // Store the high bits and shift them over 32 bits
   tempHighInt = highInt;
   tempHighInt = (tempHighInt << 32);
   // Store the low bits
   tempLowInt = lowInt;
   tempLowInt = tempLowInt & (0x00000000ffffffff);
   // Or the two together
   tempHighInt = tempHighInt | tempLowInt;
   // Copy the bits into the float
   memcpy(&tempFloat, &tempHighInt, sizeof(double));
   // Return the result
   return tempFloat;
}

const unsigned short Opcode::float32ToFractionB16(const float value)
{
   // Fraction * 2^6 = result.
   unsigned short result = static_cast<unsigned short>(value * 64);
   return result;
}

const double Opcode::reduceAngleDegrees(const double angleInDegrees)
{
   double angle_in_radians = angleInDegrees * sc_degreesToRadians;
   double reduced_angle_in_radians = plusMinusPi(angle_in_radians);
   return reduced_angle_in_radians * sc_radiansToDegrees;
}

// End Of Data - 0x3000

EndOfData::EndOfData()
{
   m_buffer.m_opcodeNumber = 0x3000;
   m_buffer.m_reserved = 0;
}

char* EndOfData::getBuffer()
{
   return (char*)(&m_buffer);
}

int EndOfData::getBufferSize()
{
   return sizeof(m_buffer);
}

void EndOfData::setBuffer(char* buffer)
{
   memcpy(&m_buffer, (void*)buffer, sizeof(m_buffer));
}

unsigned short EndOfData::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}


// Terrain Following Modesl - 0x303D

TerrainFollowingModels::TerrainFollowingModels()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0x303D;
   m_buffer.m_unused = 0x8000;
}

char* TerrainFollowingModels::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int TerrainFollowingModels::getBufferSize()
{
   return sizeof(m_buffer);
}

void TerrainFollowingModels::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short TerrainFollowingModels::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

void TerrainFollowingModels::setMovingModelNumber(const unsigned short movingModelNumber)
{
   m_buffer.m_movingModelNumber = movingModelNumber;
}

void TerrainFollowingModels::setIdNumber(const unsigned char idNum)
{
   m_buffer.m_idNumber = idNum;
}

void TerrainFollowingModels::setConform(const unsigned char conformFlag)
{
   m_buffer.m_conformFlag = conformFlag;
}

void TerrainFollowingModels::setSmoothing(const unsigned char smoothing)
{
   m_buffer.m_smoothing = smoothing;
}

void TerrainFollowingModels::setZ(const double z)
{
   m_buffer.m_z = Opcode::doubleTo32BitScaledDistance(z);
}


// Moving Model Definition - 0x0340

MovingModelDefinition::MovingModelDefinition()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0x3040;
}

char* MovingModelDefinition::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int MovingModelDefinition::getBufferSize()
{
   return sizeof(m_buffer);
}

void MovingModelDefinition::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short MovingModelDefinition::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

void MovingModelDefinition::setProcessBind(const bool value)
{
   m_buffer.m_processBind = value;
}

void MovingModelDefinition::setBind(const bool value)
{
   m_buffer.m_bind = value;
}

void MovingModelDefinition::setEnableTranslationalExtrapolation(const bool value)
{
   m_buffer.m_enableTranslationalExtrapolation = value;
}

void MovingModelDefinition::setEnableRotationalExtrapolation(const bool value)
{
   m_buffer.m_enableRotationalExtrapolation = value;
}

void MovingModelDefinition::setEnableSecondarySubmodelRotationalExtrpolation(const bool value)
{
   m_buffer.m_enableSecondarySubmodelRotationalExtrapolation = value;
}

void MovingModelDefinition::setLocalPolygonIntensityByStep(const bool value)
{
   m_buffer.m_setLocalPolygonIntensityByStep = value;
}

void MovingModelDefinition::setLocalLightIntensityByStep(const bool value)
{
   m_buffer.m_setLocalLightIntensityByStep = value;
}

void MovingModelDefinition::setProcessDuringForegroundNonCriticalTime(const bool value)
{
   m_buffer.m_processDuringForegroundNonCriticalTime = value;
}

void MovingModelDefinition::setMotionSystemNumber(const unsigned short motionSystemNumber)
{
   m_buffer.m_motionSystemNumber = motionSystemNumber;
}

void MovingModelDefinition::setModelSlotNumber(const unsigned short modelSlotNumber)
{
   m_buffer.m_modelSlotNumber = modelSlotNumber;
}

void MovingModelDefinition::setModelCleanupClean(const bool value)
{
   m_buffer.m_modelCleanupClean = value;
}

void MovingModelDefinition::setUseUpper16LocalLightGroups(const bool value)
{
   m_buffer.m_useUpper16LocalLightGroups = value;
}

void MovingModelDefinition::setUseUpper16LocalPolygonGroups(const bool value)
{
   m_buffer.m_useUpper16LocalPolygonGroups = value;
}

void MovingModelDefinition::setParentMovingModel(const unsigned short parentMovingModel)
{
   m_buffer.m_parentMovingModel = parentMovingModel;
}

void MovingModelDefinition::setLocalLightIntensity(const double localLightIntensity)
{
   m_buffer.m_localLightIntensity = doubleTo16BitScalarA(localLightIntensity);
}

void MovingModelDefinition::setLocalLightMask(const unsigned short localLightMask)
{
   m_buffer.m_localLightMask = localLightMask;
}

void MovingModelDefinition::setLocalPolygonIntensity(const double localPolygonIntensity)
{
   m_buffer.m_localPolygonIntensity = doubleTo16BitScalarA(localPolygonIntensity);
}

void MovingModelDefinition::setLocalPolygonMask(const unsigned short localPolygonMask)
{
   m_buffer.m_localPolygonMask = localPolygonMask;
}


// Moving Model And Eyepoint Control - 0x0341

MovingModelAndEyepointControl::MovingModelAndEyepointControl()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0x3041;
}

char* MovingModelAndEyepointControl::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int MovingModelAndEyepointControl::getBufferSize()
{
   return sizeof(m_buffer);
}

void MovingModelAndEyepointControl::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short MovingModelAndEyepointControl::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

void MovingModelAndEyepointControl::setMovingModelNumber(const unsigned short movingModelNumber)
{
   m_buffer.m_movingModelNumber = movingModelNumber;
}

void MovingModelAndEyepointControl::setSubModelNumber(const unsigned char subModelNumber)
{
   m_buffer.m_subModelNumber = subModelNumber;
}

void MovingModelAndEyepointControl::setModelSelect(const unsigned char modelSelect)
{
   m_buffer.m_modelSelect = modelSelect;
}

void MovingModelAndEyepointControl::setLatitude(const double latitude)
{
   m_buffer.m_latitude = Opcode::doubleTo36BitAngle(latitude);
   setTranslationalModeGeodetic();
   setXOrLatitudeValid();
}

void MovingModelAndEyepointControl::setLongitude(const double longitude)
{
   m_buffer.m_longitude = Opcode::doubleTo36BitAngle(longitude);
   setTranslationalModeGeodetic();
   setYOrLongitudeValid();
}

void MovingModelAndEyepointControl::setAltitude(const double altitude)
{
   m_buffer.m_altitude = Opcode::doubleTo32BitScaledDistance(altitude);
   setTranslationalModeGeodetic();
   setZOrAltitudeValid();
}

void MovingModelAndEyepointControl::setPosition(const double latitude, const double longitude, const double altitude)
{
   setLatitude(latitude);
   setLongitude(longitude);
   setAltitude(altitude);
}

void MovingModelAndEyepointControl::setOrientation(const double heading, const double pitch, const double roll)
{
   setRoll(roll);
   setPitch(pitch);
   setHeading(heading);
}

void  MovingModelAndEyepointControl::setRoll(const double roll)
{
   m_buffer.m_roll = Opcode::doubleTo32BitAngle(roll);
   setRollValid();
}

void MovingModelAndEyepointControl::setPitch(const double pitch)
{
   m_buffer.m_pitch = Opcode::doubleTo32BitAngle(pitch);
   setPitchValid();
}

void MovingModelAndEyepointControl::setHeading(const double heading)
{
   m_buffer.m_heading = Opcode::doubleTo32BitAngle(Opcode::reduceAngleDegrees(heading));
   setHeadingValid();
}

void MovingModelAndEyepointControl::setXOffset(const double offset)
{
   m_buffer.m_latitudeOrXOffset.m_xOffset = Opcode::doubleTo32BitScaledDistance(offset);
   setTranslationalModeCartesian();
   setXOrLatitudeValid();
}
            
void MovingModelAndEyepointControl::setYOffset(const double offset)
{
   m_buffer.m_longitudeOrYOffset.m_yOffset = Opcode::doubleTo32BitScaledDistance(offset);
   setTranslationalModeCartesian();
   setYOrLongitudeValid();
}

void MovingModelAndEyepointControl::setZOffset(const double offset)
{
   m_buffer.m_zOffset = Opcode::doubleTo32BitScaledDistance(offset);
   setTranslationalModeCartesian();
   setZOrAltitudeValid();
}


void MovingModelAndEyepointControl::setRollValid(const bool valid)
{
   m_buffer.m_rollValid = valid;
}

void MovingModelAndEyepointControl::setPitchValid(const bool valid)
{
   m_buffer.m_pitchValid = valid;
}

void MovingModelAndEyepointControl::setHeadingValid(const bool valid)
{
   m_buffer.m_headingValid = valid;
}

void MovingModelAndEyepointControl::setZOrAltitudeValid(const bool valid)
{
   m_buffer.m_zOrAltitudeValid = valid;
}

void MovingModelAndEyepointControl::setYOrLongitudeValid(const bool valid)
{
   m_buffer.m_yOrLongitudeValid = valid;
}

void MovingModelAndEyepointControl::setXOrLatitudeValid(const bool valid)
{
   m_buffer.m_xOrLatitudeValid = valid;
}

void MovingModelAndEyepointControl::setTranslationalModeGeodetic()
{
   m_buffer.m_translationalModeGeodetic = 1;
}

void MovingModelAndEyepointControl::setTranslationalModeCartesian()
{
   m_buffer.m_translationalModeGeodetic = 0;
}

void MovingModelAndEyepointControl::setExtrapolationDisabled(const bool disabled)
{
   m_buffer.m_extrapolationDisabled = disabled;
}


// Ascii - 0x3050

Ascii::Ascii()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0x3050;
}

Ascii::Ascii(const char ascii[80])
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0x3050;
   set(ascii);
}

char* Ascii::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int Ascii::getBufferSize()
{
   return sizeof(m_buffer);
}

void Ascii::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short Ascii::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

void Ascii::set(const char ascii[80])
{
   char buffer[80];

   memset(buffer, 0, 80);
   
   strncpy_s(buffer, 80, ascii, 80);
   
   size_t len = strlen(ascii);
   if (len > 80) len = 80;
   
   memset(buffer + len, 0, 80 - len);

	for (size_t i = 0; i < 20; i++)
	{
		m_buffer.m_ascii[4*i]     = buffer[4*i + 3];
		m_buffer.m_ascii[4*i + 1] = buffer[4*i + 2];
		m_buffer.m_ascii[4*i + 2] = buffer[4*i + 1];
		m_buffer.m_ascii[4*i + 3] = buffer[4*i];
	}
}


// Moving Model Velocity - 0x3090

MovingModelVelocity::MovingModelVelocity()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0x3090;
   m_buffer.m_flags = 1;
}

char* MovingModelVelocity::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int MovingModelVelocity::getBufferSize()
{
   return sizeof(m_buffer);
}

void MovingModelVelocity::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short MovingModelVelocity::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

void MovingModelVelocity::setMovingModelNumber (const unsigned short movingModelNumber)
{
   m_buffer.m_movingModelNumber = movingModelNumber;
}

void MovingModelVelocity::setSubModelNumber (const unsigned char subModelNumber)
{
   m_buffer.m_subModelNumber = subModelNumber;
}

void MovingModelVelocity::setVelocity(double xVelocity, double yVelocity, double zVelocity, 
	double headingRate, double pitchRate, double rollRate)
{
   m_buffer.m_xVelocity = Opcode::doubleTo32BitScalarD(xVelocity);
	m_buffer.m_yVelocity = Opcode::doubleTo32BitScalarD(yVelocity);
	m_buffer.m_zVelocity = Opcode::doubleTo32BitScalarD(zVelocity);
	m_buffer.m_headingRate = Opcode::doubleTo32BitScaledAngularRate(headingRate);
	m_buffer.m_pitchRate = Opcode::doubleTo32BitScaledAngularRate(pitchRate);
	m_buffer.m_rollRate = Opcode::doubleTo32BitScaledAngularRate(rollRate);
}

void MovingModelVelocity::setCoordinateSystem(CoordinateSystem system)
{
      m_buffer.m_flags = system; 
}

void MovingModelVelocity::setTimeConstant(unsigned char time)
{
   m_buffer.m_timeConstant = time;
}


// Load Status Request - 0xE000 0x0005/0x002F

LoadStatusRequest::LoadStatusRequest()
{
   memset(&this->m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0xE000;
   m_buffer.m_size = 0x0038;
   m_buffer.m_processId = 0x0003;
   m_buffer.m_executionPriority = 0x0002;
   m_buffer.m_subOpcodeFuncId = 0x002F;
   m_buffer.m_subOpcodeObjId = 0x0005;
   m_buffer.m_responseProcess = 0x0002;
   m_buffer.m_responsePriority = 0x0002;
   m_buffer.m_userSubOpcodeB = 0x002F;   // user defined
   m_buffer.m_userSubOpcodeA = 0x0005;   // user defined
   m_buffer.m_userData = 0x00000000;
}

char* LoadStatusRequest::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int LoadStatusRequest::getBufferSize()
{
   return sizeof(m_buffer);
}

void LoadStatusRequest::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short LoadStatusRequest::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

unsigned short LoadStatusRequest::getSize()
{
   return m_buffer.m_size;
}

unsigned short LoadStatusRequest::getExecutionPriority()
{
   return m_buffer.m_executionPriority;
}

unsigned short LoadStatusRequest::getProcessId()
{
   return m_buffer.m_processId;
}

unsigned short LoadStatusRequest::getObjectId()
{
   return m_buffer.m_subOpcodeObjId;
}

unsigned short LoadStatusRequest::getFunctionId()
{
   return m_buffer.m_subOpcodeFuncId;
}

unsigned short LoadStatusRequest::getResponsePriority()
{
   return m_buffer.m_responsePriority;
}

unsigned short LoadStatusRequest::getResponseProcess()
{
   return m_buffer.m_responseProcess;
}

unsigned short LoadStatusRequest::getSubOpcodeB()
{
   return m_buffer.m_userSubOpcodeB;
}

unsigned short LoadStatusRequest::getSubOpcodeA()
{
   return m_buffer.m_userSubOpcodeA;
}

unsigned int LoadStatusRequest::getUserData()
{
   return m_buffer.m_userData;
}

void LoadStatusRequest::setLongitudinalCenter(double longCenter)
{
   __int64 tempInt;
   memcpy(&tempInt, &longCenter, sizeof(__int64));
   m_buffer.m_longitudinalCenter[0] = static_cast<int>((tempInt & 0xffffffff00000000ULL) >> 32);
   m_buffer.m_longitudinalCenter[1] = static_cast<int>(tempInt & 0x00000000ffffffffULL);
}

void LoadStatusRequest::setLatitudinalCenter(double latCenter)
{
   __int64 tempInt;
   memcpy(&tempInt, &latCenter, sizeof(__int64));
   m_buffer.m_latitudinalCenter[0] = static_cast<int>((tempInt & 0xffffffff00000000ULL) >> 32);
   m_buffer.m_latitudinalCenter[1] = static_cast<int>(tempInt & 0x00000000ffffffffULL);
}

void LoadStatusRequest::setAltitudinalCenter(double altCenter)
{
   __int64 tempInt;
   memcpy(&tempInt, &altCenter, sizeof(__int64));
   m_buffer.m_altitudinalCenter[0] = static_cast<int>((tempInt & 0xffffffff00000000ULL) >> 32);
   m_buffer.m_altitudinalCenter[1] = static_cast<int>(tempInt & 0x00000000ffffffffULL);
}

void LoadStatusRequest::setRadius(float radius)
{
   m_buffer.m_radius = radius;
}

void LoadStatusRequest::setWaitOnModels(bool wait)
{
   m_buffer.m_modelsDone = wait;
}

void LoadStatusRequest::setWaitOnTerrain(bool wait)
{
   m_buffer.m_terrainDone = wait;
}

void LoadStatusRequest::setWaitOnCT(bool wait)
{
   m_buffer.m_ctDone = wait;
}

void LoadStatusRequest::setNonPollMode(bool poll)
{
   m_buffer.m_nonPollMode = poll;
}


// Load Status Response - 0xE000 0x0005/0x002F

LoadStatusResponse::LoadStatusResponse()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0xE000;
   m_buffer.m_size = sizeof(m_buffer);
   m_buffer.m_processId = 0x0002;
   m_buffer.m_responsePriority = 0x0002;
   m_buffer.m_userSubOpcodeB = 0x002F;   // user defined
   m_buffer.m_userSubOpcodeA = 0x0005;   // user defined
   m_buffer.m_userData = 0x00000000;
}

char* LoadStatusResponse::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int LoadStatusResponse::getBufferSize()
{
   return sizeof(m_buffer);
}

void LoadStatusResponse::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short LoadStatusResponse::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

unsigned short LoadStatusResponse::getSize()
{
   return m_buffer.m_size;
}

unsigned short LoadStatusResponse::getProcessId()
{
   return m_buffer.m_processId;
}

unsigned short LoadStatusResponse::getResponsePriority()
{
   return m_buffer.m_responsePriority;
}

unsigned short LoadStatusResponse::getSubOpcodeB()
{
   return m_buffer.m_userSubOpcodeB;
}

unsigned short LoadStatusResponse::getSubOpcodeA()
{
   return m_buffer.m_userSubOpcodeA;
}

unsigned int LoadStatusResponse::getUserData()
{
   return m_buffer.m_userData;
}

bool LoadStatusResponse::getModelsLoaded()
{
   return m_buffer.m_modelsLoaded;
}

bool LoadStatusResponse::getTerrainLoaded()
{
   return m_buffer.m_terrainLoaded;
}

bool LoadStatusResponse::getCtLoaded()
{
   return m_buffer.m_ctLoaded;
}


// Moving Model Request - 0xE000 0x0005/0x0030

MovingModelRequest::MovingModelRequest()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0xE000;
   m_buffer.m_size = 0x0024;
   m_buffer.m_processId = 0x0003;
   m_buffer.m_executionPriority = 0x0002;
   m_buffer.m_subOpcodeFuncId = 0x0030;
   m_buffer.m_subOpcodeObjId = 0x0005;
   m_buffer.m_responseProcess = 0x0002;
   m_buffer.m_responsePriority = 0x0002;
   m_buffer.m_userSubOpcodeB = 0x0030;   // user defined
   m_buffer.m_userSubOpcodeA = 0x0005;   // user defined
   m_buffer.m_userData = 0x00000000;
}

char* MovingModelRequest::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int MovingModelRequest::getBufferSize()
{
   return sizeof(m_buffer);
}

void MovingModelRequest::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short MovingModelRequest::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

unsigned short MovingModelRequest::getSize()
{
   return m_buffer.m_size;
}

unsigned short MovingModelRequest::getExecutionPriority()
{
   return m_buffer.m_executionPriority;
}

unsigned short MovingModelRequest::getProcessId()
{
   return m_buffer.m_processId;
}

unsigned short MovingModelRequest::getObjectId()
{
   return m_buffer.m_subOpcodeObjId;
}

unsigned short MovingModelRequest::getFunctionId()
{
   return m_buffer.m_subOpcodeFuncId;
}

unsigned short MovingModelRequest::getResponsePriority()
{
   return m_buffer.m_responsePriority;
}

unsigned short MovingModelRequest::getResponseProcess()
{
   return m_buffer.m_responseProcess;
}

unsigned short MovingModelRequest::getSubOpcodeB()
{
   return m_buffer.m_userSubOpcodeB;
}

unsigned short MovingModelRequest::getSubOpcodeA()
{
   return m_buffer.m_userSubOpcodeA;
}

unsigned int MovingModelRequest::getUserData()
{
   return m_buffer.m_userData;
}

void MovingModelRequest::setMovingModelNumber(int movingModelNumber)
{
   m_buffer.m_movingModelNumber = movingModelNumber;
}

void MovingModelRequest::setSubModelNumber(int submodelNumber)
{
   if (submodelNumber >= 0 && submodelNumber < 256)
   {
      m_buffer.m_subModelNumber = submodelNumber;
   }
}

void MovingModelRequest::setMode(short mode)
{
   if (mode >-20)
   {
      m_buffer.m_mode = mode;
   }
}

void MovingModelRequest::setHatEnable(bool returnHat)
{
   m_buffer.m_returnHat = returnHat;
}

void MovingModelRequest::setMfeBypass(bool bypassMfe)
{
   m_buffer.m_bypassMfe = bypassMfe;
}

void MovingModelRequest::setReturnTimestamp(bool returnTimestamp)
{
   m_buffer.m_returnTimestamp = returnTimestamp;
}

void MovingModelRequest::setReturnWorldPosition(bool returnWorldPosition)
{
   m_buffer.m_returnWorldPosition = returnWorldPosition;
}

void MovingModelRequest::setUserData(const int data)
{
   m_buffer.m_userData = data;
}


// Moving Model Response - 0xE000 0005/0030

MovingModelResponse::MovingModelResponse()
{
   memset(&m_buffer, 0, sizeof(m_buffer));
   m_buffer.m_opcodeNumber = 0xE000;
   m_buffer.m_size = sizeof(m_buffer);
   m_buffer.m_processId = 0x0002;
   m_buffer.m_responsePriority = 0x0002;
   m_buffer.m_userSubOpcodeB = 0x0030;   // user defined
   m_buffer.m_userSubOpcodeA = 0x0005;   // user defined
   m_buffer.m_userData = 0x00000000;
}

char* MovingModelResponse::getBuffer()
{
   return reinterpret_cast<char*>(&m_buffer);
}

int MovingModelResponse::getBufferSize()
{
   return sizeof(m_buffer);
}

void MovingModelResponse::setBuffer(char* buffer)
{
   memcpy(&m_buffer, buffer, sizeof(m_buffer));
}

unsigned short MovingModelResponse::getOpcodeNumber()
{
   return m_buffer.m_opcodeNumber;
}

unsigned short MovingModelResponse::getSize()
{
   return m_buffer.m_size;
}

unsigned short MovingModelResponse::getProcessId()
{
   return m_buffer.m_processId;
}

unsigned short MovingModelResponse::getResponsePriority()
{
   return m_buffer.m_responsePriority;
}

unsigned short MovingModelResponse::getSubOpcodeB()
{
   return m_buffer.m_userSubOpcodeB;
}

unsigned short MovingModelResponse::getSubOpcodeA()
{
   return m_buffer.m_userSubOpcodeA;
}

unsigned int MovingModelResponse::getUserData()
{
   return m_buffer.m_userData;
}

int MovingModelResponse::getMovingModelNumber()
{
   return m_buffer.m_movingModelNumber;
}

int MovingModelResponse::getSubmodelNumber()
{
   return m_buffer.m_subModelNumber;
}

double MovingModelResponse::getLongitude()
{
   return Opcode::intToFloat64(m_buffer.m_longitude[0], m_buffer.m_longitude[1]);
}

double MovingModelResponse::getLatitude()
{
   return Opcode::intToFloat64(m_buffer.m_latitude[0], m_buffer.m_latitude[1]);
}

double MovingModelResponse::getAltitude()
{
   return Opcode::intToFloat64(m_buffer.m_altitude[0], m_buffer.m_altitude[1]);
}

float MovingModelResponse::getHeading()
{
   return m_buffer.m_heading;
}

float MovingModelResponse::getPitch()
{
   return m_buffer.m_pitch;
}

float MovingModelResponse::getRoll()
{
   return m_buffer.m_roll;
}

float MovingModelResponse::getHat()
{
   return m_buffer.m_hat;
}

float MovingModelResponse::getHot()
{
   return m_buffer.m_hot;
}
