#include "MainForm.h"
#include "SettingsForm.h"
#include <vcclr.h>

#include "Packet.h"
#include "Opcodes.h"

#include "Joystick.h"

using System::IO::Stream;
using RouteEditor::MainForm;
using System::IntPtr;
using System::Runtime::InteropServices::Marshal;

using namespace System::Windows::Forms;

MainForm::MainForm(void)
{
	InitializeComponent();
   m_filename = "";
   m_saved = true;
   updateTitle();

   m_cursorMotionSystem = 5;
   m_eyepointMotionSystem = 0;

   m_startLatitude = 32.505081;
   m_startLongitude = -93.671719;
   m_startAltitude = 178;
   m_startHeading = -116.0;
   m_modelFilename = "f16";

   // Temporary.
   //this->textBoxIP->Text = "127.0.0.1";

   // Put toolbars in the right place.
   this->toolStripMain->Location = System::Drawing::Point(3, 0);
   this->toolStripConnect->Location = System::Drawing::Point(286, 0);
   this->toolStripCommand->Location = System::Drawing::Point(497, 0);

   // Create an IgConnection.
   m_igConnection = new Ig::Connection();
   // Create a Joystick.
   m_joystick = new Joystick();

   // Chain the eyepoint.
   chain();
   // Load Settings.
   loadSettings();

   // Setup the joystick.
   m_joystick->setDeadZone(m_deadZone);

   // Load the model.
   this->m_igConnection->loadModel(1, toStdString(this->m_modelFilename).c_str());
}

MainForm::~MainForm()
{
   // Close the connection to the Ig.
   m_igConnection->close();

	if (components)
	{
		delete components;
	}

   // Delete the ig connection.
   delete m_igConnection;
   // Delete the joystick.
   delete m_joystick;
}

System::Void MainForm::newFile()
{
   // Confirm any unsaved changes. If the user presses cancel, then exit.
   if (saveChanges() == System::Windows::Forms::DialogResult::Cancel)
      return;

   // Clear the filename.
   m_filename = "";
   m_saved = true;

   // Unbind all of the models in the rows.
   for (int i=0; i<this->dataGridView->Rows->Count; i++)
   {
      if (this->dataGridView->Rows[i]->Tag != nullptr)
      {
         int motionSystem = Convert::ToInt32(this->dataGridView->Rows[i]->Tag);
         m_igConnection->unbindModel(motionSystem);
      }
   }
   this->dataGridView->Rows->Clear();      


   // Update the title bar.
   updateTitle();

}

System::Void MainForm::openFile()
{
   // Setup the Open File Dialog.
   openFileDialog->Filter = "Route Files (*.rtd)|*.rtd|Comma Delimited Files (*.csv)|*.csv";
   openFileDialog->FilterIndex = 1;
   // Show Dialog and check to see if the user pressed OK.
   if (openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK)
   {
      // Confirm any unsaved changes. If the user presses cancel, then exit.
      if (saveChanges() == System::Windows::Forms::DialogResult::Cancel)
         return;

      // Check the extension of the filename.
      System::String^ extension = openFileDialog->FileName->Substring(openFileDialog->FileName->LastIndexOf('.'))->ToLower();
      
      // Unbind all of the models in the rows.
      for (int i=0; i<this->dataGridView->Rows->Count; i++)
      {
         if (this->dataGridView->Rows[i]->Tag != nullptr)
         {
            int motionSystem = Convert::ToInt32(this->dataGridView->Rows[i]->Tag);
            m_igConnection->unbindModel(motionSystem);
         }
      }
      this->dataGridView->Rows->Clear();      
      

      // Comma Seperated File.
      if (extension == ".csv")
      {
         openCsvFile(openFileDialog->FileName);
      }
      // EPX Route Editor File.
      else if (extension == ".rtd")
      {
         openRtdFile(openFileDialog->FileName);
      }
      // Unknown.
      else
      {
         MessageBox::Show("Error: Unrecognized File Format.", "Error", 
            System::Windows::Forms::MessageBoxButtons::OK, 
            System::Windows::Forms::MessageBoxIcon::Error);
      }

      // Iterate through the rows and pass them to the Ig.
      for (int i=0; i<this->dataGridView->Rows->Count; i++)
         this->dataGridRowToWaypoint(i);
   }
  
}

System::Void MainForm::saveAsFile()
{
   // Setup the Save File Dialog.
   saveFileDialog->Filter = "Route Files (*.rtd)|*.rtd|Comma Delimited Files (*.csv)|*.csv";
   saveFileDialog->FilterIndex = 1;

   // Show Dialog and check to see if the user pressed OK.
   if (saveFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK)
   {
      // Check the extension of the filename.
      System::String^ extension = saveFileDialog->FileName->Substring(saveFileDialog->FileName->LastIndexOf('.'))->ToLower();
      
      // Comma Seperated File.
      if (extension == ".csv")
      {
         saveCsvFile(saveFileDialog->FileName);
      }
      // EPX Route Editor File.
      else if (extension == ".rtd")
      {
         saveRtdFile(saveFileDialog->FileName);
      }
      // Unknown.
      else
      {
         MessageBox::Show("Error: Unrecognized File Format.", "Error", 
            System::Windows::Forms::MessageBoxButtons::OK, 
            System::Windows::Forms::MessageBoxIcon::Error);
      }
   }

}

System::Void MainForm::saveFile()
{
   // Stop editing.
   this->dataGridView->EndEdit();

   // If the filename has not been set, then do a "Save As".
   if (m_filename == "")
   {
      saveAsFile();
      return;
   }

   // Check the extension of the filename.
   int periodIndex = m_filename->LastIndexOf('.');

   System::String^ extension;
   if (periodIndex > 0)   
      extension = m_filename->Substring(periodIndex)->ToLower();
   else
      extension = "";

   // Comma Seperated File.
   if (extension == ".csv")
   {
      saveCsvFile(m_filename);
   }
   // EPX Route Editor File.
   else if (extension == ".rtd")
   {
      saveRtdFile(m_filename);
   }   
}


System::Boolean MainForm::openCsvFile(System::String^ filename)
{
   m_saved = true;
   m_filename = filename;
   updateTitle();
   
   System::IO::StreamReader^ stream;

   // Open the file.
   try
   {
      stream = System::IO::File::OpenText(filename);
   }
   // Catch any errors.
   catch(...)
   {
      Windows::Forms::MessageBox::Show("Error: Could not open file. Make sure it is not locked by another program.", "Error", 
         System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Error);
      return false;
   }

   System::String^ line;

   // Loop through each line of the file and read them.
   while (!stream->EndOfStream)
   {
      // Read a line of data from the file.
      line = stream->ReadLine();
      // Make sure the line has data.
      if (line->Trim() != "")
      {
         // Split the line by commas.
         cli::array<System::String^, 1>^ columns = line->Split(',');
         // Create a new line in the data grid.
         this->dataGridView->Rows->Add(columns);
      }
   }
   
   // Close the file.
   stream->Close();
   return true;
}

System::Boolean MainForm::openRtdFile(System::String^ filename)
{
   m_saved = true;
   m_filename = filename;
   updateTitle();

   System::IO::StreamReader^ stream;

   // Open the file.
   try
   {
      stream = System::IO::File::OpenText(filename);
   }
   // Catch any errors.
   catch(...)
   {
      Windows::Forms::MessageBox::Show("Error: Could not open file. Make sure it is not locked by another program.", "Error", 
         System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Error);
      return false;
   }

   System::String^ line;

   // Loop through each line of the file and read them.
   while (!stream->EndOfStream)
   {
      // Read a line of data from the file.
      line = stream->ReadLine();
      // Make sure the line has data.
      if (line->Trim() != "")
      {
         // Split the line by spaces.
         cli::array<System::String^, 1>^ data = line->Split(' ');
         cli::array<System::String^, 1>^ columns = gcnew cli::array<System::String^, 1>(this->dataGridView->ColumnCount);
         

         // Loop through each of the data pieces and split by the equal sign.
         // Then put the data in the right column.
         
         for (int i=0; i<data->Length; i++)
         {
            if (data[i]->IndexOf('=') > 0)
            {
               cli::array<System::String^, 1>^ params = data[i]->Split('=');
               if (params->Length > 1)
               {
                  if (params[0]->Trim() == "y")
                     columns[0] = params[1];
                  if (params[0]->Trim() == "x")
                     columns[1] = params[1];
                  if (params[0]->Trim() == "z")
                     columns[2] = params[1];
                  if (params[0]->Trim() == "h")
                     columns[3] = params[1];
                  if (params[0]->Trim() == "p")
                     columns[4] = params[1];
                  if (params[0]->Trim() == "r")
                     columns[5] = params[1];
                  if (params[0]->Trim() == "mph" ||
                     params[0]->Trim() == "fps" ||
                     params[0]->Trim() == "knots")
                  {
                     columns[6] = params[1];
                     columns[7] = params[0];
                  }
                  if (params[0]->Trim() == "tfm")
                     columns[8] = params[1];
                  if (params[0]->Trim() == "turn_radius")
                     columns[9] = params[1];
               }
            }
         }
         
         // Create a new line in the data grid.
         this->dataGridView->Rows->Add(columns);
      }
   }
   
   // Close the file.
   stream->Close();
   return true;
}

System::Boolean MainForm::saveCsvFile(System::String^ filename)
{
   m_saved = true;
   m_filename = filename;
   updateTitle();

   System::IO::StreamWriter^ stream;

   // Open the file.
   try
   {
      stream = System::IO::File::CreateText(filename);
   }
   // Catch any errors.
   catch(...)
   {
      Windows::Forms::MessageBox::Show("Error: Could not open file writing. Make sure it is not locked by another program.", "Error", 
         System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Error);
      return false;
   }

   System::String^ line;

   // Loop through each line of the grid and add it to the file.
   for (int i = 0; i < this->dataGridView->Rows->Count-1; i++)
   {
      // Create a 1d array to hold the cell values for the row.
      cli::array<System::String^, 1>^ columns = gcnew cli::array<System::String^, 1>(this->dataGridView->ColumnCount);
      // Loop through the cells on the row and add them to the array.
      for (int j = 0; j < this->dataGridView->Rows[i]->Cells->Count; j++)
      {
         if (this->dataGridView->Rows[i]->Cells[j]->Value != nullptr)
            columns[j] = this->dataGridView->Rows[i]->Cells[j]->Value->ToString();
         else
            columns[j] = "";
      }
      // Take the data in the array and concat it together with commas seperating values.
      line = System::String::Join(",", columns);
      // Write the line of data to the file.
      stream->WriteLine(line);
   }

   // Close the file.
   stream->Close();
   return true;
}

System::Boolean MainForm::saveRtdFile(System::String^ filename)
{
   m_saved = true;
   m_filename = filename;
   updateTitle();

   System::IO::StreamWriter^ stream;

   // Open the file.
   try
   {
      stream = System::IO::File::CreateText(filename);
   }
   // Catch any errors.
   catch(...)
   {
      Windows::Forms::MessageBox::Show("Error: Could not open file writing. Make sure it is not locked by another program.", "Error", 
         System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Error);
      return false;
   }

   System::String^ line;
   System::String^ field;
   System::String^ value;

   // Loop through each line of the grid and add it to the file.
   for (int i = 0; i < this->dataGridView->Rows->Count-1; i++)
   {
      line = "";
      
      // Loop through the cells on the row and add them to the array.
      for (int j = 0; j < this->dataGridView->Rows[i]->Cells->Count; j++)
      {
         if (this->dataGridView->Rows[i]->Cells[j]->Value != nullptr)
            value = this->dataGridView->Rows[i]->Cells[j]->Value->ToString();
         else
            value = "0";

         switch (j)
         {
         case 0: field = "y"; break;
         case 1: field = "x"; break;
         case 2: field = "z"; break;
         case 3: field = "h"; break;
         case 4: field = "p"; break;
         case 5: field = "r"; break;
         case 6:
            {
               if (this->dataGridView->Rows[i]->Cells[j]->Value != nullptr)
                  field = this->dataGridView->Rows[i]->Cells[7]->Value->ToString();
               else
                  field = "mph";
               break;
            }
         case 8:
            {
               field = "tfm"; 
               if (value == "0") value = "off"; 
               break;
            }
         case 9: field = "turn_radius"; break;
         }

         // Don't write out on 7 because 6 and 7 are combined to make one set.
         if (j != 7)
         {
            line += field + "=" + value;
            if (j < this->dataGridView->Rows[i]->Cells->Count - 1)
               line += " ";
         }
      }

      // Write the line of data to the file.
      stream->WriteLine(line);
   }

   // Close the file.
   stream->Close();
   return true;
}

System::Windows::Forms::DialogResult MainForm::saveChanges()
{
   // Stop editing.
   this->dataGridView->EndEdit();

   // If the document is already saved, then return ok.
   if (m_saved) return System::Windows::Forms::DialogResult::OK;

   // Get the current filename.
   System::String^ filename = m_filename;

   // Make sure the name is valid.
   if (filename != nullptr && filename != "")
   {
      filename = filename->Substring(filename->LastIndexOf('\\') + 1);
   }
   // Otherwise display "Untitled".
   else
   {
      filename = "Untitled";
   }

   // Ask the user if they want to save their changes.
   System::Windows::Forms::DialogResult result = MessageBox::Show("Do you want to save changes to " + filename + "?", "Save?", 
      MessageBoxButtons::YesNoCancel, MessageBoxIcon::Question, MessageBoxDefaultButton::Button1);

   // Check the button that was pressed.
   switch (result)
   {
   // Yes
   case System::Windows::Forms::DialogResult::Yes:
      saveFile();
      break;
   // No
   case System::Windows::Forms::DialogResult::No:
      break;
   // Cancel
   case System::Windows::Forms::DialogResult::Cancel:
      break;
   }

   return result;
}

System::Void MainForm::updateTitle()
{
   System::String^ filename = m_filename;

   // Make sure the name is valid.
   if (filename != nullptr && filename != "")
   {
      filename = filename->Substring(filename->LastIndexOf('\\') + 1);
      this->Text = "Route Editor - " + filename;
   }
   // Otherwise display "Untitled".
   else
   {
      this->Text = "Route Editor - Untitled";
   }

   // If not saved, add an asterisk to the end.
   if (!m_saved)
      this->Text = this->Text + "*";
}


System::Void MainForm::addWaypoint()
{
   // TODO: Check to see if we are connected to the IG.
   // If we are connected then add a new waypoint at the current IG position.

   int row = 0;
   System::Boolean row_assigned = false;

   // Iterate through the selected cells and find the one in the bottom right corner.
   for (int i=0; i<this->dataGridView->SelectedCells->Count; i++)
   {
      if (this->dataGridView->SelectedCells[i]->RowIndex >= row && !this->dataGridView->Rows[this->dataGridView->SelectedCells[i]->RowIndex]->IsNewRow)
      {
         row = this->dataGridView->SelectedCells[i]->RowIndex + 1;
         row_assigned = true;
      }
   }

   // If the row was not assigned, put it at the bototm

   Ig::Connection::Position position = m_igConnection->getModelPosition(m_cursorMotionSystem);
   bool terrainFollowing = m_igConnection->getModelTerrainFollowing(m_cursorMotionSystem);

   cli::array<System::String^, 1>^ columns = gcnew cli::array<System::String^, 1>(this->dataGridView->ColumnCount);
   columns[0] = Convert::ToString(position.latitude);
   columns[1] = Convert::ToString(position.longitude);
   columns[2] = Convert::ToString(position.altitude);
   columns[3] = Convert::ToString(position.heading);
   columns[4] = Convert::ToString(position.pitch);
   columns[5] = Convert::ToString(position.roll);
   columns[8] = terrainFollowing ? "on" : "off";

   // If there is a row above this one, then copy the speed, units, and radius from there.
   if (row > 0)
   {
      columns[6] = this->dataGridView->Rows[row-1]->Cells[6]->Value->ToString();
      columns[7] = this->dataGridView->Rows[row-1]->Cells[7]->Value->ToString();
      columns[9] = this->dataGridView->Rows[row-1]->Cells[9]->Value->ToString();
   }
   else
   {
      columns[6] = "0";
      columns[7] = "fps";
      columns[9] = "0";
   }

   if (row_assigned)
      this->dataGridView->Rows->Insert(row, columns);
   else
   {
       row = this->dataGridView->Rows->Add(columns);
       //row = this->dataGridView->Rows->Count-1;
   }

   // Move the cursor to the new row.
   this->dataGridView->CurrentCell = this->dataGridView[0, row];
   int motionSystem = this->m_igConnection->getNextAvailableMotionSystem();
   this->dataGridView->Rows[row]->Tag = motionSystem;
   m_igConnection->bindModel(motionSystem, 1);
   // Copy the row to the Ig.
   this->dataGridRowToWaypoint(row);

   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::updateWaypoint()
{
   // Check to see if we are connected to the IG.
   // If we are connected then capture data.
   if (m_igConnection->getState() != Ig::Connection::running)
   {
      MessageBox::Show("You must be connected to an IG to capture waypoint data.", "Cannot Capture Data", 
         System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Information);
   }
   else
   {
      // If there is a row above this one, then copy the speed, units, and radius from there.
      int row = this->dataGridView->CurrentRow->Index;

      if (this->dataGridView->CurrentRow->IsNewRow)
      {
         this->dataGridView->Rows->Add();
         this->dataGridView->CurrentCell = this->dataGridView[0, row];
      }

      this->dataGridView->CurrentRow->Cells[0]->Value = this->textBoxLatitude->Text;
      this->dataGridView->CurrentRow->Cells[1]->Value = this->textBoxLongitude->Text;
      this->dataGridView->CurrentRow->Cells[2]->Value = this->textBoxAltitude->Text;
      this->dataGridView->CurrentRow->Cells[3]->Value = this->textBoxHeading->Text;
      this->dataGridView->CurrentRow->Cells[4]->Value = this->textBoxPitch->Text;
      this->dataGridView->CurrentRow->Cells[5]->Value = this->textBoxRoll->Text;
      this->dataGridView->CurrentRow->Cells[8]->Value = this->dropDownTerrain->Text;

      if (row > 0)
      {
         this->dataGridView->CurrentRow->Cells[6]->Value = 
            this->dataGridView->Rows[row]->Cells[6]->Value;
         this->dataGridView->CurrentRow->Cells[7]->Value = 
            this->dataGridView->Rows[row]->Cells[7]->Value;
         this->dataGridView->CurrentRow->Cells[9]->Value = 
            this->dataGridView->Rows[row]->Cells[9]->Value;
      }
      else
      {
         this->dataGridView->CurrentRow->Cells[6]->Value = "0";
         this->dataGridView->CurrentRow->Cells[7]->Value = "fps";
         this->dataGridView->CurrentRow->Cells[9]->Value = "0";
      }

      // Copy the row to the Ig.
      this->dataGridRowToWaypoint(row);
   }

   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::deleteWaypoint()
{
   // Check to see if we are connected to the IG.
   // If we are connected then remove the waypoint marker on the IG.

   System::Collections::ArrayList^ selected_rows = gcnew System::Collections::ArrayList();


   // Get the selected rows.
   for (int i=0; i<this->dataGridView->Rows->Count; i++)
   {
      System::Boolean row_selected = false;

      // Check to see if any cells in the row are selected.
      for (int k=0; k<this->dataGridView->Rows[i]->Cells->Count; k++)
         if (this->dataGridView->Rows[i]->Cells[k]->Selected)
            row_selected = true;

      if ((this->dataGridView->Rows[i]->Selected || row_selected) && 
         !this->dataGridView->Rows[i]->IsNewRow)
      {
         selected_rows->Add(this->dataGridView->Rows[i]);
         // Remove the waypoint from the Ig.
         if (this->dataGridView->Rows[i]->Tag != nullptr)
         {
            int motionSystem = Convert::ToInt32(this->dataGridView->Rows[i]->Tag);
            m_igConnection->unbindModel(motionSystem);
         }
      }
   }

   for (int i=0; i<selected_rows->Count; i++)
      this->dataGridView->Rows->Remove(dynamic_cast<System::Windows::Forms::DataGridViewRow^>(selected_rows[i]));

      // TODO: if row was modified, update the Ig.


   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::cut()
{
   // Setup an array to hold the data.
   System::String^ data = "";
   System::Collections::ArrayList^ selected_rows = gcnew System::Collections::ArrayList();

   // Stop editing.
   this->dataGridView->EndEdit();

   // Get the selected rows.
   for (int i=0; i<this->dataGridView->Rows->Count; i++)
   {
      System::Boolean row_selected = false;

      // Check to see if any cells in the row are selected.
      for (int k=0; k<this->dataGridView->Rows[i]->Cells->Count; k++)
         if (this->dataGridView->Rows[i]->Cells[k]->Selected)
            row_selected = true;

      // If the row is selected, copy the data into the temporary array.
      if (this->dataGridView->Rows[i]->Selected || row_selected)
      {
         selected_rows->Add(this->dataGridView->Rows[i]);

         for (int j=0; j<this->dataGridView->Rows[i]->Cells->Count; j++)
         {
            if (this->dataGridView->Rows[i]->Cells[j]->Value != nullptr)
               data += this->dataGridView->Rows[i]->Cells[j]->Value->ToString();

            if (j<this->dataGridView->Rows[i]->Cells->Count-1)
               data += "\t";
            else
               data += "\r\n";
         }

         // Remove the row from the Ig.
         if (this->dataGridView->Rows[i]->Tag != nullptr)
            m_igConnection->unbindModel(Convert::ToInt32(this->dataGridView->Rows[i]->Tag));
      }
   }

   // Remove the rows that were selected.
   for (int i=0; i<selected_rows->Count; i++)
      this->dataGridView->Rows->Remove(dynamic_cast<System::Windows::Forms::DataGridViewRow^>(selected_rows[i]));


   if (data != "")
      Clipboard::SetData("Text", data);

   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::copy()
{
   // Setup an array to hold the data.
   System::String^ data = "";
   
   // Stop editing.
   this->dataGridView->EndEdit();

   // Get the selected rows.
   for (int i=0; i<this->dataGridView->Rows->Count; i++)
   {
      System::Boolean row_selected = false;

      // Check to see if any cells in the row are selected.
      for (int k=0; k<this->dataGridView->Rows[i]->Cells->Count; k++)
         if (this->dataGridView->Rows[i]->Cells[k]->Selected)
            row_selected = true;

      if (this->dataGridView->Rows[i]->Selected || row_selected)
      {
         for (int j=0; j<this->dataGridView->Rows[i]->Cells->Count; j++)
         {
            if (this->dataGridView->Rows[i]->Cells[j]->Value != nullptr)
               data += this->dataGridView->Rows[i]->Cells[j]->Value->ToString();

            if (j<this->dataGridView->Rows[i]->Cells->Count-1)
               data += "\t";
            else
               data += "\r\n";
         }
      }
   }

   if (data != "")
      Clipboard::SetData("Text", data);
}

System::Void MainForm::paste()
{
   cli::array<System::String^, 1>^ formats = Clipboard::GetDataObject()->GetFormats();

   // If any cells are in edit mode then take them out of it.
   this->dataGridView->EndEdit();

   // Loop through the formats to see if the one we want is available.
   for (int i=0; i<formats->Length; i++)
   {
      if (formats[i] == "Text")
      {
         System::Object^ data = Clipboard::GetData("Text");
         
         // Parse the data from the clipboard into rows.
         cli::array<System::String^, 1>^ seperators = gcnew cli::array<System::String^, 1>{"\r\n"};
         cli::array<System::String^>^ rows = data->ToString()->Split(seperators, System::StringSplitOptions::RemoveEmptyEntries);

         int row = this->dataGridView->Rows->Count;
         System::Boolean cell_assigned = false;

         // Iterate through the selected cells and find the one at the top.
         for (int i=0; i<this->dataGridView->SelectedCells->Count; i++)
         {
            if (this->dataGridView->SelectedCells[i]->RowIndex < row)
            {
               row = this->dataGridView->SelectedCells[i]->RowIndex;
               cell_assigned = true;
            }
         }
            
         if (!cell_assigned)
         {
            row = 0;
         }

         // Make sure there are enough rows in the datagrid to hold the new data.
         int count = this->dataGridView->Rows->Count;
         int needed = row + rows->Length;

         // Insert rows.
         this->dataGridView->Rows->Insert(row, rows->Length);

         // Setup an array to hold the different seperators in the data.
         seperators = gcnew cli::array<System::String^, 1>{"\t", ","};

         // Now copy the data into the cells.
         for (int i=0; i<rows->Length; i++)
         {
            // Split the row of data by the seperators above.
            cli::array<System::String^, 1>^ cells = rows[i]->Split(seperators, System::StringSplitOptions::None);

            // Loop through each piece of data and copy it into the datagrid.
            for (int j=0; j<cells->Length; j++)
            {
               if (j< this->dataGridView->ColumnCount)
               {
                  this->dataGridView->Rows[row + i]->Cells[j]->Value = cells[j];
               }
            }

            // Copy the row data to the Ig.
            this->dataGridRowToWaypoint(row + i);
         }

         this->dataGridView->EndEdit();

         break;
      }
   }

   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::fillUp()
{
   // Loop through the columns and find cells that are selected. Then copy the data
   // from the bottom most cell into the cells above it.

   // Stop editing.
   this->dataGridView->EndEdit();

   for (int i=0; i<this->dataGridView->Columns->Count; i++)
   {
      // Loop through the rows in the column starting from the bottom.
      for (int j=this->dataGridView->Rows->Count-1; j>=0; j--)
      {
         // If a cell is found then copy the data up and then
         // break out of the loop.
         if (this->dataGridView->Rows[j]->Cells[i]->Selected)
         {
            for (int k=j; k>=0; k--)
            {
               // Only update the value if it is selected.
               if (this->dataGridView->Rows[k]->Cells[i]->Selected)
               {
                  this->dataGridView->Rows[k]->Cells[i]->Value = 
                     this->dataGridView->Rows[j]->Cells[i]->Value;
               }
            }

            break;
         }
      }
   }

   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::fillDown()
{
   // Loop through the columns and find cells that are selected. Then copy the data
   // from the top most cell into the cells under it.

   // Stop editing.
   this->dataGridView->EndEdit();

   for (int i=0; i<this->dataGridView->Columns->Count; i++)
   {
      // Loop through the rows in the column starting from the top.
      for (int j=0; j<this->dataGridView->Rows->Count; j++)
      {
         // If a cell is found then copy the data up and then
         // break out of the loop.
         if (this->dataGridView->Rows[j]->Cells[i]->Selected)
         {
            for (int k=j; k<this->dataGridView->Rows->Count; k++)
            {
               // Only update the value if it is selected.
               if (this->dataGridView->Rows[k]->Cells[i]->Selected)
               {
                  this->dataGridView->Rows[k]->Cells[i]->Value = 
                     this->dataGridView->Rows[j]->Cells[i]->Value;
               }
            }

            break;
         }
      }
   }

   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::loadSettings()
{
   System::IO::StreamReader^ stream;

   // Default settings.
   m_modelFilename = "bus";
   m_maxVelocity = 500;
   m_maxAngularVelocity = 0.125;
   m_deadZone = 0.2;


   // Open the file.
   try
   {
      stream = System::IO::File::OpenText("settings.txt");
   }
   // Catch any errors.
   catch(...)
   {
      return;
   }

   System::String^ line;

   // Loop through each line of the file and read them.
   while (!stream->EndOfStream)
   {
      // Read a line of data from the file.
      line = stream->ReadLine();
      // Make sure the line has data.
      if (line->Trim() != "")
      {
         // Split the line by equal signs.
         cli::array<System::String^, 1>^ data = line->Split('=');
         // Make sure there are at least two values.
         if (data->Length > 1)
         {
            if (data[0]->ToLower() == "max_velocity")
               m_maxVelocity = System::Convert::ToDouble(data[1]);
            if (data[0]->ToLower() == "max_angular_velocity")
               m_maxAngularVelocity = System::Convert::ToDouble(data[1]);
            if (data[0]->ToLower() == "dead_zone")
               m_deadZone = System::Convert::ToDouble(data[1]);
            if (data[0]->ToLower() == "model_file_name")
               m_modelFilename = data[1];
            if (data[0]->ToLower() == "latitude")
               m_startLatitude = System::Convert::ToDouble(data[1]);
            if (data[0]->ToLower() == "longitude")
               m_startLongitude = System::Convert::ToDouble(data[1]);
            if (data[0]->ToLower() == "altitude")
               m_startAltitude = System::Convert::ToDouble(data[1]);
            if (data[0]->ToLower() == "heading")
               m_startHeading = System::Convert::ToDouble(data[1]);
         }
      }
   }
   
   // Close the file.
   stream->Close();
   return;  
}

System::Void MainForm::saveSettings()
{
   updateTitle();

   System::IO::StreamWriter^ stream;

   // Open the file.
   try
   {
      stream = System::IO::File::CreateText("settings.txt");
   }
   // Catch any errors.
   catch(...)
   {
      Windows::Forms::MessageBox::Show("Error: Could not open settings file writing. Make sure it is not locked by another program.", "Error", 
         System::Windows::Forms::MessageBoxButtons::OK, System::Windows::Forms::MessageBoxIcon::Error);
      return;
   }

      
   // Write the settings to the file.
   stream->WriteLine("max_velocity=" + System::Convert::ToString(m_maxVelocity));
   stream->WriteLine("max_angular_velocity=" + System::Convert::ToString(m_maxAngularVelocity));
   stream->WriteLine("dead_zone=" + System::Convert::ToString(m_deadZone));
   stream->WriteLine("model_file_name=" + m_modelFilename);
   stream->WriteLine("latitude=" + m_startLatitude);
   stream->WriteLine("longitude=" + m_startLongitude);
   stream->WriteLine("altitude=" + m_startAltitude);
   stream->WriteLine("heading=" + m_startHeading);


   // Close the file.
   stream->Close();
   return;
}


System::Void MainForm::connect()
{
   // Lock the toolbar.
   this->textBoxIP->Enabled = false;
   this->textBoxPort->Enabled = false;
   // Hide the connect button.
   this->toolStripButtonConnect->Visible = false;
   // Show the disconnect button.
   this->toolStripButtonDisconnect->Visible = true;

   // Reset some settings...
   this->toolStripButtonEyepoint->Checked = false;
   this->toolStripButtonCursor->Checked = true;


   // Open the connection.
   this->m_igConnection->open(toStdString(this->textBoxIP->Text).c_str(), 
      System::Convert::ToInt32(this->textBoxPort->Text));

   // Load models.
   m_igConnection->loadModel(1, toStdString(this->m_modelFilename).c_str());
   // Bind the cursor model.
   m_igConnection->bindModel(m_cursorMotionSystem, 1);

   // Chain the eyepoint.
   chain();

   // Set the cursor position to the starting point.
   Ig::Connection::Position position;
   position.latitude = m_startLatitude;
   position.longitude = m_startLongitude;
   position.altitude = m_startAltitude;
   position.heading = m_startHeading;
   m_igConnection->setModelPosition(m_cursorMotionSystem, position);

   // Iterate through the grid rows and assign motion systems.
   for (int i=0; i<this->dataGridView->Rows->Count; i++)
   {
      int motionSystem = m_igConnection->getNextAvailableMotionSystem();
      this->dataGridView->Rows[i]->Tag = motionSystem;
      m_igConnection->bindModel(motionSystem, 1);
      // Copy the row to the Ig.
      this->dataGridRowToWaypoint(i);
   }
}

System::Void MainForm::disconnect()
{
   // Close the connection.
   this->m_igConnection->close();
   // Disable the disconnect button so they don't keep hitting it.
   this->toolStripButtonDisconnect->Enabled = false;
}


std::string MainForm::toStdString(System::String^ s)
{
   if (System::String::IsNullOrEmpty(s)) return "";

   std::string temp;
   const char* chars = (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
   temp = chars;
   Marshal::FreeHGlobal (IntPtr((void*)chars));
   return temp;
}


System::Void MainForm::disableLocationBar()
{
   // Show the update location button.
   this->toolStripButtonUpdateLocation->Visible = true;
   // Show the OK and Cancel buttons.
   this->toolStripButtonOK->Visible = false;
   this->toolStripButtonCancel->Visible = false;
   // Disable the textboxes.
   this->textBoxLatitude->Enabled = false;
   this->textBoxLongitude->Enabled = false;
   this->textBoxAltitude->Enabled = false;
   this->textBoxHeading->Enabled = false;
   this->textBoxPitch->Enabled = false;
   this->textBoxRoll->Enabled = false;
   this->dropDownTerrain->Enabled = false;
}

System::Void MainForm::enableLocationBar()
{
   // Hide the update location button.
   this->toolStripButtonUpdateLocation->Visible = false;
   // Show the OK and Cancel buttons.
   this->toolStripButtonOK->Visible = true;
   this->toolStripButtonCancel->Visible = true;
   // Enable the textboxes.
   this->textBoxLatitude->Enabled = true;
   this->textBoxLongitude->Enabled = true;
   this->textBoxAltitude->Enabled = true;
   this->textBoxHeading->Enabled = true;
   this->textBoxPitch->Enabled = true;
   this->textBoxRoll->Enabled = true;
   this->dropDownTerrain->Enabled = true;
}

System::Void MainForm::dataGridRowToWaypoint(int row)
{
   if (this->dataGridView->Rows->Count > row)
   {
      if (this->dataGridView->Rows[row] != nullptr)
      {
         int motionSystem = 0;

         // Make sure there is a motion system.
         if (this->dataGridView->Rows[row]->Tag == nullptr)
         {
            motionSystem = m_igConnection->getNextAvailableMotionSystem();
            m_igConnection->bindModel(motionSystem, 1);
            this->dataGridView->Rows[row]->Tag = motionSystem;
         }
         else
         {
            // Get the motion system number.
            motionSystem = Convert::ToInt32(this->dataGridView->Rows[row]->Tag);
         }

         // Position the model.
         Ig::Connection::Position position;
         if (this->dataGridView->Rows[row]->Cells[0]->Value != nullptr &&
            this->dataGridView->Rows[row]->Cells[0]->Value->ToString() != "") 
            position.latitude = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[0]->Value);
         if (this->dataGridView->Rows[row]->Cells[1]->Value != nullptr&&
            this->dataGridView->Rows[row]->Cells[1]->Value->ToString() != "")
            position.longitude = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[1]->Value);
         if (this->dataGridView->Rows[row]->Cells[2]->Value != nullptr&&
            this->dataGridView->Rows[row]->Cells[2]->Value->ToString() != "")
            position.altitude = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[2]->Value);
         if (this->dataGridView->Rows[row]->Cells[3]->Value != nullptr&&
            this->dataGridView->Rows[row]->Cells[3]->Value->ToString() != "")
            position.heading = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[3]->Value);
         if (this->dataGridView->Rows[row]->Cells[4]->Value != nullptr &&
            this->dataGridView->Rows[row]->Cells[4]->Value->ToString() != "")
            position.pitch = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[4]->Value);
         if (this->dataGridView->Rows[row]->Cells[5]->Value != nullptr &&
            this->dataGridView->Rows[row]->Cells[5]->Value->ToString() != "")
            position.roll = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[5]->Value);

         m_igConnection->setModelPosition(motionSystem, position);

         // Set terrain following
         if (this->dataGridView->Rows[row]->Cells[8]->Value != nullptr)
         {
            if (this->dataGridView->Rows[row]->Cells[8]->Value->ToString() == "on")
               m_igConnection->setModelTerrainFollowing(motionSystem, true);
            else
               m_igConnection->setModelTerrainFollowing(motionSystem, false);
         }
      }
   }
}

System::Void MainForm::dataGridRowToMotionSystem(int row, int motionSystem)
{
   if (this->dataGridView->Rows->Count > row)
   {
      if (this->dataGridView->Rows[row] != nullptr)
      {
         // Position the model.
         Ig::Connection::Position position;
         if (this->dataGridView->Rows[row]->Cells[0]->Value != nullptr &&
            this->dataGridView->Rows[row]->Cells[0]->Value->ToString() != "") 
            position.latitude = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[0]->Value);
         if (this->dataGridView->Rows[row]->Cells[1]->Value != nullptr&&
            this->dataGridView->Rows[row]->Cells[1]->Value->ToString() != "")
            position.longitude = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[1]->Value);
         if (this->dataGridView->Rows[row]->Cells[2]->Value != nullptr&&
            this->dataGridView->Rows[row]->Cells[2]->Value->ToString() != "")
            position.altitude = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[2]->Value);
         if (this->dataGridView->Rows[row]->Cells[3]->Value != nullptr&&
            this->dataGridView->Rows[row]->Cells[3]->Value->ToString() != "")
            position.heading = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[3]->Value);
         if (this->dataGridView->Rows[row]->Cells[4]->Value != nullptr &&
            this->dataGridView->Rows[row]->Cells[4]->Value->ToString() != "")
            position.pitch = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[4]->Value);
         if (this->dataGridView->Rows[row]->Cells[5]->Value != nullptr &&
            this->dataGridView->Rows[row]->Cells[5]->Value->ToString() != "")
            position.roll = Convert::ToDouble(this->dataGridView->Rows[row]->Cells[5]->Value);

         m_igConnection->setModelPosition(motionSystem, position);

         // Set terrain following
         if (this->dataGridView->Rows[row]->Cells[8]->Value != nullptr)
         {
            if (this->dataGridView->Rows[row]->Cells[8]->Value->ToString() == "on")
               m_igConnection->setModelTerrainFollowing(motionSystem, true);
            else
               m_igConnection->setModelTerrainFollowing(motionSystem, false);
         }
      }
   }
}

System::Void MainForm::chain()
{
   this->toolStripButtonChain->Checked = true;
   this->toolStripButtonUnchain->Checked = false;

   Ig::Connection::Position position;
   position.latitude = 0;  // x offset.
   position.longitude = -300;   // y offset.
   position.altitude = 100;  // z offset.
   position.pitch = -15;

   // Chain it.
   this->m_igConnection->setModelParent(m_eyepointMotionSystem, m_cursorMotionSystem);
   this->m_igConnection->setModelPosition(m_eyepointMotionSystem, position); 

}

System::Void MainForm::unchain()
{
   this->toolStripButtonChain->Checked = false;
   this->toolStripButtonUnchain->Checked = true;

   // Unchain it.
   this->m_igConnection->setModelParent(m_eyepointMotionSystem, 1);
   this->m_igConnection->setModelPosition(m_eyepointMotionSystem, 
      m_igConnection->getModelPosition(m_eyepointMotionSystem)); 
}


// Toolstrip Button Handlers

System::Void MainForm::toolStripButtonNew_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->newFile();
}

System::Void MainForm::toolStripButtonOpen_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->openFile();
}

System::Void MainForm::toolStripButtonSave_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->saveFile();
}

System::Void MainForm::toolStripButtonNewRecord_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->addWaypoint();
}

System::Void MainForm::toolStripButtonUpdateRecord_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->updateWaypoint();
}

System::Void MainForm::toolStripButtonDeleteRecord_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->deleteWaypoint();
}

System::Void MainForm::toolStripButtonCut_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->cut();
}

System::Void MainForm::toolStripButtonCopy_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->copy();
}

System::Void MainForm::toolStripButtonPaste_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->paste();
}

System::Void MainForm::toolStripButtonFillUp_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->fillUp();
}

System::Void MainForm::toolStripButtonFillDown_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->fillDown();
}

System::Void MainForm::toolStripButtonConnect_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->connect();
}

System::Void MainForm::toolStripButtonDisconnect_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->disconnect();
}


System::Void MainForm::toolStripButtonUpdateLocation_Click(System::Object^  sender, System::EventArgs^  e)
{
   // Enable editing of the location bar.
   enableLocationBar();
}

System::Void MainForm::toolStripButtonOK_Click(System::Object^  sender, System::EventArgs^  e)
{
   // Check to see if the eyepoint is chained.
   if (this->toolStripButtonChain->Checked && this->toolStripButtonEyepoint->Checked)
   {
      System::Windows::Forms::DialogResult result = 
         System::Windows::Forms::MessageBox::Show("Warning: The eyepoint is currently chained. Setting the eyepoint position will unchain the eyepoint. Are you sure you want to do this?", 
         "Warning", System::Windows::Forms::MessageBoxButtons::YesNo, 
         System::Windows::Forms::MessageBoxIcon::Warning, 
         System::Windows::Forms::MessageBoxDefaultButton::Button1);

      // If the user says no, then exit.
      if (result == System::Windows::Forms::DialogResult::No)
      {
         return;
      }
      // Otherwise break the chain.
      else
      {
         this->m_igConnection->setModelParent(m_eyepointMotionSystem, 1);
         this->toolStripButtonChain->Enabled = false;
      }
   }

   // Copy the position from the location bar to the Ig.
   Ig::Connection::Position position;
   if (!System::String::IsNullOrEmpty(this->textBoxLatitude->Text))
      position.latitude = Convert::ToDouble(this->textBoxLatitude->Text);
   if (!System::String::IsNullOrEmpty(this->textBoxLongitude->Text))
      position.longitude = Convert::ToDouble(this->textBoxLongitude->Text);
   if (!System::String::IsNullOrEmpty(this->textBoxAltitude->Text))
      position.altitude = Convert::ToDouble(this->textBoxAltitude->Text);
   if (!System::String::IsNullOrEmpty(this->textBoxHeading->Text))
      position.heading = Convert::ToDouble(this->textBoxHeading->Text);
   if (!System::String::IsNullOrEmpty(this->textBoxPitch->Text))
      position.pitch = Convert::ToDouble(this->textBoxPitch->Text);
   if (!System::String::IsNullOrEmpty(this->textBoxRoll->Text))
      position.roll = Convert::ToDouble(this->textBoxRoll->Text);
   
   // Correct any errors.
   if (position.latitude < -90) position.latitude = -90;
   if (position.latitude > 90) position.latitude = 90;
   if (position.longitude < -180) position.longitude = -180;
   if (position.longitude > 180) position.longitude = 180;
   if (position.heading < -180) position.heading = -180;
   if (position.heading > 180) position.heading = 180;
   if (position.pitch < -180) position.pitch = -180;
   if (position.pitch > 180) position.pitch = 180;
   if (position.roll < -180) position.roll = -180;
   if (position.roll > 180) position.roll = 180;

   // Copy corrected values back.
   this->textBoxLatitude->Text = Convert::ToString(position.latitude);
   this->textBoxLongitude->Text = Convert::ToString(position.longitude);
   this->textBoxAltitude->Text = Convert::ToString(position.altitude);
   this->textBoxHeading->Text = Convert::ToString(position.heading);
   this->textBoxPitch->Text = Convert::ToString(position.pitch);
   this->textBoxRoll->Text = Convert::ToString(position.roll);

   bool terrainFollowing = false;
   if (this->dropDownTerrain->Text == "on")
      terrainFollowing = true;

   if (this->toolStripButtonEyepoint->Checked)
   {
      m_igConnection->setModelPosition(m_eyepointMotionSystem, position);
      // Only update terrain following if it has changed.
      if (m_igConnection->getModelTerrainFollowing(m_eyepointMotionSystem) != terrainFollowing)
         m_igConnection->setModelTerrainFollowing(m_eyepointMotionSystem, terrainFollowing);
   }
   else
   {
      m_igConnection->setModelPosition(m_cursorMotionSystem, position);
      // Only update terrain following if it has changed.
      if (m_igConnection->getModelTerrainFollowing(m_cursorMotionSystem) != terrainFollowing)
         m_igConnection->setModelTerrainFollowing(m_cursorMotionSystem, terrainFollowing);
   }



   // Disable editing of the location bar.
   disableLocationBar();
}

System::Void MainForm::toolStripButtonCancel_Click(System::Object^  sender, System::EventArgs^  e)
{
   // Disable editing of the location bar.
   disableLocationBar();
}

System::Void MainForm::toolStripButtonEyepoint_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->toolStripButtonEyepoint->Checked = true;
   this->toolStripButtonCursor->Checked = false;
}

System::Void MainForm::toolStripButtonCursor_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->toolStripButtonEyepoint->Checked = false;
   this->toolStripButtonCursor->Checked = true;
}

System::Void MainForm::toolStripButtonChain_Click(System::Object^  sender, System::EventArgs^  e)
{
   chain();
}

System::Void MainForm::toolStripButtonUnchain_Click(System::Object^  sender, System::EventArgs^  e)
{
   unchain();
}

System::Void MainForm::toolStripButtonExecute_Click(System::Object^  sender, System::EventArgs^  e)
{
   if (!System::String::IsNullOrEmpty(this->textBoxCommand->Text))
   {
      m_igConnection->sendCliCommand(toStdString(this->textBoxCommand->Text).c_str());
      this->textBoxCommand->Text = "";
   }
}


// Menu Item Event Handlers

System::Void MainForm::newToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->newFile();
}

System::Void MainForm::openToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->openFile();
}

System::Void MainForm::saveToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->saveFile();
}

System::Void MainForm::saveAsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->saveAsFile();
}

System::Void MainForm::exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->Close();
}

System::Void MainForm::cutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->cut();
}

System::Void MainForm::copyToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->copy();
}

System::Void MainForm::pasteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->paste();
}

System::Void MainForm::deleteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->deleteWaypoint();
}

System::Void MainForm::selectAllToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->dataGridView->SelectAll();
}

System::Void MainForm::settingsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   // Create an instance of the Settings form.
   SettingsForm^ settings = gcnew SettingsForm();
   
   // Set the values on the form.
   settings->setMaxVelocity(m_maxVelocity);
   settings->setMaxAngularVelocity(m_maxAngularVelocity);
   settings->setDeadZone(m_deadZone);
   settings->setModelFilename(m_modelFilename);

   settings->setLatitude(m_startLatitude);
   settings->setLongitude(m_startLongitude);
   settings->setAltitude(m_startAltitude);
   settings->setHeading(m_startHeading);
   

   // Show the form and get the result (ok or cancel).
   System::Windows::Forms::DialogResult result = settings->ShowDialog(this);
   // If the user clicks ok do stuff with the data.
   if (result == System::Windows::Forms::DialogResult::OK)
   {
      m_maxVelocity = settings->getMaxVelocity();
      m_maxAngularVelocity = settings->getMaxAngularVelocity();
      m_deadZone = settings->getDeadZone();
      m_modelFilename = settings->getModelFilename();
      m_startLatitude = settings->getLatitude();
      m_startLongitude = settings->getLongitude();
      m_startAltitude = settings->getAltitude();
      m_startHeading = settings->getHeading();

      // Apply the joystick settings.
      m_joystick->setDeadZone(m_deadZone);
      // Load the model.
      m_igConnection->loadModel(1, toStdString(m_modelFilename).c_str());

   }
}

//
// These methods hide/show toolbars based on the checked status of menu items.
//
System::Void MainForm::standardToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   this->toolStripMain->Visible = this->standardToolStripMenuItem->Checked;
}

System::Void MainForm::connectionToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   this->toolStripConnect->Visible = this->connectionToolStripMenuItem->Checked;
}

System::Void MainForm::locationToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   this->toolStripLocation->Visible = this->locationToolStripMenuItem->Checked;
}

System::Void MainForm::commandToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   this->toolStripCommand->Visible = this->commandToolStripMenuItem->Checked;
}


System::Void MainForm::statusBarToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   this->statusStrip->Visible = this->statusBarToolStripMenuItem->Checked;
}


System::Void MainForm::dataGridView_CellValueChanged(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e)
{
   if (e->RowIndex < 0) return;

   // If the value is null then don't do anything.
   if (this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value == nullptr ||
      this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value == "" ||
      System::String::IsNullOrEmpty(this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString()))
   {
      this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = "0";
      return;
   }

   // Check the value based on the column.
   switch(e->ColumnIndex)
   {
      // Latitude
      case 0:
      {
         try
         {
            double value = System::Convert::ToDouble(this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString());
            if (value < -90.0) value = -90.0;
            if (value > 90.0) value = 90.0;
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = value;
         }
         catch (...)
         {
            MessageBox::Show("Error: " + this->dataGridView->Columns[e->ColumnIndex]->HeaderText + 
               " must be numeric.", "Error", System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = "";
         }
         break;
      }

      // Longitude
      case 1:
      {
         try
         {
            double value = System::Convert::ToDouble(this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString());
            if (value < -180.0) value = -180.0;
            if (value > 180.0) value = 180.0;
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = value;
         }
         catch (...)
         {
            MessageBox::Show("Error: " + this->dataGridView->Columns[e->ColumnIndex]->HeaderText + 
               " must be numeric.", "Error", System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = "";
         }
         break;
      }

      // Altitude
      case 2:
      {
         try
         {
            double value = System::Convert::ToDouble(this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString());
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = value;
         }
         catch (...)
         {
            MessageBox::Show("Error: " + this->dataGridView->Columns[e->ColumnIndex]->HeaderText + 
               " must be numeric.", "Error", System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = "";
         }
         break;
      }
      
      // Heading, Pitch, Roll
      case 3:
      case 4:
      case 5:
      {
         try
         {
            double value = System::Convert::ToDouble(this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString());
            if (value < -180.0) value = -180.0;
            if (value > 180.0) value = 180.0;
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = value;
         }
         catch (...)
         {
            MessageBox::Show("Error: " + this->dataGridView->Columns[e->ColumnIndex]->HeaderText + 
               " must be numeric.", "Error", System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = "";
         }
         break;
      }

      // Speed, Turn Radius
      case 6:
      case 9:
      {
         try
         {
            double value = System::Convert::ToDouble(this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString());
            if (value < 0.0) value = 0.0;
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = value;
         }
         catch (...)
         {
            MessageBox::Show("Error: " + this->dataGridView->Columns[e->ColumnIndex]->HeaderText + 
               " must be numeric.", "Error", System::Windows::Forms::MessageBoxButtons::OK,
               System::Windows::Forms::MessageBoxIcon::Error);
            this->dataGridView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value = "";
         }
         break;
      }
   }

   // Copy the row data to the Ig.
   this->dataGridRowToWaypoint(e->RowIndex);
   // Set the saved flag.
   m_saved = false;
   updateTitle();
}

System::Void MainForm::dataGridView_RowEnter(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e)
{
   // Update the status label.
   this->statusLabel->Text = System::String::Format("Waypoint: {0}", e->RowIndex);
}

System::Void MainForm::dataGridView_RowLeave(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e)
{
   // Blank out the status bar when we leave a row.
   this->statusLabel->Text = "";
}

System::Void MainForm::dataGridView_DataError(System::Object^  sender, System::Windows::Forms::DataGridViewDataErrorEventArgs^  e)
{
   // If there is an error in the data, don't throw an exception.
   e->ThrowException = false;
}

System::Void MainForm::dataGridView_CellDoubleClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e)
{

}

System::Void MainForm::dataGridView_RowHeaderMouseDoubleClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellMouseEventArgs^  e)
{
   // When the user double clicks a cell, then copy the row data into the location bar.
   if (this->dataGridView->Rows[e->RowIndex]->Cells[0]->Value != nullptr)
      this->textBoxLatitude->Text = this->dataGridView->Rows[e->RowIndex]->Cells[0]->Value->ToString();
   if (this->dataGridView->Rows[e->RowIndex]->Cells[1]->Value != nullptr)
      this->textBoxLongitude->Text = this->dataGridView->Rows[e->RowIndex]->Cells[1]->Value->ToString();
   if (this->dataGridView->Rows[e->RowIndex]->Cells[2]->Value != nullptr)
      this->textBoxAltitude->Text = this->dataGridView->Rows[e->RowIndex]->Cells[2]->Value->ToString();
   if (this->dataGridView->Rows[e->RowIndex]->Cells[3]->Value != nullptr)
      this->textBoxHeading->Text = this->dataGridView->Rows[e->RowIndex]->Cells[3]->Value->ToString();
   if (this->dataGridView->Rows[e->RowIndex]->Cells[4]->Value != nullptr)
      this->textBoxPitch->Text = this->dataGridView->Rows[e->RowIndex]->Cells[4]->Value->ToString();
   if (this->dataGridView->Rows[e->RowIndex]->Cells[5]->Value != nullptr)
      this->textBoxRoll->Text = this->dataGridView->Rows[e->RowIndex]->Cells[5]->Value->ToString();
   if (this->dataGridView->Rows[e->RowIndex]->Cells[8]->Value != nullptr)
      this->dropDownTerrain->Text = this->dataGridView->Rows[e->RowIndex]->Cells[8]->Value->ToString();
   
   // Move the cursor there.
   if (this->toolStripButtonEyepoint->Checked && !this->toolStripButtonChain->Checked)
      this->dataGridRowToMotionSystem(e->RowIndex, m_eyepointMotionSystem);
   else
      this->dataGridRowToMotionSystem(e->RowIndex, m_cursorMotionSystem);
}


System::Void MainForm::MainForm_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e)
{
   // Confirm any unsaved changes. If the user presses cancel then stop the form from closing.
   if (saveChanges() == System::Windows::Forms::DialogResult::Cancel)
      e->Cancel = true;
   // Save settings.
   saveSettings();
   
}

System::Void MainForm::MainForm_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e)
{
}

System::Void MainForm::textBoxCommand_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e)
{
   if (e->KeyCode == System::Windows::Forms::Keys::Enter)
   {
      if (!System::String::IsNullOrEmpty(this->textBoxCommand->Text))
      {
         m_igConnection->sendCliCommand(toStdString(this->textBoxCommand->Text).c_str());
         this->textBoxCommand->AutoCompleteCustomSource->Add(this->textBoxCommand->Text);
         this->textBoxCommand->Text = "";
      }
   }
}

System::Void MainForm::timer_Tick(System::Object^  sender, System::EventArgs^  e)
{
   // The timer monitors the state of the ig connection and displays it
   // in the status bar of the window.

   
   // Disable the timer so it isn't ticking away while we are doing work.
   this->timer->Enabled = false;


   // Check the current state.
   switch(m_igConnection->getState())
   {
   // Not Connected.
   case Ig::Connection::offline:
      {
         // If the disconnect button is visible and we are here,
         // then the Ig disconnected. Display a message.
         if (this->toolStripButtonDisconnect->Visible == true &&
            this->toolStripButtonDisconnect->Enabled == true)
         {
            Windows::Forms::MessageBox::Show("Error: Lost connection to the Image Generator. Ensure that the Image Generator is running and cables are connected.", 
               "Error", System::Windows::Forms::MessageBoxButtons::OK, 
               System::Windows::Forms::MessageBoxIcon::Error);
         }
         this->connectionStatusLabel->Text = "IG Status: Offline.";
         // Unlock the connection toolbar.
         this->textBoxIP->Enabled = true;
         this->textBoxPort->Enabled = true;
         // Show the connect button.
         this->toolStripButtonConnect->Visible = true;
         // Hide the disconnect button.
         this->toolStripButtonDisconnect->Visible = false;
         this->toolStripButtonDisconnect->Enabled = true;

         // Disable editing of the location bar.
         disableLocationBar();
         // Disable the update location button.
         this->toolStripButtonUpdateLocation->Enabled = false;
         this->toolStripButtonUpdateRecord->Enabled = false;
         this->toolStripButtonEyepoint->Enabled = false;
         this->toolStripButtonCursor->Enabled = false;
         this->toolStripButtonChain->Enabled = false;
         this->toolStripButtonUnchain->Enabled = false;

         this->toolStripButtonExecute->Enabled = false;
         this->textBoxCommand->Enabled = false;
      }
      break;

   // Connecting.
   case Ig::Connection::connecting: 
      this->connectionStatusLabel->Text = "IG Status: Connecting..."; 
      break;

   // Loading.
   case Ig::Connection::loading:
      this->connectionStatusLabel->Text = "IG Status: Loading..."; 
      break;

   // Waiting.
   case Ig::Connection::waiting:
      this->connectionStatusLabel->Text = "IG Status: Waiting..."; 
      break;

   // Running.
   case Ig::Connection::running:
      {


         // Enable the update location button.
         this->toolStripButtonUpdateLocation->Enabled = true;
         this->toolStripButtonUpdateRecord->Enabled = true;
         this->toolStripButtonEyepoint->Enabled = true;
         this->toolStripButtonCursor->Enabled = true;
         this->toolStripButtonChain->Enabled = true;
         this->toolStripButtonUnchain->Enabled = true;
         this->toolStripButtonExecute->Enabled = true;
         this->textBoxCommand->Enabled = true;
         this->connectionStatusLabel->Text = "IG Status: Running."; 
      }
      break;

   // Disconnecting.
   case Ig::Connection::disconnecting:
      {
         this->connectionStatusLabel->Text = "IG Status: Disconnecting..."; 
         // Disable editing of the location bar.
         disableLocationBar();
         // Disable the update location button.
         this->toolStripButtonUpdateLocation->Enabled = false;
      }
      break;
   }
 

   // Turn the timer back on so it isn't ticking away while we are doing work.
   this->timer->Enabled = true;
}

System::Void MainForm::timerJoystick_Tick(System::Object^  sender, System::EventArgs^  e)
{
   // Disable the timer so it isn't ticking away while we are doing work.
   this->timerJoystick->Enabled = false;
   static bool button1Pressed = false;
   static bool button2Pressed = false;
   static bool button3Pressed = false;
   
   // Get joystick status.
   m_joystick->checkInput();

   // Send joystick velocity to the ig.
   if (m_joystick->isConnected())
   {
      Ig::Connection::Velocity velocity;
      velocity.roll = m_joystick->getXAxis() * m_maxAngularVelocity;
      velocity.pitch = m_joystick->getYAxis() * m_maxAngularVelocity;
      if (m_joystick->getHasZ())
         velocity.y = m_joystick->getZAxis() * -m_maxVelocity;
      if (m_joystick->getHasR())
         velocity.heading = m_joystick->getRAxis() * m_maxAngularVelocity;
      if (m_joystick->getHasPov())
      {
         switch(m_joystick->getPov())
         {
         case Joystick::e_JoyPovBackward: velocity.z = -m_maxVelocity; break;
         case Joystick::e_JoyPovForward: velocity.z = m_maxVelocity; break;
         case Joystick::e_JoyPovLeft: velocity.x = -m_maxVelocity; break;
         case Joystick::e_JoyPovRight: velocity.x = m_maxVelocity; break;
         }
      }

      // If in eyepoint mode, set the eyepoint velocity and zero out the cursor.
      if (this->toolStripButtonEyepoint->Checked)
      {
         m_igConnection->setModelVelocity(m_eyepointMotionSystem, velocity);
         m_igConnection->setModelVelocity(m_cursorMotionSystem, Ig::Connection::Velocity());
      }
      // otherwise do it the other way around.
      else
      {
         m_igConnection->setModelVelocity(m_eyepointMotionSystem, Ig::Connection::Velocity());
         m_igConnection->setModelVelocity(m_cursorMotionSystem, velocity);
      }

      // If button 1 is pressed and wasn't last time, get a waypoint.
      if (m_joystick->getButton(1) && !button1Pressed)
      {
         this->addWaypoint();
         button1Pressed = true;
      }
      else
      {
         button1Pressed = false;
      }

      // If button 2 is pressed and wasn't last time, delete a waypoint.
      if (m_joystick->getButton(2) && !button2Pressed)
      {
         this->deleteWaypoint();
         button2Pressed = true;
      }
      else
      {
         button2Pressed = false;
      }

      // If button 3 is pressed and wasn't last time, update a waypoint.
      if (m_joystick->getButton(3) && !button3Pressed)
      {
         this->updateWaypoint();
         button3Pressed = true;
      }
      else
      {
         button3Pressed = false;
      }
   }

   // Enable the timer again.
   this->timerJoystick->Enabled = true;
}

System::Void MainForm::timerLocation_Tick(System::Object^  sender, System::EventArgs^  e)
{

   this->timerLocation->Enabled = false;

   // If in the running state, then update some things.
   if (m_igConnection->getState() == Ig::Connection::running)
   {
      // Request the eyepoint position.
      m_igConnection->requestModelPosition(m_eyepointMotionSystem);
      m_igConnection->requestModelPosition(m_cursorMotionSystem);

      // Get the current location and copy it to the location bar.
      // Only do it if the position isn't being edited by the user.
      if (this->toolStripButtonUpdateLocation->Visible)
      {
         Ig::Connection::Position position;
         bool terrainFollowing;

         // If the eyepoint button is selected, get the eyepoint position.
         if (this->toolStripButtonEyepoint->Checked)
         {
            position = m_igConnection->getModelPosition(m_eyepointMotionSystem);
            terrainFollowing = m_igConnection->getModelTerrainFollowing(m_eyepointMotionSystem);
         }
         // Otherwise get the cursor location.
         else
         {
            position = m_igConnection->getModelPosition(m_cursorMotionSystem);
            terrainFollowing = m_igConnection->getModelTerrainFollowing(m_cursorMotionSystem);
         }

         this->textBoxLatitude->Text = Convert::ToString(position.latitude);
         this->textBoxLongitude->Text = Convert::ToString(position.longitude);
         this->textBoxAltitude->Text = Convert::ToString(position.altitude);
         this->textBoxHeading->Text = Convert::ToString(position.heading);
         this->textBoxPitch->Text = Convert::ToString(position.pitch);
         this->textBoxRoll->Text = Convert::ToString(position.roll);

         // Get the state of the terrain following flag.
          
         if (terrainFollowing)
            this->dropDownTerrain->Text = "on";
         else
            this->dropDownTerrain->Text = "off";
      }
   }

   this->timerLocation->Enabled = true;
}