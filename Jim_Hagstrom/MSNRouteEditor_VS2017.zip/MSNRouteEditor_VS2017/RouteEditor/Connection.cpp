#include "Connection.h"
#include "Packet.h"
#include "Opcodes.h"

using Ig::Connection;
using Ig::CriticalSection;

using namespace Ig;

CriticalSection::CriticalSection()
{
   // Setup the critical section.
   InitializeCriticalSection(&m_criticalSection);
}

CriticalSection::~CriticalSection()
{
   // Get rid of the critical section.
   DeleteCriticalSection(&m_criticalSection);
}

void CriticalSection::lock()
{
   EnterCriticalSection(&m_criticalSection);
}

void CriticalSection::unlock()
{
   LeaveCriticalSection(&m_criticalSection);
}

Connection::Connection()
{
	// Initialize Winsock
	WSAData	winsock_data;	// filled in by WSAStartup()	
	WSAStartup(MAKEWORD(1,1), &winsock_data);

   m_restarted = true;
   // Set the timeout to 5 seconds.
   m_timeOut = 5000;
   m_finishedLoading = false;

   // Initialize handles.
   m_sendThread = 0;
   m_receiveThread = 0;

   m_motionSystemStart = 2500;
   m_motionSystemEnd = 5000;

   // Set the connection state.
   setState(Ig::Connection::offline);
}

Connection::~Connection()
{
   // Wait for the thread to exit.
   exitThreads();

   // Clear any pending opcodes.
   clearPendingOpcodes();
}

bool Connection::open(const char* ip, const int port, const int timeOut)
{
   // Make sure the threads are not already running.
   exitThreads();

   // Setup the ports
   m_sendPort = port;
   m_receivePort = port-1;
   m_timeOut = timeOut;
   if (m_timeOut < 1000) m_timeOut = 1000;

   // Setup the sockets.
   m_sendSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
   m_receiveSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

   // Set the receive socket timeout.
   int timeout = 100;
   setsockopt(m_receiveSocket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout)); 

   // Set up the send address.
   memset(&m_sendAddress, 0, sizeof(m_sendAddress));
   m_sendAddress.sin_family = AF_INET;
   m_sendAddress.sin_addr.s_addr = inet_addr(ip);
   m_sendAddress.sin_port = htons(m_sendPort);

   // Setup the receive address
	memset(&m_receiveAddress, 0, sizeof(m_receiveAddress));
	m_receiveAddress.sin_family = AF_INET;
	m_receiveAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	m_receiveAddress.sin_port = htons(m_receivePort);

   // Change the state to connecting
   m_state = Connection::connecting;
   m_finishedLoading = false;

   // Connect to the sender address.
   if (::connect(m_sendSocket, (sockaddr *)&m_sendAddress, sizeof(m_sendAddress)) == SOCKET_ERROR)
   {
      int error = WSAGetLastError();
      closesocket(m_sendSocket);
      return false;
   }   

   // Bind to the receiver address.
   if (::bind(m_receiveSocket, (sockaddr *)&m_receiveAddress, sizeof(m_receiveAddress)) == SOCKET_ERROR)
   {
      int error = WSAGetLastError();
      closesocket(m_sendSocket);
      closesocket(m_receiveSocket);
      return false;
   }

   // Clear everyting.
   m_motionSystems.clear();
   m_models.clear();

   // Clear all changes.
   clearModelChanges();
   clearMotionSystemChanges();
   clearMotionSystemRequests();

   // Clear pending opcodes.
   clearPendingOpcodes();

   // Start the threads
   m_sendThread = (HANDLE)_beginthreadex(NULL, 0, sendData, this, 0, &this->m_sendThreadId);
   m_receiveThread = (HANDLE)_beginthreadex(NULL, 0, receiveData, this, 0, &this->m_receiveThreadId);

   return true;
}

void Connection::close(bool immediate)
{
   if (immediate)
   {
      setState(Connection::offline);
      clearPendingOpcodes();
   }
   else
   {
      setState(Connection::unloading);
   }
}

void Connection::loadModel(int slot, const char* filename)
{
   m_csModels.lock();
   // Put the model into the map.
   m_models[slot] = filename;
   m_csModels.unlock();

   // Post a change notices so opcodes are sent.
   postModelChange(slot, true);
}

void Connection::unloadModel(int slot)
{
   m_csModels.lock();

   // Make sure the model exists.
   std::map<int, std::string>::iterator iter;
   iter = m_models.find(slot);
   if (iter != m_models.end())
   {
      // Post a change notice so opcodes are sent.
      postModelChange(slot, false);
   }
   
   m_csModels.unlock();
}

void Connection::bindModel(int motionSystem, int slot)
{
   // Put the motion system into the map.
   m_csMotionSystems.lock();
   m_motionSystems[motionSystem].model = slot;
   m_motionSystems[motionSystem].bound = true;
   m_csMotionSystems.unlock();

   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, true, true, true, true);
}

void Connection::unbindModel(int motionSystem)
{
   // Make sure the motion system exists.
   m_csMotionSystems.lock();
   std::map<int, MotionSystem>::iterator iter;
   iter = m_motionSystems.find(motionSystem);
   if (iter != m_motionSystems.end())
   {
      iter->second.bound = false;
      iter->second.terrainFollowing = false;
   }
   m_csMotionSystems.unlock();

   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, true, true, true, true);
}

void Connection::unbindAllModels()
{
   m_csMotionSystems.lock();
   std::map<int, MotionSystem>::iterator iter;
   for (iter = m_motionSystems.begin(); iter != m_motionSystems.end(); iter++)
   {
      iter->second.bound = false;
      iter->second.terrainFollowing = false;
      // Post a change notice so the opcodes are sent.
      postMotionSystemChange(iter->first, true, true, true, true);
   }
   m_csMotionSystems.unlock();
}


void Connection::setModelParent(int motionSystem, int parentMotionSystem)
{
   // Put the motion system into the map.
   m_csMotionSystems.lock();
   m_motionSystems[motionSystem].parentMotionSystem = parentMotionSystem;
   m_csMotionSystems.unlock();
   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, false, true, false, false, true);
}

void Connection::setModelPosition(int motionSystem, const Connection::Position& position)
{
   // Put the motion system into the map.
   m_csMotionSystems.lock();
   m_motionSystems[motionSystem].position = position;
   m_csMotionSystems.unlock();

   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, false, true, false, false);
}

Connection::Position Connection::getModelPosition(int motionSystem)
{
   Connection::Position temp;

   m_csMotionSystems.lock();

   // Make sure the model exists.
   std::map<int, MotionSystem>::iterator iter;
   iter = m_motionSystems.find(motionSystem);
   if (iter != m_motionSystems.end())
   {
      temp = iter->second.position;
   }
   
   m_csMotionSystems.unlock();

   return temp;
}


void Connection::setModelVelocity(int motionSystem, const Connection::Velocity& velocity)
{
   // Put the motion system into the map.
   m_csMotionSystems.lock();
   m_motionSystems[motionSystem].velocity = velocity;
   m_csMotionSystems.unlock();

   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, false, false, true, false);
}

void Connection::setModelSelect(int motionSystem, int modelSelect)
{
   // Put the motion system into the map.
   m_csMotionSystems.lock();
   m_motionSystems[motionSystem].select = modelSelect;
   m_csMotionSystems.unlock();

   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, false, true, false, false);
}

void Connection::setModelTerrainFollowing(int motionSystem, bool enable)
{
   // Put the motion system into the map.
   m_csMotionSystems.lock();
   m_motionSystems[motionSystem].terrainFollowing = enable;
   m_csMotionSystems.unlock();

   // Post a change notice so the opcodes are sent.
   postMotionSystemChange(motionSystem, false, false, false, true);
}

bool Connection::getModelTerrainFollowing(int motionSystem)
{
   bool temp;

   m_csMotionSystems.lock();

   // Make sure the model exists.
   std::map<int, MotionSystem>::iterator iter;
   iter = m_motionSystems.find(motionSystem);
   if (iter != m_motionSystems.end())
   {
      temp = iter->second.terrainFollowing;
   }
   
   m_csMotionSystems.unlock();

   return temp; 
}


void Connection::sendCliCommand(const char command[80])
{
   pushOpcode(new Ig::Opcodes::Ascii(command));   
}

void Connection::requestModelPosition(int motionSystem)
{
   // Post a request to send out opcodes.
   postMotionSystemRequest(motionSystem);
}

int Connection::getNextAvailableMotionSystem()
{
   int temp = 0;
   std::map<int, MotionSystem>::iterator iter;

   // Find the next available motion system number.
   m_csMotionSystems.lock();
   
   for (int i=m_motionSystemStart; i<m_motionSystemEnd; i++)
   {
      iter = m_motionSystems.find(i);
      // If the motion system was not found, then use it.
      if (iter == m_motionSystems.end())
      {
         temp = i;
         break;
      }
      // Otherwise check to see if it is bound.
      else
      {
         // If not, use it.
         if (!iter->second.bound)
         {
            temp = i;
            break;
         }
      }
   }

   m_csMotionSystems.unlock();

   return temp;
}

Connection::ConnectionState Connection::getState()
{ 
   ConnectionState temp;

   m_csState.lock();
   temp = m_state;
   m_csState.unlock();

   return temp; 
}

void Connection::setState(ConnectionState state)
{
   // Make sure we aren't already in the state.
   if (state == m_state) return;

   m_csState.lock();
   m_state = state;
   m_csState.unlock();
}

int Connection::getTimeOut()
{
   int temp;

   m_csTimeOut.lock();
   temp = m_timeOut;
   m_csTimeOut.unlock();
   
   return temp; 
}

bool Connection::getFinishedLoading()
{
   bool temp;

   m_csFinishedLoading.lock();
   temp = m_finishedLoading;
   m_csFinishedLoading.unlock();
   
   return temp; 
}

void Connection::setFinishedLoading(bool finished)
{
   m_csFinishedLoading.lock();
   m_finishedLoading = finished;
   m_csFinishedLoading.unlock();
}

bool Connection::getRestarted()
{
   bool temp;

   m_csRestarted.lock();
   temp = m_restarted;
   m_csRestarted.unlock();

   return temp;
}

void Connection::setRestarted(bool restarted)
{
   m_csRestarted.lock();
   m_restarted = restarted;
   m_csRestarted.unlock();
}

void Connection::pushOpcode(Ig::Opcodes::Opcode* opcode)
{
   m_csOpcodes.lock();
   m_opcodes.push_back(opcode);
   m_csOpcodes.unlock();
}

void Connection::postModelChange(int number, bool load)
{
   m_csModelChanges.lock();
   m_modelChanges[number] = load;
   m_csModelChanges.unlock();
}

void Connection::postMotionSystemChange(int number, bool bind, 
   bool position, bool velocity, bool terrainFollowing, bool parent)
{
   m_csMotionSystemChanges.lock();
   if (bind) m_motionSystemChanges[number].bind = true;
   if (position) m_motionSystemChanges[number].position = true;
   if (velocity) m_motionSystemChanges[number].velocity = true;
   if (terrainFollowing) m_motionSystemChanges[number].terrainFollowing = true;
   if (parent) m_motionSystemChanges[number].parent = true;
   m_csMotionSystemChanges.unlock();
}

void Connection::postMotionSystemRequest(int number)
{
   m_csMotionSystemRequests.lock();
   m_motionSystemRequests.insert(number);
   m_csMotionSystemRequests.unlock();
}

uintptr_t Connection::sendData(void* param)
{
   bool request_thread_exit = false;
   ConnectionState state = Connection::connecting;

   // The param should be an instance of the connection class.
   if (param == 0) return 0;

   // Cast it to a connection
   Connection* connection = static_cast<Connection*>(param);

   // Set the state to connecting.
   connection->setState(Connection::connecting);

   // Loop until we are told to exit.
   while (state != Connection::offline)
   {
      // Get the current state (thread safe).
      state = connection->getState();

      // Send data based on the state of the connection.
      switch (state)
      {
      // The connection is offline.
      case offline: break;
      // Connecting to the Ig.
      case connecting:     connection->processConnectingState();    break;
      // Loading everything.
      case loading:        connection->processLoadingState();       break;
      // Waiting for the Ig to set load flags.
      case waiting:        connection->processWaitingState();       break;
      // Running.
      case running:        connection->processRunningState();       break;
      // Unloading.
      case unloading:      connection->processUnloadingState();     break;
      // Disconnecting.
      case disconnecting:  connection->processDisconnectingState(); break;
      }

      // Take a break...
      Sleep(15);
   }

   // Close the socket.
   closesocket(connection->m_sendSocket);

   return 0;
}

uintptr_t Connection::receiveData(void* param)
{
   bool request_thread_exit = false;
   ConnectionState state = Connection::connecting;

   // The param should be an instance of the connection class.
   if (param == 0) return 0;

   // Cast it to a connection
   Connection* connection = static_cast<Connection*>(param);

   DWORD lastResponseTime = GetTickCount();
   DWORD elapsedTime = 0;
   const int max_buffer_size = 66000;
   char buffer[max_buffer_size];
   DWORD maxTime = (DWORD)connection->getTimeOut();

   while (state != Connection::offline)
   {
      // Get the current state (thread safe).
      state = connection->getState();

      // Attempt to receive data.
      int bytes_received = recv(connection->m_receiveSocket, buffer, max_buffer_size, 0);
      if (bytes_received != SOCKET_ERROR)
      {
         // Update the response time.
         lastResponseTime = GetTickCount();
         // Process the Response.
         connection->processResponse(buffer, bytes_received);

         //If the state is connecting, then transition to the loading state.
         if (state == Connection::connecting)
            connection->setState(Connection::loading);

      }
      else
      {
         // Check how long it has been since we have received a response.
         // If it has been to long, then transition to the offline state.
         elapsedTime = GetTickCount() - lastResponseTime;

         // Make sure the timer didn't roll over.
         if (elapsedTime < 0) 
         {
            elapsedTime = 0;
            lastResponseTime = GetTickCount();
         }

         if (elapsedTime > maxTime && (state > Connection::connecting && state <= Connection::disconnecting))
         {
            // Set the state to offline (thread safe).
            connection->setState(Connection::offline);
         }
      }
   }

   // Close the socket.
   closesocket(connection->m_receiveSocket);

   return 0;
}

void Connection::exitThreads()
{
   // Disconnect first.
   close();

   // If the thread is running, we need to shut it down.
   if (m_sendThread != 0)
   {

      // Wait for the thread to exit.
      // Catch the thread's exit value.
      DWORD dwExitCode;
      GetExitCodeThread(m_sendThread, &dwExitCode);

      // If the thread is still active then wait for it.
      if (dwExitCode == STILL_ACTIVE)
      {   
         WaitForSingleObject(m_sendThread, INFINITE);
         GetExitCodeThread(m_sendThread, &dwExitCode);        
      }

      if (m_sendThread)
      {
         CloseHandle(m_sendThread);
         m_sendThread = 0;
      }
   }

   // If the thread is running, we need to shut it down.
   if (m_receiveThread != 0)
   {
      // Wait for the thread to exit.
      // Catch the thread's exit value.
      DWORD dwExitCode;
      GetExitCodeThread(m_receiveThread, &dwExitCode);

      // If the thread is still active then wait for it.
      if (dwExitCode == STILL_ACTIVE)
      {   
         WaitForSingleObject(m_receiveThread, INFINITE);
         GetExitCodeThread(m_receiveThread, &dwExitCode);        
      }

      if (m_receiveThread)
      {
         CloseHandle(m_receiveThread);
         m_receiveThread = 0;
      }
   }
}

void Connection::clearPendingOpcodes()
{
   m_csOpcodes.lock();
   // Iterate through the pending opcodes and delete them.
   if (!m_opcodes.empty())
   {
      // Put as many opcodes into the packet as possible.
      while(!m_opcodes.empty())
      {
         // Delete the opcode.
         delete m_opcodes.front();
         // Pop it.
         m_opcodes.pop_front();
      }
   }
   m_csOpcodes.unlock();
}

void Connection::sendPendingOpcodes()
{
   // Create a packet to send out data.
   Ig::Packet packet(1, Ig::Packet::sc_normalHostData);
   
   m_csOpcodes.lock();

   // If the Ig has restarted, then acknowledge it.
   if (getRestarted())
   {
      packet.setStatus(Packet::sc_restartAckHostData);
      setRestarted(false);
   }
   
   // Iterate through the pending opcodes and put them into packets.
   if (!m_opcodes.empty())
   {
      // Put as many opcodes into the packet as possible.
      while(!m_opcodes.empty() && packet.pushOpcode(*m_opcodes.front()))
      {
         // If the opcode is an end of data opcode, then we need to
         // ship it.
         if (m_opcodes.front()->getOpcodeNumber() == Ig::Opcodes::EndOfData::opcodeNumber)
         {
            // Delete the opcode.
            delete m_opcodes.front();
            // Pop it.
            m_opcodes.pop_front();
            // Exit the loop.
            break;
         }
         else
         {
            // Delete the opcode.
            delete m_opcodes.front();
            // Pop it.
            m_opcodes.pop_front();
         }
      }
   }

   m_csOpcodes.unlock();

   // Put the packet in network order.
   packet.serialize();
   // Send it out.
   ::send(m_sendSocket, packet.getBuffer(), packet.getBufferSize(), 0);
}

bool Connection::hasPendingOpcodes()
{
   bool temp;
   m_csOpcodes.lock();
   temp = !m_opcodes.empty();
   m_csOpcodes.unlock();
   return temp;
}

void Connection::pushLoadStatusRequest()
{
   // Get the position of the eyepoint.
   Position position = getModelPosition(0);

   // Create a new load status request.
   Ig::Opcodes::LoadStatusRequest* request = new Ig::Opcodes::LoadStatusRequest();
   request->setWaitOnCT(true);
   request->setWaitOnModels(true);
   request->setWaitOnTerrain(true);
   request->setLatitudinalCenter(position.latitude);
   request->setLongitudinalCenter(position.longitude);
   request->setAltitudinalCenter(position.altitude);
   request->setRadius(30000);
   // Add the request to the queue.
   pushOpcode(request);
}

void Connection::clearModelChanges()
{
   m_csModelChanges.lock();
   m_modelChanges.clear();
   m_csModelChanges.unlock();
}

void Connection::clearMotionSystemChanges()
{
   m_csMotionSystemChanges.lock();
   m_motionSystemChanges.clear();
   m_csMotionSystemChanges.unlock();
}

void Connection::clearMotionSystemRequests()
{
   m_csMotionSystemRequests.lock();
   m_motionSystemRequests.clear();
   m_csMotionSystemRequests.unlock();
}

void Connection::processModelChanges()
{
   char buffer[80];

   // Iterate through the model changes and process them.
   m_csModelChanges.lock();
   std::map<int, bool>::iterator iter;
   for (iter = m_modelChanges.begin(); iter != m_modelChanges.end(); iter++)
   {
      // Find the model.
      m_csModels.lock();
      std::map<int, std::string>::iterator modelIter;
      modelIter = m_models.find(iter->first);

      // Loading.
      if (iter->second == true)
      {
         if (modelIter != m_models.end())
         {
            sprintf_s(buffer, 80, "load %s slot=%d", modelIter->second.c_str(), modelIter->first);
            pushOpcode(new Ig::Opcodes::Ascii(buffer));
         }
      }
      // Unloading.
      else
      {
         sprintf_s(buffer, 80, "unload slot=%d", iter->first);      
         pushOpcode(new Ig::Opcodes::Ascii(buffer));

         // Remove it.
         if (modelIter != m_models.end())
            m_models.erase(modelIter);
      }

      m_csModels.unlock();
   }

   // Clear the list.
   m_modelChanges.clear();
   m_csModelChanges.unlock();
}

void Connection::processMotionSystemChanges()
{
   //char buffer[80];

   // Iterate through the motion system changes and send out opcodes.
   m_csMotionSystemChanges.lock();

   // Setup a temporary map of changes that will need to be handled in the next frame.
   std::map<int, MotionSystemChange> nextFrameChanges;

   std::map<int, MotionSystemChange>::iterator iter;
   for (iter = m_motionSystemChanges.begin(); iter != m_motionSystemChanges.end(); iter++)
   {
      // Check to see if the motion system still exists (it should).
      m_csMotionSystems.lock();
      std::map<int, MotionSystem>::iterator motionSystemIter;
      motionSystemIter = m_motionSystems.find(iter->first);
      if (motionSystemIter != m_motionSystems.end())
      {
         // Process the changes in the motion system.

         // Process Bind
         if (iter->second.bind)
         {
            if (motionSystemIter->second.bound)
            {
               //sprintf_s(buffer, 80, "!bind model=%d ms=%d", motionSystemIter->second.model, motionSystemIter->first);
               //pushOpcode(new Ig::Opcodes::Ascii(buffer));

               Ig::Opcodes::MovingModelDefinition* request = new Ig::Opcodes::MovingModelDefinition();
               request->setMotionSystemNumber(iter->first);
               request->setModelSlotNumber(motionSystemIter->second.model);
               request->setParentMovingModel(motionSystemIter->second.parentMotionSystem);
               request->setLocalLightMask(0xFFFF);
               request->setLocalPolygonMask(0xFFFF);
               request->setUseUpper16LocalLightGroups(false);
               request->setUseUpper16LocalPolygonGroups(false);
               request->setProcessBind(true);
               request->setBind(true);
               pushOpcode(request);

               request = new Ig::Opcodes::MovingModelDefinition();
               request->setMotionSystemNumber(iter->first);
               request->setModelSlotNumber(motionSystemIter->second.model);
               request->setParentMovingModel(motionSystemIter->second.parentMotionSystem);
               request->setLocalLightMask(0xFFFF);
               request->setLocalPolygonMask(0xFFFF);
               request->setUseUpper16LocalLightGroups(true);
               request->setUseUpper16LocalPolygonGroups(true);
               request->setProcessBind(false);
               pushOpcode(request);

               // Since this also takes care of the parent model, we
               // can clear that flag so it isn't done twice.
               iter->second.parent = false;

               iter->second.terrainFollowing = true;
            }
         }

         // Process Parent
         if (iter->second.parent)
         {
            
            //if (motionSystemIter->second.parentMotionSystem != 1)
            //{
            //   sprintf_s(buffer, 80, "!chain child=%d parent=%d x=%.2f y=%.2f z=%2.f", motionSystemIter->first, 
            //      motionSystemIter->second.parentMotionSystem,
            //      motionSystemIter->second.position.latitude,
            //      motionSystemIter->second.position.longitude,
            //      motionSystemIter->second.position.altitude);
            //   pushOpcode(new Ig::Opcodes::Ascii(buffer));

            //}
            //else
            //{
            //   sprintf_s(buffer, 80, "!unchain %d", motionSystemIter->first);
            //   pushOpcode(new Ig::Opcodes::Ascii(buffer));
            //}

            // Send a definition request which will chain/unchain the motion system.
            Ig::Opcodes::MovingModelDefinition* request = new Ig::Opcodes::MovingModelDefinition();
            request->setMotionSystemNumber(iter->first);
            request->setModelSlotNumber(motionSystemIter->second.model);
            request->setParentMovingModel(motionSystemIter->second.parentMotionSystem);
            pushOpcode(request);
         }

         // Process Terrain Following
         if (iter->second.terrainFollowing)
         {

            // On
            if (motionSystemIter->second.terrainFollowing)
            {
               //pushOpcode(new Ig::Opcodes::Ascii("!pos ... up in the air"));
               //sprintf_s(buffer, 80, "!bind \\terrain mm=%d enable=on", motionSystemIter->first);
               
               // Send a position opcode to put it way up in the air so that when terrain following
               // is turned on, it clamps properly.
               Ig::Opcodes::MovingModelAndEyepointControl* positionRequest = new Ig::Opcodes::MovingModelAndEyepointControl();
               positionRequest->setMovingModelNumber(iter->first);
               Ig::Connection::Position position = motionSystemIter->second.position;
               positionRequest->setPosition(position.latitude, position.longitude, 30000);
               positionRequest->setOrientation(position.heading, position.pitch, position.roll);
               pushOpcode(positionRequest);

               // Send a terrain following opcode to turn it on.
               Ig::Opcodes::TerrainFollowingModels* request = new Ig::Opcodes::TerrainFollowingModels();
               request->setMovingModelNumber(iter->first);
               request->setConform(true);
               pushOpcode(request);
            }
            // Off
            else
            {
               //sprintf_s(buffer, 80, "!bind \\terrain mm=%d enable=off", motionSystemIter->first);

               // Send two terrain following opcodes to turn it off.
               Ig::Opcodes::TerrainFollowingModels* request = new Ig::Opcodes::TerrainFollowingModels();
               request->setMovingModelNumber(iter->first);
               pushOpcode(request);
               request = new Ig::Opcodes::TerrainFollowingModels();
               request->setMovingModelNumber(-1);
               pushOpcode(request);

               // Since we turned it off, we need to update the position, but it will be done
               // in the next frame because the IG needs a frame to process it.
               nextFrameChanges[iter->first].position = true;

            }
            //pushOpcode(new Ig::Opcodes::Ascii(buffer));

            // Because we just processed terrain following,
            // we need to also send out a position so set the flag to do so.
            iter->second.position = true;
         }

         // Process Position
         if (iter->second.position)
         {
            // If terrain following is turned on, don't set alt.
            //if (motionSystemIter->second.terrainFollowing)
            //{
            //   sprintf_s(buffer, 80, "!pos mm=%d lat=%.4f lon=%.4f sel=%d", 
            //      motionSystemIter->first, 
            //      motionSystemIter->second.position.latitude,
            //      motionSystemIter->second.position.longitude,
            //      motionSystemIter->second.select);
            //}
            //else
            //{
            //   sprintf_s(buffer, 80, "!pos mm=%d lat=%.4f lon=%.4f alt=%.4f sel=%d", 
            //      motionSystemIter->first,
            //      motionSystemIter->second.position.latitude,
            //      motionSystemIter->second.position.longitude,
            //      motionSystemIter->second.position.altitude,
            //      motionSystemIter->second.select);
            //}

            //pushOpcode(new Ig::Opcodes::Ascii(buffer));

            Ig::Opcodes::MovingModelAndEyepointControl* request = new Ig::Opcodes::MovingModelAndEyepointControl();
            request->setMovingModelNumber(iter->first);

            // If not chained then send a normal position.
            Ig::Connection::Position position = motionSystemIter->second.position;
            if (motionSystemIter->second.parentMotionSystem == 1)
            {
               // If terrain following is on, do not send altitude.
               if (motionSystemIter->second.terrainFollowing)
               {
                  request->setLatitude(position.latitude);
                  request->setLongitude(position.longitude);
               }
               else
               {
                  request->setPosition(position.latitude, position.longitude, position.altitude);
               }
            }
            // Otherwise send an offset.
            else
            {
               request->setXOffset(position.latitude);
               request->setYOffset(position.longitude);
               request->setZOffset(position.altitude);
            }

            // If terrain following is on, do not send pitch and roll.
            if (motionSystemIter->second.terrainFollowing)
               request->setHeading(position.heading);
            else
               request->setOrientation(position.heading, position.pitch, position.roll);

            request->setModelSelect(motionSystemIter->second.select);
            request->setExtrapolationDisabled(true);
            pushOpcode(request);
         }

         // Velocity
         if (iter->second.velocity)
         {
            //sprintf_s(buffer, 80, "!vel mm=%d ...", motionSystemIter->first);
            //pushOpcode(new Ig::Opcodes::Ascii(buffer));

            Ig::Opcodes::MovingModelVelocity* request = new Ig::Opcodes::MovingModelVelocity();
            request->setMovingModelNumber(iter->first);
            Ig::Connection::Velocity velocity = motionSystemIter->second.velocity;
            request->setVelocity(velocity.x, velocity.y, velocity.z, 
               velocity.heading, velocity.pitch, velocity.roll);
            pushOpcode(request);
         }

         // Process Unbind
         if (iter->second.bind)
         {
            if (!motionSystemIter->second.bound)
            {
               //sprintf_s(buffer, 80, "!unbind ms=%d clean", motionSystemIter->first);
               //pushOpcode(new Ig::Opcodes::Ascii(buffer));

               // Send two terrain following opcodes to turn it off.
               Ig::Opcodes::TerrainFollowingModels* requestTerrainFollowing = new Ig::Opcodes::TerrainFollowingModels();
               requestTerrainFollowing->setMovingModelNumber(iter->first);
               pushOpcode(requestTerrainFollowing);
               requestTerrainFollowing = new Ig::Opcodes::TerrainFollowingModels();
               requestTerrainFollowing->setMovingModelNumber(-1);
               pushOpcode(requestTerrainFollowing);

               Ig::Opcodes::MovingModelDefinition* request = new Ig::Opcodes::MovingModelDefinition();
               request->setMotionSystemNumber(iter->first);
               request->setBind(false);
               request->setParentMovingModel(1);
               request->setProcessBind(true);
               request->setModelCleanupClean(true);
               pushOpcode(request);

               // Get rid of it.
               m_motionSystems.erase(motionSystemIter);
            }
         }
      }
      m_csMotionSystems.unlock();
   }

   // Clear the list.
   m_motionSystemChanges.clear();

   // Copy over the changes for the next frame.
   m_motionSystemChanges = nextFrameChanges;
   m_csMotionSystemChanges.unlock();
}

void Connection::processMotionSystemRequests()
{
   // Iterate through the motion system requests and send out opcodes.
   m_csMotionSystemRequests.lock();
   std::set<int>::iterator iter;
   for (iter = m_motionSystemRequests.begin(); iter != m_motionSystemRequests.end(); iter++)
   {
      Ig::Opcodes::MovingModelRequest* request = new Ig::Opcodes::MovingModelRequest();
      request->setMovingModelNumber(*iter);
      request->setReturnWorldPosition(true);
      pushOpcode(request);
   }
   // Clear the list.
   m_motionSystemRequests.clear();
   m_csMotionSystemRequests.unlock();
}

//===========================================================
// Methods to process the different states of the connection.
//===========================================================

void Connection::processConnectingState()
{
   // Call send pending opcodes which will send an empty packet.
   sendPendingOpcodes();
   // Set the finished loading flag to false.
   setFinishedLoading(false);
}

void Connection::processLoadingState()
{

   // If the Ig has not finished loading, send
   // another load status request and wait till then.
   if (!getFinishedLoading())
   {
      pushLoadStatusRequest();
      // Send pending opcodes.
      sendPendingOpcodes();
   }
   // When finished loading, process the changes.
   else
   {
      // Process changes.
      processModelChanges();
      processMotionSystemChanges();
      processMotionSystemRequests();

      // When all opcodes have been sent, 
      // transition to the next state.
      if (!hasPendingOpcodes())
      {
         // Reset the load status flags.
         setFinishedLoading(false);
         // Transition to the waiting state.
         setState(Connection::waiting);
      }
      // Otherwise keep sending opcodes.
      else
      {
         sendPendingOpcodes();
      }
   }
}

void Connection::processWaitingState()
{
   // If the Ig has not finished loading, then wait...
   if (!getFinishedLoading())
   {
      pushLoadStatusRequest();
      sendPendingOpcodes();
   }
   // If we have finished loading, reset the load
   // status flags and transition to the next state.
   else
   {
      // Reset the load status flags.
      setFinishedLoading(false);
      // Transition to the running state.
      setState(Connection::running);
   }
}

void Connection::processRunningState()
{
   // Process changes.
   processModelChanges();
   processMotionSystemChanges();
   processMotionSystemRequests();

   // Send pending opcodes.
   sendPendingOpcodes();
}

void Connection::processUnloadingState()
{
   std::map<int, std::string>::iterator modelIter;
   std::map<int, MotionSystem>::iterator motionSystemIter;

   // Unbind all of the motion systems.
   m_csMotionSystems.lock();
   for(motionSystemIter = m_motionSystems.begin(); 
      motionSystemIter != m_motionSystems.end(); motionSystemIter++)
   {
      // TODO: Temporary, remove this...
      char buffer[80];
      sprintf_s(buffer, 80, "!unbind mm=%d clean", motionSystemIter->first);
      pushOpcode(new Ig::Opcodes::Ascii(buffer));

      // Send two terrain following opcodes to turn it off.
      Ig::Opcodes::TerrainFollowingModels* requestTerrainFollowing = new Ig::Opcodes::TerrainFollowingModels();
      requestTerrainFollowing->setMovingModelNumber(motionSystemIter->first);
      pushOpcode(requestTerrainFollowing);
      requestTerrainFollowing = new Ig::Opcodes::TerrainFollowingModels();
      requestTerrainFollowing->setMovingModelNumber(-1);
      pushOpcode(requestTerrainFollowing);

      Ig::Opcodes::MovingModelDefinition* request = 
         new Ig::Opcodes::MovingModelDefinition();
      request->setMotionSystemNumber(motionSystemIter->first);
      request->setBind(false);
      request->setParentMovingModel(1);
      request->setProcessBind(true);
      request->setModelCleanupClean(true);
      pushOpcode(request);
   
   }
   
   // Clear the motion systems.
   m_motionSystems.clear();

   m_csMotionSystems.unlock();

   // Unload all of the models.
   m_csModels.lock();
   for (modelIter = m_models.begin(); modelIter != m_models.end(); modelIter++)
   {
      char buffer[80];
      sprintf_s(buffer, 80, "unload slot=%d", modelIter->first);
      pushOpcode(new Ig::Opcodes::Ascii(buffer));
   }

   // Clear all of the models.
   m_models.clear();

   m_csModels.unlock();

   // Transition to the disconnecting state (thread safe).
   setState(Connection::disconnecting);
}

void Connection::processDisconnectingState()
{
   // Clear all requests.
   clearModelChanges();
   clearMotionSystemChanges();
   clearMotionSystemRequests();

   // Send pending opcodes.
   sendPendingOpcodes();

   int opcodesLeft;
   m_csOpcodes.lock();
   opcodesLeft = m_opcodes.size();
   m_csOpcodes.unlock();

   // When no opcodes remain, transition to the offline state (thread safe).
   if (!hasPendingOpcodes())
      setState(Connection::offline);
}

void Connection::processResponse(char* buffer, int size)
{
   unsigned short opcodeNumber;
   unsigned short subOpcodeA;
   unsigned short subOpcodeB;

   // Make sure it is a valid packet.
   // If in the connecting state, then switch to the loading state.
   // If in the waiting state and the load flags are set then switch to the running state.
   
   Ig::Packet packet(buffer, size);

   // Check the status of the packet.
   if (packet.getStatus() > 0x2)
   {
      setRestarted(true);
      // If we were in a state other than connecting, disconnect.
      if (getState() > Connection::connecting)
      {
         setState(Connection::offline);
      }
   }

   // Loop through the opcodes in the packet and handle them.
   while (packet.peekOpcode(opcodeNumber, subOpcodeA, subOpcodeB))
   {
      switch (opcodeNumber)
      {
      // Extended Opcodes
      case Ig::Opcodes::ExtendedOpcode::opcodeNumber:
         {
            // Load Status Response
            if (subOpcodeA == Ig::Opcodes::LoadStatusResponse::subOpcodeA &&
               subOpcodeB == Ig::Opcodes::LoadStatusResponse::subOpcodeB)
            {
               Ig::Opcodes::LoadStatusResponse response;
               packet.popOpcode(response);

               // Update the load status.
               if (response.getCtLoaded() && response.getTerrainLoaded())
                  setFinishedLoading(true);
               else
                  setFinishedLoading(false);
            }

            // Moving Model Response
            else if (subOpcodeA == Ig::Opcodes::MovingModelResponse::subOpcodeA &&
               subOpcodeB == Ig::Opcodes::MovingModelResponse::subOpcodeB)
            {
               Ig::Opcodes::MovingModelResponse response;
               packet.popOpcode(response);

               Position position;
               position.latitude = response.getLatitude();
               position.longitude = response.getLongitude();
               position.altitude = response.getAltitude();
               position.heading = response.getHeading();
               position.pitch = response.getPitch();
               position.roll = response.getRoll();

               // Check to see if there is a pending change for the motion system.
               m_csMotionSystemChanges.lock();
               std::map<int, MotionSystemChange>::iterator iter;
               iter = m_motionSystemChanges.find(response.getMovingModelNumber());
               bool pendingChanges = false;
               if (iter != m_motionSystemChanges.end())
               {
                  if (iter->second.position)
                     pendingChanges = true;
               }
               m_csMotionSystemChanges.unlock();

               // If there are no pending position changes, then update it.
               if (!pendingChanges)
               {
                  m_csMotionSystems.lock();
                  m_motionSystems[response.getMovingModelNumber()].position = position;
                  m_csMotionSystems.unlock();
               }
            }
         }
         break;

      // All other opcodes.
      default:
         // Just pop it.
         packet.popOpcode();

      }
   }
}