#pragma once

namespace Ig
{
   namespace Opcodes
   {
      /** Virtual base class for all opcodes. */
      class Opcode
      {
      public:
         
         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer() = 0;
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize() = 0;
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer) = 0;

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber() = 0;

         /** Convert a double to a 36 bit angle.
         * @return The new angle.
         * @param angle The angle to convert.
         */
         static const __int64 doubleTo36BitAngle(const double angle);
   
         /** Convert a double to a 32 bit scaled distance.
         * @return The scaled distance.
         * @param distance The distance to convert.
         */
         static const int doubleTo32BitScaledDistance(const double distance);

         /** Convert a double to a 32 bit angle.
         * @return The new angle.
         * @param angle The angle to convert.
         */
         static const int doubleTo32BitAngle(const double angle);

         /** Convert a double to a 16 bit scalar A value.
         * @return The scalar value.
         * @param value The value to convert.
         */
         static const short doubleTo16BitScalarA(const double value);

         /** Convert a double to a 32 bit scalar A value.
         * @return The scalar value.
         * @param value The value to convert.
         */
         static const int doubleTo32BitScalarA(const double value);

         /** Convert a double to a 32 bit scalar D value.
         * @return The scalar value.
         * @param value The value to convert.
         */
         static const int doubleTo32BitScalarD(const double value);

         /** Convert a double to a 32 bit scaled angular rate.
         * @return The scaled angular rate.
         * @param rate The rate to convert.
         */
         static const int doubleTo32BitScaledAngularRate(const double rate);

         /** Convert a scaled distance to a 32 bit double.
         * @return The 32 bit double.
         * @param distance The scaled distance to convert.
         */
         static const double scaledDistance32BitToDouble(const int distance);

         /** Take the bits in two 32 bit integers and covert it to a single float 64.
         * @return A 64 bit float.
         * @param highInt The integer holding the high 32 bits.
         * @param lowInt the integer holding the low 32 bits.
         */
         static const double intToFloat64(int highInt, int lowInt);

         /** Convert a 32 bit float to a fraction B16 value.
         * @return The converted value.
         * @param value The float to convert.
         */
         static const unsigned short float32ToFractionB16 (const float value);


         /** Returns the +/-PI equivalent of an angle in radians <0 or >2PI.
         * @param angle Input angle in radians.
         * @return Input angle constrained to +/-Pi. */
         template <class T>
         inline static const T plusMinusPi(const T angle);

         /** Returns the 0-2PI equivalent of an angle in radians <0 or >2PI. 
         * @param angle Input angle in radians.
         * @return Input angle constrained to 0 to 2Pi*/
         template <class T>
         inline static const T zeroTwoPi(const T angle);


         static const double reduceAngleDegrees(const double angleInDegrees);

         static const double sc_epsilon;
         static const double sc_pi;
         static const double sc_halfPi;
         static const double sc_twoPi;
         static const double sc_degreesToRadians;
         static const double sc_radiansToDegrees;

      };


      template <class T>
      inline const T Opcode::zeroTwoPi(const T angle)
      {
         int x = static_cast<int>(angle/sc_twoPi);

         T new_angle = angle - x * sc_twoPi;

         if (new_angle < 0.0)
            new_angle += sc_twoPi;

         return new_angle;
      }

      template <class T>
      inline const T Opcode::plusMinusPi(const T angle)
      {
         T new_angle = zeroTwoPi(angle);

         if (new_angle > sc_pi)
            new_angle -= sc_twoPi;

         return new_angle;
      }

      /** Virtual base class for all extended opcodes. */
      class ExtendedOpcode : public Opcode
      {
      public:
         /** The opcode number. */
         static const unsigned int opcodeNumber = 0xE000;

         /** Get the size of the opcode. 
         * @return The size of the opcode.
         */
         virtual unsigned short getSize() = 0;

         /** Get the process Id.
         * @return The process Id.
         */
         virtual unsigned short getProcessId() = 0;
      };


      /** Virutal base class for all extended request opcodes. */
      class ExtendedOpcodeRequest : public ExtendedOpcode
      {
      public:

         /** Get the execution priority.
         * @return The execution priority.
         */
         virtual unsigned short getExecutionPriority() = 0;

         /** Get the Object Id.
         * @return The object Id.
         */
         virtual unsigned short getObjectId() = 0;

         /** Get the Function Id.
         * @return The function Id.
         */
         virtual unsigned short getFunctionId() = 0;
      };
      

      /** Virtual base class for all extended response opcodes. */
      class ExtendedOpcodeResponse : public ExtendedOpcode
      {
         /** Get the response priority.
         * @return The response priority.
         */
         virtual unsigned short getResponsePriority() = 0;

         /** Get the sub opcode B.
         * @return The sub opcode B.
         */
         virtual unsigned short getSubOpcodeB() = 0;

         /** Get the sub opcode A.
         * @return The sub opcdoe A.
         */
         virtual unsigned short getSubOpcodeA() = 0;

         /** Get the user data. 
         * @return The user data.
         */
         virtual unsigned int getUserData() = 0;
      };


      /** End of Data Opcode - 0x3000 */
      class EndOfData : public Opcode
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0x3000;

      public:

         /** Constructor. */
         EndOfData();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

      private:

         /** The buffer of data for the opcode. */
         struct
         {
            /** The opcode number. */
            unsigned short m_opcodeNumber : 16;		// xxxxxxxx xxxxxxxx 00000000 00000000
            /** Reserved. */
            unsigned short m_reserved  : 16;	   // 00000000 00000000 xxxxxxxx xxxxxxxx
         } m_buffer;
      };

      /** Terrain Following Models - 0x303D */
      class TerrainFollowingModels : public Opcode
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0x303D;

      public:
         /** Constructor. */
         TerrainFollowingModels();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         * @param size The size of the buffer.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Set the moving model #.
         * @param movingModelNumber Primary model. Setting this to -1 disables
         * terrain following for the moving model in the previously sent terrain following opcode.
         */
         void setMovingModelNumber(const unsigned short movingModelNumber);

         /** Set the id number
         * @param idNum The id number.
         */
         void setIdNumber(const unsigned char idNum);

         /** Set the conform to terrain flag.
         * @param conformFlag The value of the flag.
         */
         void setConform(const unsigned char conformFlag);

         /** Set the smoothing.
         * @param smoothing The amount of smoothing.
         */
         void setSmoothing(const unsigned char smoothing);

         /** Set the Z.
         * @param z The z value.
         */
         void setZ(const double z);

      private:

         /** The buffer of data for the opcode. */
         struct
         {
            /** The opcode number. */
            unsigned short m_opcodeNumber : 16;
            /** Reserved */
            unsigned short m_reserved  : 8;
            /** Specifies an identifier for use in enabling/disabling terrain following. */
            unsigned short m_idNumber     : 8;

            /** The 1/x multiplier that is applied to the delta between the previous and current field's pitch and roll values. A value of 10 gives a 10% correction of the delta in a field. A value of 4 gives a 25% correction of the delta in a field. */
            unsigned short m_smoothing : 8;

            /** Specifies whether the moving model uses the pitch and roll of the polygon directly beneath the testpoint.
            * When active, the user cannot control pitch and roll of the moving model. */
            unsigned short m_conformFlag : 8;

            /** Specifies the moving model that will be made terrain following.
            * NOTE: Entering �1 disables terrain following for the moving model used in the previous terrain following models opcode. 
            */
            unsigned short m_movingModelNumber : 16;

            /** Specifies the Z offset from the terrain that the model will maintain. */
            unsigned int m_z      :32;

            /** Unused. */
            unsigned int m_unused :32;
         } m_buffer;
      };

      /** Moving Model Definition - 0x3040 */
      class MovingModelDefinition : public Opcode
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0x3040;

      public:
         /** Constructor. */
         MovingModelDefinition();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         * @param size The size of the buffer.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Set the process bind flag.
         * @param value The value of the process bind flag.
         */
         void setProcessBind(const bool value = true);

         /** Set the bind flag. 
         * @param value The value of the bind flag. 
         */
         void setBind(const bool value = true);

         /** Set the enable translational extrapolation flag. 
         * @param value The value of the flag.
         */
         void setEnableTranslationalExtrapolation(const bool value = true);

         /** Set the enable rotational extrapolation flag. 
         * @param value The value of the flag.
         */
         void setEnableRotationalExtrapolation(const bool value = true);

         /** Set the enable secondary submodel rotational extrapolation flag. 
         * @param value The value of the flag.
         */
         void setEnableSecondarySubmodelRotationalExtrpolation(const bool value = true);            

         /** Set the local polygon intensity by step flag. 
         * @param value The value of the flag.
         */
         void setLocalPolygonIntensityByStep(const bool value = true);  

         /** Set the local light intensity by step flag. 
         * @param value The value of the flag.
         */
         void setLocalLightIntensityByStep(const bool value = true);  

         /** Set the process during foreground non critical time flag. 
         * @param value The value of the flag.
         */
         void setProcessDuringForegroundNonCriticalTime(const bool value = true);  

         /** Set the motion system number. 
         * @param motionSystemNumber The motion system number.
         */
         void setMotionSystemNumber(const unsigned short motionSystemNumber);

         /** Set the model slot number.
         * @param modelSlotNumber The model slot number.
         */
         void setModelSlotNumber(const unsigned short modelSlotNumber);

         /** Set the model cleanup clean flag.
         * @param value The value of the flag.
         */
         void setModelCleanupClean(const bool value = true);  

         /** Set the use upper 16 local light groups flag.
         * @param value The value of the flag.
         */
         void setUseUpper16LocalLightGroups(const bool value = true);  

         /** Set the use upper 16 local polygon groups flag.
         * @param value The value of the flag.
         */
         void setUseUpper16LocalPolygonGroups(const bool value = true);  

         /** Set the parent moving model.
         * @param parentMovingModel The parent moving model.
         */
         void setParentMovingModel(const unsigned short parentMovingModel);

         /** Set the local light intensity.
         * @param localLightIntensity The local light intensity.
         */
         void setLocalLightIntensity(const double localLightIntensity);

         /** Set the local light mask.
         * @param localLightMask The local light mask.
         */
         void setLocalLightMask(const unsigned short localLightMask);

         /** Set the local polygon intensity.
         * @param localPolygonIntensity The local polygon intensity.
         */
         void setLocalPolygonIntensity(const double localPolygonIntensity);

         /** set the local polygon mask.
         * @param localPolygonMask The local polygon mask.
         */
         void setLocalPolygonMask(const unsigned short localPolygonMask);

      private:
         struct
         {
            /** This opcode #. */
            unsigned short m_opcodeNumber;

            /** Specifies whether to process bit 17. */
            unsigned short m_processBind				: 1;	

            /** Specifies whether to bind a model and a motion system. */
            unsigned short m_bind				: 1;	
            /** Enables or disables translational extrapolation for a primary model. */
            unsigned short m_enableTranslationalExtrapolation : 1;

            /** Enables or disables rotational extrapolation for a primary model. */
            unsigned short m_enableRotationalExtrapolation : 1;

            /** Enables or disables rotational extrapolation for a secondary submodel. 
            * Bit 18 or bit 19 must be enabled in order for this bit to be enabled. */
            unsigned short m_enableSecondarySubmodelRotationalExtrapolation : 1;

            /** Specifies whether local-polygon intensity is set by the scalar or by the steps in the LOCAL-POLYGON INTENSITY field. */
            unsigned short m_setLocalPolygonIntensityByStep : 1 ;

            /** Specifies whether local-light intensity is set by the scalar or by the steps in the LOCAL-LIGHT INTENSITY field. */
            unsigned short m_setLocalLightIntensityByStep : 1 ;
            /** Unused. */
            unsigned short :3;
            /** If set, instructs the RT moving model layer to process this model during foreground non-critical time. This will result in a one field delay in the update for this model on the GP(s). */
            unsigned short m_processDuringForegroundNonCriticalTime : 1 ;
            /** Unused. */
            unsigned short :5;
            /** Specifies the motion system used for this moving-model definition. */
            unsigned short m_motionSystemNumber;
            /** Specifies the database image bound to the motion system. */
            unsigned short m_modelSlotNumber;
           
            // Start of flags2
            /** Specifies moving model parameters will be cleaned up. Clean resets model selects, position and velocity of the model being unbound. */
            unsigned short m_modelCleanupClean : 1;
            /** Unused. */
            unsigned short :8;
            /** The status of bit 9 determines whether the upper or lower 16 bits of the 32 bit word of LOCAL-LIGHT MASK are used. */
            unsigned short m_useUpper16LocalLightGroups : 1;

            /** The status of bit 10 determines whether the upper or lower 16 bits of the 32-bit word of LOCAL-POLYGON MASK are used. */
            unsigned short m_useUpper16LocalPolygonGroups: 1;
            /** Unused. */
            unsigned short :1;
            // End of flags 2

            /** Unused. */
            unsigned short :4;

            /** Specifies the moving model to which this moving model is 
            * chained. The moving model will be positioned relative to the 
            * parent moving model. regular moving models are valid for a parent 
            * moving model number. 
            */
            unsigned short m_parentMovingModel;

            /** If bit 22 in the flag field = 0, this field specifies the scalar applied to the lights� modeled intensity. If bit 22 in the flag field = 1, this field specifies the light step scalar applied to the lights� modeled intensity. */
            unsigned short m_localLightIntensity;
            /** Specifies the active local-light groups for this moving model. There is one bit for each of the 32 local-light groups.
            The status of FLAGS2 bit 9 determines whether the upper or lower 16 bits of the 32-bit word are used. */
            unsigned short m_localLightMask;

            /** If bit 21 in the flag field = 0, this field specifies the scalar applied to the polygons� modeled intensity. If bit 21 in the flag field = 1, this field specifies the polygon step scalar applied to the polygons� modeled intensity. */
            unsigned short m_localPolygonIntensity;
            /** Specifies the active local-polygon groups for this moving model. There is one bit for each of the 32 local-polygon groups.
            The status of FLAGS2 bit 10 determines whether the upper or lower 16 bits of the 32-bit word are used. */
            unsigned short m_localPolygonMask;
            /** Unused. */
            unsigned int :32;
            /** Unused. */
            unsigned int :32;               
            /** Unused. */
            unsigned int :32;
         } m_buffer;
      };


      /** Moving Mode And Eyepoint Control - 0x3041 */
      class MovingModelAndEyepointControl : public Opcode
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0x3041;

      public:
         /** Constructor. */
         MovingModelAndEyepointControl();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         * @param size The size of the buffer.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Set the moving model #.
         * @param movingModelNumber Primary model.
         */
         void setMovingModelNumber(const unsigned short movingModelNumber);

         /** Set the submodel to move.
         * @param subModelNumber Submodel to move.
         */
         void setSubModelNumber(const unsigned char subModelNumber);

         /** Set the model select.
         * @param select Model select to move.
         */
         void setModelSelect(const unsigned char select);

         /** Set the lat, long, altitude.
         * @param latitude The latitude.
         * @param longitude The longitude.
         * @param altitude The altitude.
         */
         void setPosition(const double latitude, const double longitude, const double altitude);

         /** Set the orientation (roll, pitch, heading).
         * @param heading The heading.
         * @param pitch The pitch.
         * @param roll The roll.
         */
         void setOrientation(const double heading, const double pitch, const double roll);

         /** Set the latitude.
         * @param latitude The latitude.
         */
         void setLatitude(const double latitude);

         /** Set the longitude. 
         * @param longitude The longitude.
         */
         void setLongitude(const double longitude);

         /** Set the altitude.
         * @param altitude The altitude.
         */
         void setAltitude(const double altitude);

         /** Set the heading.
         * @param heading The heading.
         */
         void setHeading(const double heading);

         /** Set the pitch.
         * @param pitch The pitch.
         */
         void setPitch(const double pitch);

         /** Set the roll.
         * @param roll The roll.
         */
         void setRoll(const double roll);

         /** Set the X offset.
         * @param offset The X offset.
         */
         void setXOffset(const double offset);
         
         /** Set the Y offset.
         * @param offset The Y offset.
         */
         void setYOffset(const double offset);

         /** Set the Z offset.
         * @param offset The Z offset.
         */
         void setZOffset(const double offset);

         /** Set the roll valid flag.
         * @param valid The roll valid flag.
         */
         void setRollValid(const bool valid = true);

         /** Set the pitch valid flag.
         * @param valid The pitch valid flag.
         */
         void setPitchValid(const bool valid = true);

         /** Set the heading valid flag.
         * @param valid The heading valid flag.
         */
         void setHeadingValid(const bool valid = true);

         /** Set the Z or altitude valid flag. 
         * @param valid The Z or altitude flag.
         */
         void setZOrAltitudeValid(const bool valid = true);

         /** Set the Y or longitude valid flag.
         * @param valid The Y or longitude flag. 
         */
         void setYOrLongitudeValid(const bool valid = true);
            
         /** Set the X or latitude valid flag.
         * @param valid The X or latitude flag.
         */
         void setXOrLatitudeValid(const bool valid = true);

         /** Set the translational mode to geodetic. */
         void setTranslationalModeGeodetic();

         /** Set the translational model to cartesian. */
         void setTranslationalModeCartesian();

         /** Set the extrapolation mode disabled flag.
         * @param disabled The extrapolation disabled flag.
         */
         void setExtrapolationDisabled(const bool disabled = true);

      private:

         /** This structure represents the layout of the opcode data. */
         struct 
         {
            /** The opcode number. */
            unsigned short m_opcodeNumber : 16;
            /** The moving model number. */
            unsigned short m_movingModelNumber : 16;
            /** The sub model nuber. */
            unsigned char m_subModelNumber : 8;
            /** The model select */
            unsigned char m_modelSelect : 8;

            /** Should extrapolation be disabled? */
            unsigned short m_extrapolationDisabled : 1;
            /** The translation mode. */
            unsigned short m_translationalModeGeodetic : 1;
            /** Unused. */
            unsigned short : 1;
            /** X or Latitude. */
            unsigned short m_xOrLatitudeValid : 1;
            /** Y or Longitude. */
            unsigned short m_yOrLongitudeValid : 1;
            /** Z or Altitude. */
            unsigned short m_zOrAltitudeValid : 1;

            /** Is the heading valid? */
            unsigned short m_headingValid : 1;
            /** Is the pitch valid? */
            unsigned short m_pitchValid : 1;
            /** Is the roll valid? */
            unsigned short m_rollValid : 1;
            /** Unused. */
            unsigned short :7;

            /** Union between the latitude and X offset. */
            union  
            {
               /** Latitude. */
               __int64 m_latitude;
               /** X Offset. */
               struct
               {
                  /** Unused. */
                  unsigned int :32;
                  /** X offset. */
                  unsigned int m_xOffset;
               }m_latitudeOrXOffset;
            };

            /** Union between the longitude and Y offset. */
            union 
            {
               /** Longitude. */
               __int64 m_longitude;
               /** Y Offset. */
               struct
               {
                  /** Unused. */
                  unsigned int :32;
                  /** Y offset. */
                  unsigned int m_yOffset;
               }m_longitudeOrYOffset;
            };

            /** Altitude. */
            unsigned int m_altitude: 32;
            /** Z offset. */
            unsigned int m_zOffset : 32;
            /** Heading. */
            unsigned int m_heading : 32;
            /** Pitch. */
            unsigned int m_pitch : 32;
            /** Roll. */
            unsigned int m_roll : 32;
            /** Unused. */
            unsigned int m_unused :32;
         } m_buffer;
      };


      /** Ascii - 03050 */
      class Ascii : public Opcode
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0x3050;

      public:
         /** Constructor. */
         Ascii();

         /** Constructor. 
         * @param ascii The CLI command to send.         
         */
         Ascii(const char ascii[80]);


         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Set the CLI command to send. 
         * @param ascii The command to send.
         */
         virtual void set(const char ascii[80]);

      private:

         struct
         {
            /** The opcode number. */
            unsigned short m_opcodeNumber   : 16;
            /** Reserved. */
	         unsigned short m_reserved    : 16;
	         /** The ascii CLI command */
	         char m_ascii[80];
         } m_buffer;
      };

      /** Moving Model Velocity - 0x3090 */
      class MovingModelVelocity : public Opcode
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0x3090;

      public:

         /** Specifies coordinate system used for velocity. */
         enum CoordinateSystem
         {
            /** parent coordinate system */
            e_parentCoordinateSystem = 0,
            /** model body coordinate system */
            e_modelBodyCoordinateSystem = 1,
         };

         /** Constructor. */
         MovingModelVelocity();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Set the moving model #.
         * @param movingModelNumber Primary model.
         */
         void setMovingModelNumber(const unsigned short movingModelNumber);

         /** Set the submodel to move.
         * @param subModelNumber Submodel to move.
         */
         void setSubModelNumber(const unsigned char subModelNumber);

         /** Set the velocity.
         * @param xVelocity The velocity on the X axis.
         * @param yVelocity The velocity on the Y axis.
         * @param zVelocity The velocity on the Z axis.
         * @param headingRate The rate of change for the heading.
         * @param pitchRate The rate of change for the pitch.
         * @param rollRate The rate of change for the roll.
         */
         void setVelocity(double xVelocity = 0.0, double yVelocity = 0.0, double zVelocity = 0.0, 
   			double headingRate = 0.0, double pitchRate = 0.0, double rollRate = 0.0);

         /** Set the coordinate system to use.
         * @param system The coordinate system.
         */
         void setCoordinateSystem(CoordinateSystem system);

         /** Set the time constant in tenths of seconds to correct for
         * positional errors. 
         * @param time 0-255 Time in tenths of seconds.
         */
         void setTimeConstant(unsigned char time);

      private:

         struct
         {
            /** The opcode number 0x3090 */
            unsigned short m_opcodeNumber		   : 16;
            /** Specifies the primary model. */
            unsigned short m_movingModelNumber	: 16;
            /** Specifies the submodel. */
            unsigned char m_subModelNumber		: 8;
            /** Reserved */
            unsigned char				         : 8;
            /** Flags */
            unsigned char m_flags			   : 8;
            /** Specifies time constant, in tenths of seconds, for smooth removal of positional errors. */
            unsigned char m_timeConstant	   : 8;
            /** Specifies the x velocity. Feet/second are the units. Refer to the Scaled Velocity format description for format information. */
            int m_xVelocity		            : 32;
            /** Specifies the y velocity in database units/second. */
            int m_yVelocity		            : 32;
            /** Specifies the z velocity in database units/second. */
            int m_zVelocity	               : 32;
            /** Specifies the heading rate in revolutions/second. Refer to the Scaled Angular Rate format description for format information. */
            int m_headingRate                : 32;
            /** Specifies the pitch rate in revolutions/second. */
            int m_pitchRate                  : 32;
            /** Specifies the roll rate in revolutions/second. */
            int m_rollRate			            : 32;
            /** Should be set to zero for future compatibility. */
            int m_reserved 	               : 32;
         } m_buffer;
      };


      /** Load Status Request - 0xE000 0x0005/0x002F */
      class LoadStatusRequest : public ExtendedOpcodeRequest
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0xE000;
         /** The sub opcode A. */
         static const unsigned int subOpcodeA = 0x0005;
         /** The sub opcode B. */
         static const unsigned int subOpcodeB = 0x002F;

      public:
         /** Constructor. */
         LoadStatusRequest();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Get the size of the opcode. 
         * @return The size of the opcode.
         */
         virtual unsigned short getSize();

         /** Get the process Id.
         * @return The process Id.
         */
         virtual unsigned short getProcessId();

         /** Get the execution priority.
         * @return The execution priority.
         */
         virtual unsigned short getExecutionPriority();

         /** Get the Object Id.
         * @return The object Id.
         */
         virtual unsigned short getObjectId();

         /** Get the Function Id.
         * @return The function Id.
         */
         virtual unsigned short getFunctionId();

         /** Get the response priority.
         * @return The response priority.
         */
         virtual unsigned short getResponsePriority();

         /** Get the response process. 
         * @return The response process.
         */
         virtual unsigned short getResponseProcess();

         /** Get the sub opcode B.
         * @return The sub opcode B.
         */
         virtual unsigned short getSubOpcodeB();

         /** Get the sub opcode A.
         * @return The sub opcdoe A.
         */
         virtual unsigned short getSubOpcodeA();

         /** Get the user data. 
         * @return The user data.
         */
         virtual unsigned int getUserData();

         /** Set the longitudinal center.
         * @param longCenter The longitudinal center.
         */
         void setLongitudinalCenter(double longCenter);

         /** Set the latitudinal center. 
         * @param latCenter The latitudinal center.
         */
         void setLatitudinalCenter(double latCenter);

         /** Set the altitudinal center.
         * @param altCenter The altitudinal center.
         */
         void setAltitudinalCenter(double altCenter);

         /** Set the radius.
         * @param radius The radius.
         */
         void setRadius(float radius);

         /** Set the wait on models flag.
         * @param wait Wait for models to load.
         */
         void setWaitOnModels(bool wait);

         /** Set the wait on terrain flag.
         * @param wait Wait for the terrain to load.
         */
         void setWaitOnTerrain(bool wait);

         /** Set the wait on continuous texture flag.
         * @param wait Wait for the continuous texture to load.
         */
         void setWaitOnCT(bool wait);

         /** Set the non poll mode.
         * @param poll The poll mode.
         */
         void setNonPollMode(bool poll);

      private:
         struct
         {
            /** The opcode number. 0xe000 */
            unsigned short m_opcodeNumber;
            /** Length of opcode in bytes (28). */
	         unsigned short m_size;
            /** Direction of data transfer. 0x0003 = Host to EP */
            unsigned short m_processId;
            /** IG execution priority. 0x0001 = Foreground */
            unsigned short m_executionPriority;
            /** Function ID that defines the opcode and are used to dispatch the opcode. 0x005C*/
            unsigned short m_subOpcodeFuncId;
            /** Object ID that defines the opcode and are used to dispatch the opcode. 0x0005 */
            unsigned short m_subOpcodeObjId;
            /** Response Process ID that defines the direction of return data transfer. 0x0002 */
            unsigned short m_responseProcess;
            /** User defined priority that is returned in response opcode. 0x0001 */
            unsigned short m_responsePriority;
            /** User defined sub opcode B that is returned in response opcode */
            unsigned short m_userSubOpcodeB;
            /** User defined sub opcode A that is returned in response opcode. */
            unsigned short m_userSubOpcodeA;
            /** Additional User Data that will be returned in response opcode */
            unsigned int m_userData;

            /** Longitude of the area being queried for load status (eyepoint location) */
            int m_longitudinalCenter[2];
            /** Latitude of the area being queried for load status (eyepoint location) */
            int m_latitudinalCenter[2];
            /** Altitude of the area being queried for load status (eyepoint location) */
            int m_altitudinalCenter[2];
            /** Radius of the area being queried in feet */
            float m_radius;
            /** Models done flag. */
            unsigned int m_modelsDone :1;
            /** Terrain done flag. */
            unsigned int m_terrainDone :1;
            /** Continious Texture done. */
            unsigned int m_ctDone :1;
            /** Unused. */
            unsigned int :28;
            /** Non poll mode. */
            unsigned int m_nonPollMode :1;
         } m_buffer;
      };


      /** Load Status Response - 0xE000 0x0005/0x002F */
      class LoadStatusResponse : public ExtendedOpcodeResponse
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0xE000;
         /** The sub opcode A. */
         static const unsigned int subOpcodeA = 0x0005;
         /** The sub opcode B. */
         static const unsigned int subOpcodeB = 0x002F;

      public:
         /** Constructor. */
         LoadStatusResponse();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Get the size of the opcode. 
         * @return The size of the opcode.
         */
         virtual unsigned short getSize();

         /** Get the process Id.
         * @return The process Id.
         */
         virtual unsigned short getProcessId();

         /** Get the response priority.
         * @return The response priority.
         */
         virtual unsigned short getResponsePriority();

         /** Get the sub opcode B.
         * @return The sub opcode B.
         */
         virtual unsigned short getSubOpcodeB();

         /** Get the sub opcode A.
         * @return The sub opcdoe A.
         */
         virtual unsigned short getSubOpcodeA();

         /** Get the user data. 
         * @return The user data.
         */
         virtual unsigned int getUserData();

         /** Get the models loaded flag.
         * @return The models loaded flag.
         */
         bool getModelsLoaded();

         /** Get the terrain loaded flag.
         * @return The terrain loaded flag.
         */
         bool getTerrainLoaded();

         /** Get the CT loaded flag.
         * @return The CT loaded flag.
         */
         bool getCtLoaded();

      private:
         struct
         {
            /** The opcode number. 0xe000*/
            unsigned short m_opcodeNumber;  
            /** Length of opcode in bytes (112). */
	         unsigned short m_size;
            /** Direction of data transfer. 0x0002 = EP to Host */
            unsigned short m_processId;
            /** IG execution priority. 0x0001 = Foreground */
            unsigned short m_responsePriority;
            /** User supplied Sub Opcode B - Copied from request packet. 0x005C*/
            unsigned short m_userSubOpcodeB;
            /** User supplied Sub Opcode A - Copied from request packet. 0x0005 */
            unsigned short m_userSubOpcodeA;
            /** User supplied data - Copied from request packet. */
            unsigned int m_userData;
            /** Models Loaded Flag # */
            unsigned int m_modelsLoaded :1;
            /** Terrain Loaded Flag # */
            unsigned int m_terrainLoaded :1;
            /** Continuous Textures Loaded Flag # */
            unsigned int m_ctLoaded :1;
            /** Unused. */
            unsigned int :29;
         } m_buffer;
      };

      /** Moving Model Request - 0xE000 0x0005/0x0030 */
      class MovingModelRequest : public ExtendedOpcodeRequest
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0xE000;
         /** The sub opcode A. */
         static const unsigned int subOpcodeA = 0x0005;
         /** The sub opcode B. */
         static const unsigned int subOpcodeB = 0x0030;

      public:
         /** Constructor. */
         MovingModelRequest();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Get the size of the opcode. 
         * @return The size of the opcode.
         */
         virtual unsigned short getSize();

         /** Get the process Id.
         * @return The process Id.
         */
         virtual unsigned short getProcessId();

         /** Get the execution priority.
         * @return The execution priority.
         */
         virtual unsigned short getExecutionPriority();

         /** Get the Object Id.
         * @return The object Id.
         */
         virtual unsigned short getObjectId();

         /** Get the Function Id.
         * @return The function Id.
         */
         virtual unsigned short getFunctionId();

         /** Get the response priority.
         * @return The response priority.
         */
         virtual unsigned short getResponsePriority();

         /** Get the response process. 
         * @return The response process.
         */
         virtual unsigned short getResponseProcess();

         /** Get the sub opcode B.
         * @return The sub opcode B.
         */
         virtual unsigned short getSubOpcodeB();

         /** Get the sub opcode A.
         * @return The sub opcdoe A.
         */
         virtual unsigned short getSubOpcodeA();

         /** Get the user data. 
         * @return The user data.
         */
         virtual unsigned int getUserData();

         /** Set the moving model number.
         * @param mmNumber The moving model number.
         */
         void setMovingModelNumber(int movingModelNumber);

         /** Set the submodel number.
         * @param submodelNumber The submodel number.
         */
         void setSubModelNumber(int submodelNumber);

         /** Set the mode. 
         * @param mode The mode.
         */
         void setMode(short mode);

         /** Set the Height Above Terrain Enable flag.
         * @param returnHat The value of the flag.
         */
         void setHatEnable(bool returnHat);

         /** Set the Mission Function Engine Bypass flag.
         * @param bypassMfe The value of the flag.
         */
         void setMfeBypass(bool bypassMfe);

         /** Set the return timestamp flag.
         * @param returnTimestamp The value of the flag.
         */
         void setReturnTimestamp(bool returnTimestamp);

         /** Set the return world position flag.
         * @param returnWorldPosition The value of the flag.
         */
         void setReturnWorldPosition(bool returnWorldPosition);

         /** Set the user data field.
         * @param data User data.
         */
         void setUserData(const int data);

      private:
         struct
         {
            /** The opcode number. 0xe000 */
            unsigned short m_opcodeNumber;
            /** Length of opcode in bytes (28). */
	         unsigned short m_size;
            /** Direction of data transfer. 0x0003 = Host to EP */
            unsigned short m_processId;
            /** IG execution priority. 0x0001 = Foreground */
            unsigned short m_executionPriority;
            /** Function ID that defines the opcode and are used to dispatch the opcode. 0x005C*/
            unsigned short m_subOpcodeFuncId;
            /** Object ID that defines the opcode and are used to dispatch the opcode. 0x0005 */
            unsigned short m_subOpcodeObjId;
            /** Response Process ID that defines the direction of return data transfer. 0x0002 */
            unsigned short m_responseProcess;
            /** User defined priority that is returned in response opcode. 0x0001 */
            unsigned short m_responsePriority;
            /** User defined sub opcode B that is returned in response opcode */
            unsigned short m_userSubOpcodeB;
            /** User defined sub opcode A that is returned in response opcode. */
            unsigned short m_userSubOpcodeA;
            /** Additional User Data that will be returned in response opcode */
            unsigned int m_userData;
            /** Moving Model Number for which info is being returned */
            int m_movingModelNumber;
            /** Secondary Submodel */
            int m_subModelNumber;
            /** Mode: -1=disable, 0=single response, 1=send whenever possible, 
              *n>1 send every nth frame where possible */
            unsigned short m_mode;
            /** Flags */
            /** If true return Height Above Terrain */
            unsigned short m_returnHat : 1;
            /** If true, bypass Mission Function Engine if one exists on the IG */
            unsigned short m_bypassMfe : 1;
            /** If true, timestamp is returned with response */
            unsigned short m_returnTimestamp : 1;
            /** If model is chained, false returns position relative to parent, 1=world space position */
            unsigned short m_returnWorldPosition : 1;
            /** Unused. */
            unsigned short  : 12;
         } m_buffer;
      };


      /** Moving Model Response - 0xE000 0x0005/0x0030 */
      class MovingModelResponse : public ExtendedOpcodeResponse
      {
      public:

         /** The opcode number. */
         static const unsigned int opcodeNumber = 0xE000;
         /** The sub opcode A. */
         static const unsigned int subOpcodeA = 0x0005;
         /** The sub opcode B. */
         static const unsigned int subOpcodeB = 0x0030;

      public:
         /** Constructor. */
         MovingModelResponse();

         /** Get the data from the opcode. 
         * @return The buffer of data from the opcode.
         */
         virtual char* getBuffer();
         
         /** Get the size of the opcode buffer.
         * @return The size of the opcode buffer.
         */
         virtual int getBufferSize();
         
         /** Set the opcode buffer.
         * @param buffer The buffer of data.
         */
         virtual void setBuffer(char* buffer);

         /** Get the opcode number
         * @return The opcode number.
         */
         virtual unsigned short getOpcodeNumber();

         /** Get the size of the opcode. 
         * @return The size of the opcode.
         */
         virtual unsigned short getSize();

         /** Get the process Id.
         * @return The process Id.
         */
         virtual unsigned short getProcessId();

         /** Get the response priority.
         * @return The response priority.
         */
         virtual unsigned short getResponsePriority();

         /** Get the sub opcode B.
         * @return The sub opcode B.
         */
         virtual unsigned short getSubOpcodeB();

         /** Get the sub opcode A.
         * @return The sub opcdoe A.
         */
         virtual unsigned short getSubOpcodeA();

         /** Get the user data. 
         * @return The user data.
         */
         virtual unsigned int getUserData();

         /** Get the moving model number.
         * @return The moving model number.
         */
         int getMovingModelNumber();

         /** Get the submodel number.
         * @return The submodel number.
         */
         int getSubmodelNumber();

         /** Get the latitude.
         * @return The latitude.
         */
         double getLatitude();

         /** Get the longitude.
         * @return The longitude.
         */
         double getLongitude();

         /** Get the altitude.
         * @return The altitude.
         */
         double getAltitude();

         /** Get the heading.
         * @return The heading.
         */
         float getHeading();

         /** Get the pitch.
         * @return The pitch.
         */
         float getPitch();

         /** Get the roll.
         * @return The roll.
         */
         float getRoll();

         /** Get the height above terrain.
         * @return The height above terrain.
         */
         float getHat();

         /** Get the height of terrain.
         * @return The height of terrain.
         */
         float getHot();

      private:
         struct
         {
            /** The opcode number. 0xe000*/
            unsigned short m_opcodeNumber;  
            /** Length of opcode in bytes (112). */
	         unsigned short m_size;
            /** Direction of data transfer. 0x0002 = EP to Host */
            unsigned short m_processId;
            /** IG execution priority. 0x0001 = Foreground */
            unsigned short m_responsePriority;
            /** User supplied Sub Opcode B - Copied from request packet. 0x005C*/
            unsigned short m_userSubOpcodeB;
            /** User supplied Sub Opcode A - Copied from request packet. 0x0005 */
            unsigned short m_userSubOpcodeA;
            /** User supplied data - Copied from request packet. */
            unsigned int m_userData;
            /** Moving Model Number */
            int m_movingModelNumber;
            /** Submodel Number */
            int m_subModelNumber;
            /** Longitude of Moving Model */
            int m_longitude[2];
            /** Latitude of Moving Model */
            int m_latitude[2];
            /** Altitude of Moving Model */
            int m_altitude[2];
            /** Heading of Moving Model */
            float m_heading;
            /** Pitch of Moving Model */
            float m_pitch;
            /** Roll of Moving Model */
            float m_roll;
            /** Height above terrain */
            float m_hat;
            /** Height of terrain below model */
            float m_hot;
            /** The current time in seconds. */
            unsigned int m_seconds;
            /** The current time in microseconds. */
            unsigned int m_microSeconds;
         } m_buffer;
      };

   }
}